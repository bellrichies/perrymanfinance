<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Content\MediaService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '2de626a4882d63ef97142363a827b790' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0a3873383fa5c11057e77991e5502e77' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '52abeb2eefd308649e0619a6f67a81a4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => 'all',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd321ae36e4495ca57810105fff397fa7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => 'upload',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3df250347521849eb3ff1db39fb1e22' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => 'delete',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '060dc7283ff9cf540749d8cb184c122d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => 'update',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0d6500d8525467e4581c830cc82f581b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2d8b390e847d11103e35f8c8a808cd0f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'mediarepository' => 'PerrymanFinance\\Repositories\\MediaRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\MediaService',
         'functionName' => 'uuid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Content\\MediaService.php' => '471d6e4ddf78246129a55e0a26a0ff15428704d848d89a8f3ce0c0dd70fc4079',
    ),
  ),
));