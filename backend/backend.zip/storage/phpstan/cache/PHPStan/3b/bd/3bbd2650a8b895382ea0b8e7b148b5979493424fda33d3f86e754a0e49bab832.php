<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Exceptions\MethodNotAllowedException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'abccac59092cfe7f5c0d95ceb1c0ded2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Exceptions',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Exceptions\\MethodNotAllowedException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '501558671e5f72215f70d6330c6c0d2a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Exceptions',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Exceptions\\MethodNotAllowedException',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Exceptions\\MethodNotAllowedException.php' => '679ea0936f73898994e0a24a60e7d660c4f36e1bb496bbcfb774bdeddae54546',
    ),
  ),
));