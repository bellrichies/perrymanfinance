<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\database
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1-enums',
   'data' => 
  array (
    'D:\\Perryman\\backend\\database\\migrations\\202609070001_create_identity_tables.php' => 
    array (
      0 => 'cdcc880f16761f92768d4ec328d6d382f2aba89bf6d82dcaf4f3ed3ee016ffd4',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\migrations\\202609070002_create_content_tables.php' => 
    array (
      0 => 'f3c0ed717f293c13e8665d5b6bfd554fa5c2557656add471f2a47877f0a1a91e',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\migrations\\202609070003_create_investment_tables.php' => 
    array (
      0 => '258b3f1bce5a9b46e603fae94e924dce299ad6731eca8ab87d35304671c03dde',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\migrations\\202609070004_create_insight_tables.php' => 
    array (
      0 => '6cabbf3a23e207414ae39a8796218ac32faf577e513e1b47df2039b524c5324d',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\migrations\\202609070005_create_enquiry_tables.php' => 
    array (
      0 => '9c5473b6cc60d95277d67479f4e5ef9f53a2e29eafc66bd4805e63fd2893e29d',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\migrations\\202609070006_create_seo_tables.php' => 
    array (
      0 => '949b3c0e47b8111441b6d898ac56c79de901abc102bef64cf6111220d277d52a',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\seeders\\ReferenceDataSeeder.php' => 
    array (
      0 => 'ff77977050b0402345883f536e17740f8cf10debceaaed7e1a7556c8efba9cef',
      1 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\referencedataseeder',
      ),
      2 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\name',
        1 => 'perrymanfinance\\database\\seeders\\run',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\migrations\\202609070007_create_rate_limit_counters.php' => 
    array (
      0 => 'a9b53de3ef7b496f156579235a2008d2dcc17d286a2437b1b67f6239e5bc1bf1',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\migrations\\202609080001_add_release_hardening_indexes.php' => 
    array (
      0 => '487db8368f623457a7378645b4fe8a249b68dea5cf20f6711461bdf6d17544ff',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\seeders\\PublicContentSeeder.php' => 
    array (
      0 => '843c8116149c483e998655cb1ae1cd7479cc6d50d5542d74550bda916b1cb09c',
      1 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\publiccontentseeder',
      ),
      2 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\name',
        1 => 'perrymanfinance\\database\\seeders\\run',
        2 => 'perrymanfinance\\database\\seeders\\ensureseederadmin',
        3 => 'perrymanfinance\\database\\seeders\\upsertpage',
        4 => 'perrymanfinance\\database\\seeders\\replacesections',
        5 => 'perrymanfinance\\database\\seeders\\upsertlegaldocument',
        6 => 'perrymanfinance\\database\\seeders\\upsertseo',
        7 => 'perrymanfinance\\database\\seeders\\idforslug',
        8 => 'perrymanfinance\\database\\seeders\\upsertinvestmentcategory',
        9 => 'perrymanfinance\\database\\seeders\\upsertinvestmentopportunity',
        10 => 'perrymanfinance\\database\\seeders\\upsertarticlecategory',
        11 => 'perrymanfinance\\database\\seeders\\upserttag',
        12 => 'perrymanfinance\\database\\seeders\\upsertarticle',
        13 => 'perrymanfinance\\database\\seeders\\upsertfaq',
        14 => 'perrymanfinance\\database\\seeders\\settings',
        15 => 'perrymanfinance\\database\\seeders\\legaldocuments',
        16 => 'perrymanfinance\\database\\seeders\\pages',
        17 => 'perrymanfinance\\database\\seeders\\investmentcategories',
        18 => 'perrymanfinance\\database\\seeders\\investmentopportunities',
        19 => 'perrymanfinance\\database\\seeders\\articlecategories',
        20 => 'perrymanfinance\\database\\seeders\\tags',
        21 => 'perrymanfinance\\database\\seeders\\articles',
        22 => 'perrymanfinance\\database\\seeders\\faqs',
        23 => 'perrymanfinance\\database\\seeders\\grid',
        24 => 'perrymanfinance\\database\\seeders\\section',
        25 => 'perrymanfinance\\database\\seeders\\page',
        26 => 'perrymanfinance\\database\\seeders\\uuid',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\seeders\\DevAdminSeeder.php' => 
    array (
      0 => '1ce9a56d8b3b9d78d51ed257e0cf2720fbaf5c3a5824e78730c739858fc1e099',
      1 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\devadminseeder',
      ),
      2 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\name',
        1 => 'perrymanfinance\\database\\seeders\\run',
        2 => 'perrymanfinance\\database\\seeders\\uuid',
      ),
      3 => 
      array (
      ),
    ),
  ),
));