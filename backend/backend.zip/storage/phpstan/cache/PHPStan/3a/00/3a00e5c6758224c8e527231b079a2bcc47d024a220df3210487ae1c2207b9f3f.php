<?php declare(strict_types = 1);

// ftm-phar://D:\Perryman\backend\vendor\phpstan\phpstan\phpstan.phar\vendor\phpstan\php-8-stubs\stubs\ext\standard\mkdir.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '6e44f68ddfd6cfe7163e0e1209c06640' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
        ),
         'className' => NULL,
         'functionName' => 'mkdir',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar://D:\\Perryman\\backend\\vendor\\phpstan\\phpstan\\phpstan.phar\\vendor\\phpstan\\php-8-stubs\\stubs\\ext\\standard\\mkdir.stub' => '29c61aa369bc763607781dc3818c2cc8f51cae7d9f7e95d404c0ca1dc832bb96',
    ),
  ),
));