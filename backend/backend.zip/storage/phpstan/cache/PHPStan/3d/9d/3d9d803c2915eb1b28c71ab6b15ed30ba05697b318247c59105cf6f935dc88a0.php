<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-PASSWORD_DEFAULT
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'PASSWORD_DEFAULT',
        'filename' => 'phpstorm-stubs:standard/password.stub',
        'extensionName' => 'standard',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'PASSWORD_DEFAULT',
    'shortName' => 'PASSWORD_DEFAULT',
    'value' => 
    array (
      'code' => '\'2y\'',
      'attributes' => 
      array (
        'startLine' => 3,
        'endLine' => 3,
        'startTokenPos' => 7,
        'startFilePos' => 34,
        'endTokenPos' => 7,
        'endFilePos' => 37,
      ),
    ),
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 3,
    'endLine' => 3,
    'startColumn' => 1,
    'endColumn' => 32,
    'namespace' => NULL,
  ),
));