<?php declare(strict_types = 1);

// osfsl-D:/Perryman/backend/vendor/composer/../nikic/php-parser/lib/PhpParser/Node.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-8661124cdfe90d86af7937f563942d59c63630da2fa994e290e7b9294442eed5-8.2.12',
   'data' => 
  array (
    'classes' => 
    array (
      'phpparser\\node' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));