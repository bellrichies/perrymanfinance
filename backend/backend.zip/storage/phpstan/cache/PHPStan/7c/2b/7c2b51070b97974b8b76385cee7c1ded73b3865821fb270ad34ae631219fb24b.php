<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\tests\Support\ApplicationFactory.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '872d0175144ab0f9dda39ee7f5dfedbd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Support',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'application' => 'PerrymanFinance\\Core\\Application',
          'container' => 'PerrymanFinance\\Core\\Container',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'exceptionhandler' => 'PerrymanFinance\\Http\\Exceptions\\ExceptionHandler',
          'middlewaredispatcher' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
          'router' => 'PerrymanFinance\\Http\\Router',
        ),
         'className' => 'Tests\\Support\\ApplicationFactory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b73ff3f733377c73827dbb831efc454' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Support',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'application' => 'PerrymanFinance\\Core\\Application',
          'container' => 'PerrymanFinance\\Core\\Container',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'exceptionhandler' => 'PerrymanFinance\\Http\\Exceptions\\ExceptionHandler',
          'middlewaredispatcher' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
          'router' => 'PerrymanFinance\\Http\\Router',
        ),
         'className' => 'Tests\\Support\\ApplicationFactory',
         'functionName' => 'create',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\tests\\Support\\ApplicationFactory.php' => '532152598c2caef7e5a8fb846882583cf345fd7e04347d7417dd55f745464b43',
    ),
  ),
));