<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\public
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1-enums',
   'data' => 
  array (
    'D:\\Perryman\\backend\\public\\index.php' => 
    array (
      0 => '034e8f2dde6775df245bf76afe4c3fe595dec049c7b16ffc0a50a5941f32b4b9',
      1 => 
      array (
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
  ),
));