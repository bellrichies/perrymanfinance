<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\app\Http\Exceptions\BadRequestException.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PerrymanFinance\Http\Exceptions\BadRequestException
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-eb280f60e7566a719b4094e1e489f7bb4da886aa0d26cca97a54e7237245bac4',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
        'filename' => 'D:/Perryman/backend/app/Http/Exceptions/BadRequestException.php',
      ),
    ),
    'namespace' => 'PerrymanFinance\\Http\\Exceptions',
    'name' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
    'shortName' => 'BadRequestException',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 13,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PerrymanFinance\\Http\\Exceptions\\HttpException',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
          'message' => 
          array (
            'name' => 'message',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 9,
            'endLine' => 9,
            'startColumn' => 33,
            'endColumn' => 47,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 9,
        'endLine' => 12,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Http\\Exceptions',
        'declaringClassName' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
        'implementingClassName' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
        'currentClassName' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));