<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Insights\InsightService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '473c15754008ef08ea94301aaf4bab9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f726663ddce87f64653778bca7aeabb3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '85cc70281a49c882bd29d49e5010a9c3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'categories',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f512ff4f51b1ac9f6152b445bcc7fa3e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'tags',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '295210e6ee819d86b2bf950da40fdf17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'saveCategory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa6bbe40e13b5786d77542af96cc5cc2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'deleteCategory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9b97c87dc276300ca400509d3d613069' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'saveTag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'da0a47e1386ecce5489bc843ab84060d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'deleteTag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ad0702004279422ba7a3aa9f7b339a88' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'articles',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'deab98d1b519db062b58e7f247902d77' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'article',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '02abaaf56a1551c2fcf4de03e71d8b42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'saveArticle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8b49e1411f9b64a54f6721c26435d3db' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'archive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9ab540b71da38c3c21cb00f504b3f15d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'faqs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e08b26f2380b6c4eba00a9bd59b2bced' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'saveFaq',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f1e79fa4f719aa4954583b45c9f6530d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'deleteFaq',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5607d6126371c730627fc59b75660c03' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'publicShape',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b68d35cc865145d9738ee7bf162bf278' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'seo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12961083e25f11298da29fafbb6363f3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'tagIds',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9abe9fe54ad9d2ad1aa42962e2a4640a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'string',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dcd563021dbd9b56688ff0d4202193dc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'optional',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5895204b72189e3cd437b111a6b16bef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'status',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e59d97716d9fb6e445800d73a40b84d1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'slug',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9854e2bd193dad46eae31b6c2c3be1d9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'nullablePositiveInt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c09e55fad6fa50ee641aa7792d5531c8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'duplicate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dd91c19b9da79e72abc853f948e319cd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '28a7782d9f41c69d60292e74c4bfc17a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Insights',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Insights\\InsightService',
         'functionName' => 'uuid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Insights\\InsightService.php' => 'f2598dd26ddf214adea1061887eff14acc1f1f35043d8457660b9ab4aeb10c83',
    ),
  ),
));