<?php declare(strict_types = 1);

// osfsl-phar://D:/Perryman/backend/vendor/phpstan/phpstan/phpstan.phar/src/Internal/CombinationsHelper.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-f31e1d64505a30eb0960999255b3654d6b24071eca5c92a1c9da9f3b8baa8554-8.3.33',
   'data' => 
  array (
    'classes' => 
    array (
      'phpstan\\internal\\combinationshelper' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));