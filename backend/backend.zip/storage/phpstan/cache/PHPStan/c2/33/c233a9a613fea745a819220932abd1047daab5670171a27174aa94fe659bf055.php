<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Database\PdoConnectionManagerTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Database\PdoConnectionManagerTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-55e42b83e4c08c0d7112ba4b705d77a0830d9a03c4b42aa7725b3d88ea1a0547',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Database\\PdoConnectionManagerTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Database/PdoConnectionManagerTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Database',
    'name' => 'Tests\\Unit\\Database\\PdoConnectionManagerTest',
    'shortName' => 'PdoConnectionManagerTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 12,
    'endLine' => 29,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testConfiguredConnectionIsCreatedOnceWithSafeDefaults' => 
      array (
        'name' => 'testConfiguredConnectionIsCreatedOnceWithSafeDefaults',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 14,
        'endLine' => 28,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Database',
        'declaringClassName' => 'Tests\\Unit\\Database\\PdoConnectionManagerTest',
        'implementingClassName' => 'Tests\\Unit\\Database\\PdoConnectionManagerTest',
        'currentClassName' => 'Tests\\Unit\\Database\\PdoConnectionManagerTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));