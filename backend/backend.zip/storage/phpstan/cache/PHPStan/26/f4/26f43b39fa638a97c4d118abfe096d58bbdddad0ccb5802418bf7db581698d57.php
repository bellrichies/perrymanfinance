<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Domain\Content\PublicationWorkflow.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '788c6619132f2cf926a6aac8b9571fa1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\Content',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '075197829f39b5e16db6c540df2959f2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\Content',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
         'functionName' => 'guard',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Domain\\Content\\PublicationWorkflow.php' => '7c9fa85a7cda56fddb1371706ba85d81ec8a98145172f9e5bb3e3ccd8baa6780',
    ),
  ),
));