<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-FILTER_SANITIZE_EMAIL
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'FILTER_SANITIZE_EMAIL',
        'filename' => 'phpstorm-stubs:filter/filter.stub',
        'extensionName' => 'filter',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'FILTER_SANITIZE_EMAIL',
    'shortName' => 'FILTER_SANITIZE_EMAIL',
    'value' => 
    array (
      'code' => '517',
      'attributes' => 
      array (
        'startLine' => 7,
        'endLine' => 7,
        'startTokenPos' => 9,
        'startFilePos' => 128,
        'endTokenPos' => 9,
        'endFilePos' => 130,
      ),
    ),
    'docComment' => '/**
 * ID of "email" filter.
 * @link https://php.net/manual/en/filter.constants.php
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 7,
    'startColumn' => 1,
    'endColumn' => 36,
    'namespace' => NULL,
  ),
));