<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Enquiries\EnquiryService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '0485ea5bc52075154c86d1385adf058d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'loggerinterface' => 'PerrymanFinance\\Logging\\LoggerInterface',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
          'ratelimiter' => 'PerrymanFinance\\Services\\Identity\\RateLimiter',
          'validator' => 'PerrymanFinance\\Validation\\Validator',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\EnquiryService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5b25adca8d247413c9046b1c5dbf0690' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'loggerinterface' => 'PerrymanFinance\\Logging\\LoggerInterface',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
          'ratelimiter' => 'PerrymanFinance\\Services\\Identity\\RateLimiter',
          'validator' => 'PerrymanFinance\\Validation\\Validator',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\EnquiryService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '37bbefc4017424bb52be00e7ab7baa76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'loggerinterface' => 'PerrymanFinance\\Logging\\LoggerInterface',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
          'ratelimiter' => 'PerrymanFinance\\Services\\Identity\\RateLimiter',
          'validator' => 'PerrymanFinance\\Validation\\Validator',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\EnquiryService',
         'functionName' => 'submit',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Enquiries\\EnquiryService.php' => '46c1860abd51339dd5d8d93127dadd056a91cfb166de7abfad856238135c7515',
    ),
  ),
));