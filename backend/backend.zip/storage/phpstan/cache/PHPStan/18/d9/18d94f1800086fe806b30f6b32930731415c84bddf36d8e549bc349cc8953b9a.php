<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Support\ExampleService.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Support\ExampleService
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-3c399718aadc0ec20b929293a31cb0199e48fb5778fe00b44e2aa76bf508ecfb',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Support\\ExampleService',
        'filename' => 'D:/Perryman/backend/tests/Support/ExampleService.php',
      ),
    ),
    'namespace' => 'Tests\\Support',
    'name' => 'Tests\\Support\\ExampleService',
    'shortName' => 'ExampleService',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 9,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
      0 => 'Tests\\Support\\ExampleContract',
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));