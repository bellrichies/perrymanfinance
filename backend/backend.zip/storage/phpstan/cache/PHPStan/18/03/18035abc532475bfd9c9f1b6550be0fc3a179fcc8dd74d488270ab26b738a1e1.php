<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\tests\Feature\InvestmentCatalogueTest.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '6bb8fda1b32b8e79c23b2ef113781325' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b02fc244f10784ce383e8b9b9de61514' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'setUp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '66c60827ac5b7426cc2ef97b1bda1ae7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'testDraftIsInvisibleAndPublishedDetailIsPublic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b9526ed31e9ffe174379d9942a3eabbf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'testPublishingCriticalPathRequiresReviewRiskAndDisclaimer',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3cf84f481771faaeadb9cbb8be162c5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'testFilteringAndPagination',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e1cf2cc735b3d03dc058a5c89c8db407' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'testSlugAndRiskValidation',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '88e899355d3f3de6df731a5820b60b81' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'testAdminMutationRequiresInvestmentPermission',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c8db65aed5ceeb3d1bd9ab8581b2635' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'input',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e81d8e09bf640920f23c65eaf211c40f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'permissionmiddleware' => 'PerrymanFinance\\Http\\Middleware\\PermissionMiddleware',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'investmentservice' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'applicationfactory' => 'Tests\\Support\\ApplicationFactory',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\InvestmentCatalogueTest',
         'functionName' => 'createSchema',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\tests\\Feature\\InvestmentCatalogueTest.php' => 'b3a557ce62c394d3affd09c930d9d940ae05a6b714abde6efe552f039626a729',
    ),
  ),
));