<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\ClientPlanRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '820cadabb9eec863c9b9734271876513' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '481d5e2d9a08d3bb40176db410913184' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'eligiblePlans',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e1b65ee2bbcb8942c762b9c3903dad07' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'findPublishedOpportunityId',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd6f72d594147e7dfd51be6f1b871ff36' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'hasOpenRequest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6147e29fe62fbcfd79a6f3c456140fb3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'createRequest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '68550e607f43b2db8ce1791aa71715bb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'requestsForClient',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '868d8e6be98026603a2ab4800c84bc93' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'activeAccountsForClient',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b0ce20b8eecee295365a6b4627d24fac' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'listRequests',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12c8abde873ef7f4e1dea89ea2f6b8bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'findRequestByUuid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '36ca0fac75f5886a899c9c93883a768f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'reviewRequest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '001a65b2b8af2625bcb6508e809b1bd6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
         'functionName' => 'createAccountForApprovedRequest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\ClientPlanRepository.php' => '0d90247ae5cb05c05014035b0308d84aa416b3eb1576b5a7579f21a99314d678',
    ),
  ),
));