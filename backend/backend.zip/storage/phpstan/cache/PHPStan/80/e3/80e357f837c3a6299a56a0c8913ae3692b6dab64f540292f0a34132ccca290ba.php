<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Validation\Validator.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '8ab177b89755fa6960ab7cb27a50ab46' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Validation',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Validation\\Validator',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '921da7966f16e86fe5480aae46efb515' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Validation',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Validation\\Validator',
         'functionName' => 'validate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '54b3fb10e1a98106730579a6a0c88c44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Validation',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Validation\\Validator',
         'functionName' => 'check',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0ceca99b6bb46d08a22d63afabe3a8cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Validation',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Validation\\Validator',
         'functionName' => 'length',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '01f902d52847b3873a011865301cb510' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Validation',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Validation\\Validator',
         'functionName' => 'validEmail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5447116ca3f81cc03b075bd8ce32f42b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Validation',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Validation\\Validator',
         'functionName' => 'validUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '91bc314435b0d3b4fea5d4c62d9271c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Validation',
         'uses' => 
        array (
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
        ),
         'className' => 'PerrymanFinance\\Validation\\Validator',
         'functionName' => 'matches',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Validation\\Validator.php' => '02052ed9f35d8fc985e7162fa926c39f9f6bb13f83b747d8bec7d36f7fd39817',
    ),
  ),
));