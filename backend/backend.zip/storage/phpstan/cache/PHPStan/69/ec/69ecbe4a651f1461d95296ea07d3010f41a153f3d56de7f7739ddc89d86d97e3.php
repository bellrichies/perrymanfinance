<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionClass-reflectionfunctionabstract
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'ReflectionFunctionAbstract',
        'filename' => 'phpstorm-stubs:Reflection/ReflectionFunctionAbstract.stub',
        'extensionName' => 'Reflection',
        'aliasName' => NULL,
      ),
    ),
    'namespace' => NULL,
    'name' => 'ReflectionFunctionAbstract',
    'shortName' => 'ReflectionFunctionAbstract',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 64,
    'docComment' => '/**
 * A parent class to <b>ReflectionFunction</b>, read its
 * description for details.
 *
 * @link https://php.net/manual/en/class.reflectionfunctionabstract.php
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 10,
    'endLine' => 389,
    'startColumn' => 5,
    'endColumn' => 5,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
      0 => 'Reflector',
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'name' => 
      array (
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'name' => 'name',
        'modifiers' => 1,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'default' => NULL,
        'docComment' => '/**
 * @var string Name of the function, same as calling the {@see ReflectionFunctionAbstract::getName()} method
 */',
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Immutable',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'isRepeated' => false,
            'arguments' => 
            array (
              0 => 
              array (
                'code' => '[\'8.1\' => \'string\']',
                'attributes' => 
                array (
                  'startLine' => 16,
                  'endLine' => 16,
                  'startTokenPos' => 29,
                  'startFilePos' => 529,
                  'endTokenPos' => 35,
                  'endFilePos' => 547,
                ),
              ),
              'default' => 
              array (
                'code' => '\'\'',
                'attributes' => 
                array (
                  'startLine' => 16,
                  'endLine' => 16,
                  'startTokenPos' => 41,
                  'startFilePos' => 559,
                  'endTokenPos' => 41,
                  'endFilePos' => 560,
                ),
              ),
            ),
          ),
        ),
        'startLine' => 15,
        'endLine' => 17,
        'startColumn' => 9,
        'endColumn' => 28,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      '__clone' => 
      array (
        'name' => '__clone',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'isRepeated' => false,
            'arguments' => 
            array (
              'from' => 
              array (
                'code' => '"8.1"',
                'attributes' => 
                array (
                  'startLine' => 24,
                  'endLine' => 24,
                  'startTokenPos' => 60,
                  'startFilePos' => 834,
                  'endTokenPos' => 60,
                  'endFilePos' => 838,
                ),
              ),
            ),
          ),
        ),
        'docComment' => '/**
 * Clones function
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.clone.php
 * @return void
 */',
        'startLine' => 24,
        'endLine' => 27,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 4,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'inNamespace' => 
      array (
        'name' => 'inNamespace',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Checks if function in namespace
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.innamespace.php
 * @return bool {@see true} if it\'s in a namespace, otherwise {@see false}
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 35,
        'endLine' => 38,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'isClosure' => 
      array (
        'name' => 'isClosure',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Checks if closure
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.isclosure.php
 * @return bool {@see true} if it\'s a closure, otherwise {@see false}
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 46,
        'endLine' => 50,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'isDeprecated' => 
      array (
        'name' => 'isDeprecated',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Checks if deprecated
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.isdeprecated.php
 * @return bool {@see true} if it\'s deprecated, otherwise {@see false}
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 58,
        'endLine' => 62,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'isInternal' => 
      array (
        'name' => 'isInternal',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Checks if is internal
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.isinternal.php
 * @return bool {@see true} if it\'s internal, otherwise {@see false}
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 70,
        'endLine' => 74,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'isUserDefined' => 
      array (
        'name' => 'isUserDefined',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Checks if user defined
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.isuserdefined.php
 * @return bool {@see true} if it\'s user-defined, otherwise {@see false}
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 82,
        'endLine' => 86,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'isGenerator' => 
      array (
        'name' => 'isGenerator',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Returns whether this function is a generator
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.isgenerator.php
 * @return bool {@see true} if the function is generator, otherwise {@see false}
 * @since 5.5
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 95,
        'endLine' => 99,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'isVariadic' => 
      array (
        'name' => 'isVariadic',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Returns whether this function is variadic
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.isvariadic.php
 * @return bool {@see true} if the function is variadic, otherwise {@see false}
 * @since 5.6
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 108,
        'endLine' => 112,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getClosureThis' => 
      array (
        'name' => 'getClosureThis',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'object',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Returns this pointer bound to closure
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getclosurethis.php
 * @return object|null Returns $this pointer or {@see null} in case of an error.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 120,
        'endLine' => 124,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getClosureScopeClass' => 
      array (
        'name' => 'getClosureScopeClass',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'ReflectionClass',
                  'isIdentifier' => false,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Returns the scope associated to the closure
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getclosurescopeclass.php
 * @return ReflectionClass|null Returns the class on success or {@see null}
 * on failure.
 * @since 5.4
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 134,
        'endLine' => 138,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getClosureCalledClass' => 
      array (
        'name' => 'getClosureCalledClass',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'ReflectionClass',
                  'isIdentifier' => false,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * @return ReflectionClass|null Returns the class on success or {@see null}
 * on failure.
 * @since 8.0
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 145,
        'endLine' => 149,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getDocComment' => 
      array (
        'name' => 'getDocComment',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'string',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'false',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets doc comment
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getdoccomment.php
 * @return string|false The doc comment if it exists, otherwise {@see false}
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 157,
        'endLine' => 161,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getEndLine' => 
      array (
        'name' => 'getEndLine',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'int',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'false',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets end line number
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getendline.php
 * @return int|false The ending line number of the user defined function,
 * or {@see false} if unknown.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 170,
        'endLine' => 174,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getExtension' => 
      array (
        'name' => 'getExtension',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'ReflectionExtension',
                  'isIdentifier' => false,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets extension info
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getextension.php
 * @return ReflectionExtension|null The extension information, as a
 * {@see ReflectionExtension} object or {@see null} instead.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 183,
        'endLine' => 187,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getExtensionName' => 
      array (
        'name' => 'getExtensionName',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'string',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'false',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets extension name
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getextensionname.php
 * @return string|false The extension\'s name or {@see false} instead.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 195,
        'endLine' => 199,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getFileName' => 
      array (
        'name' => 'getFileName',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'string',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'false',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets file name
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getfilename.php
 * @return string|false The file name or {@see false} in case of error.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 207,
        'endLine' => 211,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getName' => 
      array (
        'name' => 'getName',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets function name
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getname.php
 * @return string The name of the function.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 219,
        'endLine' => 223,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getNamespaceName' => 
      array (
        'name' => 'getNamespaceName',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets namespace name
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getnamespacename.php
 * @return string The namespace name.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 231,
        'endLine' => 235,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getNumberOfParameters' => 
      array (
        'name' => 'getNumberOfParameters',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'int',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets number of parameters
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getnumberofparameters.php
 * @return int The number of parameters.
 * @since 5.0
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 244,
        'endLine' => 248,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getNumberOfRequiredParameters' => 
      array (
        'name' => 'getNumberOfRequiredParameters',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'int',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets number of required parameters
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getnumberofrequiredparameters.php
 * @return int The number of required parameters.
 * @since 5.0
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 257,
        'endLine' => 261,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getParameters' => 
      array (
        'name' => 'getParameters',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets parameters
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getparameters.php
 * @return ReflectionParameter[] The parameters, as a ReflectionParameter objects.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 269,
        'endLine' => 273,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getReturnType' => 
      array (
        'name' => 'getReturnType',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'ReflectionType',
                  'isIdentifier' => false,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'isRepeated' => false,
            'arguments' => 
            array (
              0 => 
              array (
                'code' => '[\'7.1\' => \'ReflectionNamedType|null\', \'8.0\' => \'ReflectionNamedType|ReflectionUnionType|null\', \'8.1\' => \'ReflectionNamedType|ReflectionUnionType|ReflectionIntersectionType|null\']',
                'attributes' => 
                array (
                  'startLine' => 284,
                  'endLine' => 284,
                  'startTokenPos' => 596,
                  'startFilePos' => 10424,
                  'endTokenPos' => 616,
                  'endFilePos' => 10601,
                ),
              ),
              'default' => 
              array (
                'code' => '\'ReflectionType|null\'',
                'attributes' => 
                array (
                  'startLine' => 284,
                  'endLine' => 284,
                  'startTokenPos' => 622,
                  'startFilePos' => 10613,
                  'endTokenPos' => 622,
                  'endFilePos' => 10633,
                ),
              ),
            ),
          ),
          2 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets the specified return type of a function
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getreturntype.php
 * @return ReflectionType|null Returns a {@see ReflectionType} object if a
 * return type is specified, {@see null} otherwise.
 * @since 7.0
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 283,
        'endLine' => 288,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getShortName' => 
      array (
        'name' => 'getShortName',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets function short name
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getshortname.php
 * @return string The short name of the function.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 296,
        'endLine' => 300,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getStartLine' => 
      array (
        'name' => 'getStartLine',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'int',
                  'isIdentifier' => true,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'false',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets starting line number
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getstartline.php
 * @return int|false The starting line number or {@see false} if unknown.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 308,
        'endLine' => 312,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getStaticVariables' => 
      array (
        'name' => 'getStaticVariables',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Gets static variables
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.getstaticvariables.php
 * @return array An array of static variables.
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 320,
        'endLine' => 324,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'returnsReference' => 
      array (
        'name' => 'returnsReference',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Checks if returns reference
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.returnsreference.php
 * @return bool {@see true} if it returns a reference, otherwise {@see false}
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 332,
        'endLine' => 335,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'hasReturnType' => 
      array (
        'name' => 'hasReturnType',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * Checks if the function has a specified return type
 *
 * @link https://php.net/manual/en/reflectionfunctionabstract.hasreturntype.php
 * @return bool Returns {@see true} if the function is a specified return
 * type, otherwise {@see false}.
 * @since 7.0
 * @betterReflectionTentativeReturnType
 */',
        'startLine' => 345,
        'endLine' => 348,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getAttributes' => 
      array (
        'name' => 'getAttributes',
        'parameters' => 
        array (
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\\null',
              'attributes' => 
              array (
                'startLine' => 360,
                'endLine' => 360,
                'startTokenPos' => 784,
                'startFilePos' => 13409,
                'endTokenPos' => 784,
                'endFilePos' => 13412,
              ),
            ),
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
              'data' => 
              array (
                'types' => 
                array (
                  0 => 
                  array (
                    'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                    'data' => 
                    array (
                      'name' => 'string',
                      'isIdentifier' => true,
                    ),
                  ),
                  1 => 
                  array (
                    'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                    'data' => 
                    array (
                      'name' => 'null',
                      'isIdentifier' => true,
                    ),
                  ),
                ),
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 360,
            'endLine' => 360,
            'startColumn' => 39,
            'endColumn' => 58,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
          'flags' => 
          array (
            'name' => 'flags',
            'default' => 
            array (
              'code' => '0',
              'attributes' => 
              array (
                'startLine' => 360,
                'endLine' => 360,
                'startTokenPos' => 793,
                'startFilePos' => 13428,
                'endTokenPos' => 793,
                'endFilePos' => 13428,
              ),
            ),
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'int',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 360,
            'endLine' => 360,
            'startColumn' => 61,
            'endColumn' => 74,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/**
 * @template T
 *
 * Returns an array of function attributes.
 *
 * @param class-string<T>|null $name Name of an attribute class
 * @param int $flags Сriteria by which the attribute is searched.
 * @return ReflectionAttribute<T>[]
 * @since 8.0
 */',
        'startLine' => 359,
        'endLine' => 362,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getClosureUsedVariables' => 
      array (
        'name' => 'getClosureUsedVariables',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'isRepeated' => false,
            'arguments' => 
            array (
              0 => 
              array (
                'code' => '\'8.1\'',
                'attributes' => 
                array (
                  'startLine' => 363,
                  'endLine' => 363,
                  'startTokenPos' => 806,
                  'startFilePos' => 13527,
                  'endTokenPos' => 806,
                  'endFilePos' => 13531,
                ),
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => NULL,
        'startLine' => 363,
        'endLine' => 367,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'hasTentativeReturnType' => 
      array (
        'name' => 'hasTentativeReturnType',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'isRepeated' => false,
            'arguments' => 
            array (
              0 => 
              array (
                'code' => '\'8.1\'',
                'attributes' => 
                array (
                  'startLine' => 368,
                  'endLine' => 368,
                  'startTokenPos' => 832,
                  'startFilePos' => 13717,
                  'endTokenPos' => 832,
                  'endFilePos' => 13721,
                ),
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => NULL,
        'startLine' => 368,
        'endLine' => 372,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'getTentativeReturnType' => 
      array (
        'name' => 'getTentativeReturnType',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionUnionType',
          'data' => 
          array (
            'types' => 
            array (
              0 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'ReflectionType',
                  'isIdentifier' => false,
                ),
              ),
              1 => 
              array (
                'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
                'data' => 
                array (
                  'name' => 'null',
                  'isIdentifier' => true,
                ),
              ),
            ),
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'isRepeated' => false,
            'arguments' => 
            array (
              0 => 
              array (
                'code' => '\'8.1\'',
                'attributes' => 
                array (
                  'startLine' => 373,
                  'endLine' => 373,
                  'startTokenPos' => 858,
                  'startFilePos' => 13905,
                  'endTokenPos' => 858,
                  'endFilePos' => 13909,
                ),
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => NULL,
        'startLine' => 373,
        'endLine' => 377,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      'isStatic' => 
      array (
        'name' => 'isStatic',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'bool',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'isRepeated' => false,
            'arguments' => 
            array (
              0 => 
              array (
                'code' => '\'8.1\'',
                'attributes' => 
                array (
                  'startLine' => 379,
                  'endLine' => 379,
                  'startTokenPos' => 887,
                  'startFilePos' => 14157,
                  'endTokenPos' => 887,
                  'endFilePos' => 14161,
                ),
              ),
            ),
          ),
          1 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Pure',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
          2 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'isRepeated' => false,
            'arguments' => 
            array (
            ),
          ),
        ),
        'docComment' => '/** @betterReflectionTentativeReturnType */',
        'startLine' => 379,
        'endLine' => 384,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
      '__toString' => 
      array (
        'name' => '__toString',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
          0 => 
          array (
            'name' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'isRepeated' => false,
            'arguments' => 
            array (
              0 => 
              array (
                'code' => '[\'7.0\' => \'string\']',
                'attributes' => 
                array (
                  'startLine' => 385,
                  'endLine' => 385,
                  'startTokenPos' => 917,
                  'startFilePos' => 14378,
                  'endTokenPos' => 923,
                  'endFilePos' => 14396,
                ),
              ),
              'default' => 
              array (
                'code' => '\'\'',
                'attributes' => 
                array (
                  'startLine' => 385,
                  'endLine' => 385,
                  'startTokenPos' => 929,
                  'startFilePos' => 14408,
                  'endTokenPos' => 929,
                  'endFilePos' => 14409,
                ),
              ),
            ),
          ),
        ),
        'docComment' => NULL,
        'startLine' => 385,
        'endLine' => 388,
        'startColumn' => 9,
        'endColumn' => 9,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => NULL,
        'declaringClassName' => 'ReflectionFunctionAbstract',
        'implementingClassName' => 'ReflectionFunctionAbstract',
        'currentClassName' => 'ReflectionFunctionAbstract',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));