<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\tests\Feature\EditorialPublishingTest.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'fa0a3b0edd23de826d19f386d50c7abf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b2310c4c59d7472652e79e54564ab402' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'setUp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0b3769cd4ce96caec314de5d25c1a1c6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'testDraftIsInvisibleAndPublishedArticleSanitizesContent',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f49c1baaa194953731db505bf8cd79f1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'testArticlePublishingCriticalPathKeepsDraftsPrivateAndAudited',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0be94cd178202139c968cdbdca6bc85a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'testPaginationFiltersAndArticleTagRelationships',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b6b15ea02a3ca3609ec35f1fecbd17c4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'testRelatedArticlesUseCategoryOrSharedTags',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1834bf0578d9f43eba5da2b074d39ee5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'testFaqOrderingAndPublicationVisibility',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b4d0e468fe91516c7c80c816aab295e6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'articleInput',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0ce0f3895b5a87bf49c67419c7deda85' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Feature',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'insightrepository' => 'PerrymanFinance\\Repositories\\InsightRepository',
          'insightservice' => 'PerrymanFinance\\Services\\Insights\\InsightService',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
          'testcase' => 'PHPUnit\\Framework\\TestCase',
          'sqliteconnection' => 'Tests\\Support\\SqliteConnection',
        ),
         'className' => 'Tests\\Feature\\EditorialPublishingTest',
         'functionName' => 'createSchema',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\tests\\Feature\\EditorialPublishingTest.php' => '7b87713aa68e20f562281adbaf3840d754eb32078b057b9891c36103e5550562',
    ),
  ),
));