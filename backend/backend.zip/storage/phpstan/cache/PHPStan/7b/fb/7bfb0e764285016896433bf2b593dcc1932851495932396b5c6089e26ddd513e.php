<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\MockObject\Runtime\Interface\Stub.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PHPUnit\Framework\MockObject\Stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-33dad69469d99b64cf86563bc39fa8323fadf7a7f44870f15dd0e1bb1134a5e1',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PHPUnit\\Framework\\MockObject\\Stub',
        'filename' => 'D:/Perryman/backend/vendor/phpunit/phpunit/src/Framework/MockObject/Runtime/Interface/Stub.php',
      ),
    ),
    'namespace' => 'PHPUnit\\Framework\\MockObject',
    'name' => 'PHPUnit\\Framework\\MockObject\\Stub',
    'shortName' => 'Stub',
    'isInterface' => true,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * @method InvocationStubber method($constraint)
 *
 * @no-named-arguments Parameter names are not covered by the backward compatibility promise for PHPUnit
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 19,
    'endLine' => 21,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));