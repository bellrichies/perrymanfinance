<?php declare(strict_types = 1);

// osfsl-D:/Perryman/backend/vendor/composer/../phpmailer/phpmailer/src/PHPMailer.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PHPMailer\PHPMailer\PHPMailer
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-45599a196ae7944ee2dcd4f3d3da0ac4243513d346b2d77bbd15dbd0c37f7064-8.2.12-6.70.0.6',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'filename' => 'D:/Perryman/backend/vendor/composer/../phpmailer/phpmailer/src/PHPMailer.php',
      ),
    ),
    'namespace' => 'PHPMailer\\PHPMailer',
    'name' => 'PHPMailer\\PHPMailer\\PHPMailer',
    'shortName' => 'PHPMailer',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * PHPMailer - PHP email creation and transport class.
 *
 * @author Marcus Bointon (Synchro/coolbru) <phpmailer@synchromedia.co.uk>
 * @author Jim Jagielski (jimjag) <jimjag@gmail.com>
 * @author Andy Prevost (codeworxtech) <codeworxtech@users.sourceforge.net>
 * @author Brent R. Matzelle (original founder)
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 32,
    'endLine' => 5586,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
      'CHARSET_ASCII' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CHARSET_ASCII',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'us-ascii\'',
          'attributes' => 
          array (
            'startLine' => 34,
            'endLine' => 34,
            'startTokenPos' => 23,
            'startFilePos' => 1253,
            'endTokenPos' => 23,
            'endFilePos' => 1262,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 34,
        'endLine' => 34,
        'startColumn' => 5,
        'endColumn' => 37,
      ),
      'CHARSET_ISO88591' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CHARSET_ISO88591',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'iso-8859-1\'',
          'attributes' => 
          array (
            'startLine' => 35,
            'endLine' => 35,
            'startTokenPos' => 32,
            'startFilePos' => 1294,
            'endTokenPos' => 32,
            'endFilePos' => 1305,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 35,
        'endLine' => 35,
        'startColumn' => 5,
        'endColumn' => 42,
      ),
      'CHARSET_UTF8' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CHARSET_UTF8',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'utf-8\'',
          'attributes' => 
          array (
            'startLine' => 36,
            'endLine' => 36,
            'startTokenPos' => 41,
            'startFilePos' => 1333,
            'endTokenPos' => 41,
            'endFilePos' => 1339,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 36,
        'endLine' => 36,
        'startColumn' => 5,
        'endColumn' => 33,
      ),
      'CONTENT_TYPE_PLAINTEXT' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CONTENT_TYPE_PLAINTEXT',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'text/plain\'',
          'attributes' => 
          array (
            'startLine' => 38,
            'endLine' => 38,
            'startTokenPos' => 50,
            'startFilePos' => 1378,
            'endTokenPos' => 50,
            'endFilePos' => 1389,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 38,
        'endLine' => 38,
        'startColumn' => 5,
        'endColumn' => 48,
      ),
      'CONTENT_TYPE_TEXT_CALENDAR' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CONTENT_TYPE_TEXT_CALENDAR',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'text/calendar\'',
          'attributes' => 
          array (
            'startLine' => 39,
            'endLine' => 39,
            'startTokenPos' => 59,
            'startFilePos' => 1431,
            'endTokenPos' => 59,
            'endFilePos' => 1445,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 39,
        'endLine' => 39,
        'startColumn' => 5,
        'endColumn' => 55,
      ),
      'CONTENT_TYPE_TEXT_HTML' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CONTENT_TYPE_TEXT_HTML',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'text/html\'',
          'attributes' => 
          array (
            'startLine' => 40,
            'endLine' => 40,
            'startTokenPos' => 68,
            'startFilePos' => 1483,
            'endTokenPos' => 68,
            'endFilePos' => 1493,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 40,
        'endLine' => 40,
        'startColumn' => 5,
        'endColumn' => 47,
      ),
      'CONTENT_TYPE_MULTIPART_ALTERNATIVE' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CONTENT_TYPE_MULTIPART_ALTERNATIVE',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'multipart/alternative\'',
          'attributes' => 
          array (
            'startLine' => 41,
            'endLine' => 41,
            'startTokenPos' => 77,
            'startFilePos' => 1543,
            'endTokenPos' => 77,
            'endFilePos' => 1565,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 41,
        'endLine' => 41,
        'startColumn' => 5,
        'endColumn' => 71,
      ),
      'CONTENT_TYPE_MULTIPART_MIXED' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CONTENT_TYPE_MULTIPART_MIXED',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'multipart/mixed\'',
          'attributes' => 
          array (
            'startLine' => 42,
            'endLine' => 42,
            'startTokenPos' => 86,
            'startFilePos' => 1609,
            'endTokenPos' => 86,
            'endFilePos' => 1625,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 42,
        'endLine' => 42,
        'startColumn' => 5,
        'endColumn' => 59,
      ),
      'CONTENT_TYPE_MULTIPART_RELATED' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CONTENT_TYPE_MULTIPART_RELATED',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'multipart/related\'',
          'attributes' => 
          array (
            'startLine' => 43,
            'endLine' => 43,
            'startTokenPos' => 95,
            'startFilePos' => 1671,
            'endTokenPos' => 95,
            'endFilePos' => 1689,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 43,
        'endLine' => 43,
        'startColumn' => 5,
        'endColumn' => 63,
      ),
      'ENCODING_7BIT' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ENCODING_7BIT',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'7bit\'',
          'attributes' => 
          array (
            'startLine' => 45,
            'endLine' => 45,
            'startTokenPos' => 104,
            'startFilePos' => 1719,
            'endTokenPos' => 104,
            'endFilePos' => 1724,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 45,
        'endLine' => 45,
        'startColumn' => 5,
        'endColumn' => 33,
      ),
      'ENCODING_8BIT' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ENCODING_8BIT',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'8bit\'',
          'attributes' => 
          array (
            'startLine' => 46,
            'endLine' => 46,
            'startTokenPos' => 113,
            'startFilePos' => 1753,
            'endTokenPos' => 113,
            'endFilePos' => 1758,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 46,
        'endLine' => 46,
        'startColumn' => 5,
        'endColumn' => 33,
      ),
      'ENCODING_BASE64' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ENCODING_BASE64',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'base64\'',
          'attributes' => 
          array (
            'startLine' => 47,
            'endLine' => 47,
            'startTokenPos' => 122,
            'startFilePos' => 1789,
            'endTokenPos' => 122,
            'endFilePos' => 1796,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 47,
        'endLine' => 47,
        'startColumn' => 5,
        'endColumn' => 37,
      ),
      'ENCODING_BINARY' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ENCODING_BINARY',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'binary\'',
          'attributes' => 
          array (
            'startLine' => 48,
            'endLine' => 48,
            'startTokenPos' => 131,
            'startFilePos' => 1827,
            'endTokenPos' => 131,
            'endFilePos' => 1834,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 48,
        'endLine' => 48,
        'startColumn' => 5,
        'endColumn' => 37,
      ),
      'ENCODING_QUOTED_PRINTABLE' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ENCODING_QUOTED_PRINTABLE',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'quoted-printable\'',
          'attributes' => 
          array (
            'startLine' => 49,
            'endLine' => 49,
            'startTokenPos' => 140,
            'startFilePos' => 1875,
            'endTokenPos' => 140,
            'endFilePos' => 1892,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 49,
        'endLine' => 49,
        'startColumn' => 5,
        'endColumn' => 57,
      ),
      'ENCRYPTION_STARTTLS' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ENCRYPTION_STARTTLS',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'tls\'',
          'attributes' => 
          array (
            'startLine' => 51,
            'endLine' => 51,
            'startTokenPos' => 149,
            'startFilePos' => 1928,
            'endTokenPos' => 149,
            'endFilePos' => 1932,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 51,
        'endLine' => 51,
        'startColumn' => 5,
        'endColumn' => 38,
      ),
      'ENCRYPTION_SMTPS' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ENCRYPTION_SMTPS',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'ssl\'',
          'attributes' => 
          array (
            'startLine' => 52,
            'endLine' => 52,
            'startTokenPos' => 158,
            'startFilePos' => 1964,
            'endTokenPos' => 158,
            'endFilePos' => 1968,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 52,
        'endLine' => 52,
        'startColumn' => 5,
        'endColumn' => 35,
      ),
      'ICAL_METHOD_REQUEST' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_REQUEST',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'REQUEST\'',
          'attributes' => 
          array (
            'startLine' => 54,
            'endLine' => 54,
            'startTokenPos' => 167,
            'startFilePos' => 2004,
            'endTokenPos' => 167,
            'endFilePos' => 2012,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 54,
        'endLine' => 54,
        'startColumn' => 5,
        'endColumn' => 42,
      ),
      'ICAL_METHOD_PUBLISH' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_PUBLISH',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'PUBLISH\'',
          'attributes' => 
          array (
            'startLine' => 55,
            'endLine' => 55,
            'startTokenPos' => 176,
            'startFilePos' => 2047,
            'endTokenPos' => 176,
            'endFilePos' => 2055,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 55,
        'endLine' => 55,
        'startColumn' => 5,
        'endColumn' => 42,
      ),
      'ICAL_METHOD_REPLY' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_REPLY',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'REPLY\'',
          'attributes' => 
          array (
            'startLine' => 56,
            'endLine' => 56,
            'startTokenPos' => 185,
            'startFilePos' => 2088,
            'endTokenPos' => 185,
            'endFilePos' => 2094,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 56,
        'endLine' => 56,
        'startColumn' => 5,
        'endColumn' => 38,
      ),
      'ICAL_METHOD_ADD' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_ADD',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'ADD\'',
          'attributes' => 
          array (
            'startLine' => 57,
            'endLine' => 57,
            'startTokenPos' => 194,
            'startFilePos' => 2125,
            'endTokenPos' => 194,
            'endFilePos' => 2129,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 57,
        'endLine' => 57,
        'startColumn' => 5,
        'endColumn' => 34,
      ),
      'ICAL_METHOD_CANCEL' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_CANCEL',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'CANCEL\'',
          'attributes' => 
          array (
            'startLine' => 58,
            'endLine' => 58,
            'startTokenPos' => 203,
            'startFilePos' => 2163,
            'endTokenPos' => 203,
            'endFilePos' => 2170,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 58,
        'endLine' => 58,
        'startColumn' => 5,
        'endColumn' => 40,
      ),
      'ICAL_METHOD_REFRESH' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_REFRESH',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'REFRESH\'',
          'attributes' => 
          array (
            'startLine' => 59,
            'endLine' => 59,
            'startTokenPos' => 212,
            'startFilePos' => 2205,
            'endTokenPos' => 212,
            'endFilePos' => 2213,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 59,
        'endLine' => 59,
        'startColumn' => 5,
        'endColumn' => 42,
      ),
      'ICAL_METHOD_COUNTER' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_COUNTER',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'COUNTER\'',
          'attributes' => 
          array (
            'startLine' => 60,
            'endLine' => 60,
            'startTokenPos' => 221,
            'startFilePos' => 2248,
            'endTokenPos' => 221,
            'endFilePos' => 2256,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 60,
        'endLine' => 60,
        'startColumn' => 5,
        'endColumn' => 42,
      ),
      'ICAL_METHOD_DECLINECOUNTER' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ICAL_METHOD_DECLINECOUNTER',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'DECLINECOUNTER\'',
          'attributes' => 
          array (
            'startLine' => 61,
            'endLine' => 61,
            'startTokenPos' => 230,
            'startFilePos' => 2298,
            'endTokenPos' => 230,
            'endFilePos' => 2313,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 61,
        'endLine' => 61,
        'startColumn' => 5,
        'endColumn' => 56,
      ),
      'RFC822_DATE_FORMAT' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'RFC822_DATE_FORMAT',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'D, j M Y H:i:s O\'',
          'attributes' => 
          array (
            'startLine' => 62,
            'endLine' => 62,
            'startTokenPos' => 239,
            'startFilePos' => 2347,
            'endTokenPos' => 239,
            'endFilePos' => 2364,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 62,
        'endLine' => 62,
        'startColumn' => 5,
        'endColumn' => 50,
      ),
      'VERSION' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'VERSION',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'7.1.1\'',
          'attributes' => 
          array (
            'startLine' => 772,
            'endLine' => 772,
            'startTokenPos' => 1165,
            'startFilePos' => 19688,
            'endTokenPos' => 1165,
            'endFilePos' => 19694,
          ),
        ),
        'docComment' => '/**
 * The PHPMailer Version number.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 772,
        'endLine' => 772,
        'startColumn' => 5,
        'endColumn' => 28,
      ),
      'STOP_MESSAGE' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'STOP_MESSAGE',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '0',
          'attributes' => 
          array (
            'startLine' => 779,
            'endLine' => 779,
            'startTokenPos' => 1176,
            'startFilePos' => 19820,
            'endTokenPos' => 1176,
            'endFilePos' => 19820,
          ),
        ),
        'docComment' => '/**
 * Error severity: message only, continue processing.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 779,
        'endLine' => 779,
        'startColumn' => 5,
        'endColumn' => 27,
      ),
      'STOP_CONTINUE' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'STOP_CONTINUE',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '1',
          'attributes' => 
          array (
            'startLine' => 786,
            'endLine' => 786,
            'startTokenPos' => 1187,
            'startFilePos' => 19955,
            'endTokenPos' => 1187,
            'endFilePos' => 19955,
          ),
        ),
        'docComment' => '/**
 * Error severity: message, likely ok to continue processing.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 786,
        'endLine' => 786,
        'startColumn' => 5,
        'endColumn' => 28,
      ),
      'STOP_CRITICAL' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'STOP_CRITICAL',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '2',
          'attributes' => 
          array (
            'startLine' => 793,
            'endLine' => 793,
            'startTokenPos' => 1198,
            'startFilePos' => 20096,
            'endTokenPos' => 1198,
            'endFilePos' => 20096,
          ),
        ),
        'docComment' => '/**
 * Error severity: message, plus full stop, critical error reached.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 793,
        'endLine' => 793,
        'startColumn' => 5,
        'endColumn' => 28,
      ),
      'CRLF' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CRLF',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '"\\r\\n"',
          'attributes' => 
          array (
            'startLine' => 799,
            'endLine' => 799,
            'startTokenPos' => 1209,
            'startFilePos' => 20253,
            'endTokenPos' => 1209,
            'endFilePos' => 20258,
          ),
        ),
        'docComment' => '/**
 * The SMTP standard CRLF line break.
 * If you want to change line break format, change static::$LE, not this.
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 799,
        'endLine' => 799,
        'startColumn' => 5,
        'endColumn' => 24,
      ),
      'FWS' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'FWS',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\' \'',
          'attributes' => 
          array (
            'startLine' => 804,
            'endLine' => 804,
            'startTokenPos' => 1220,
            'startFilePos' => 20367,
            'endTokenPos' => 1220,
            'endFilePos' => 20369,
          ),
        ),
        'docComment' => '/**
 * "Folding White Space" a white space string used for line folding.
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 804,
        'endLine' => 804,
        'startColumn' => 5,
        'endColumn' => 20,
      ),
      'MAIL_MAX_LINE_LENGTH' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'MAIL_MAX_LINE_LENGTH',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '63',
          'attributes' => 
          array (
            'startLine' => 821,
            'endLine' => 821,
            'startTokenPos' => 1246,
            'startFilePos' => 20762,
            'endTokenPos' => 1246,
            'endFilePos' => 20763,
          ),
        ),
        'docComment' => '/**
 * The maximum line length supported by mail().
 *
 * Background: mail() will sometimes corrupt messages
 * with headers longer than 65 chars, see #818.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 821,
        'endLine' => 821,
        'startColumn' => 5,
        'endColumn' => 36,
      ),
      'MAX_LINE_LENGTH' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'MAX_LINE_LENGTH',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '998',
          'attributes' => 
          array (
            'startLine' => 828,
            'endLine' => 828,
            'startTokenPos' => 1257,
            'startFilePos' => 20900,
            'endTokenPos' => 1257,
            'endFilePos' => 20902,
          ),
        ),
        'docComment' => '/**
 * The maximum line length allowed by RFC 2822 section 2.1.1.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 828,
        'endLine' => 828,
        'startColumn' => 5,
        'endColumn' => 32,
      ),
      'STD_LINE_LENGTH' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'STD_LINE_LENGTH',
        'modifiers' => 1,
        'type' => NULL,
        'value' => 
        array (
          'code' => '76',
          'attributes' => 
          array (
            'startLine' => 838,
            'endLine' => 838,
            'startTokenPos' => 1268,
            'startFilePos' => 21227,
            'endTokenPos' => 1268,
            'endFilePos' => 21228,
          ),
        ),
        'docComment' => '/**
 * The lower maximum line length allowed by RFC 2822 section 2.1.1.
 * This length does NOT include the line break
 * 76 means that lines will be 77 or 78 chars depending on whether
 * the line break format is LF or CRLF; both are valid.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 838,
        'endLine' => 838,
        'startColumn' => 5,
        'endColumn' => 31,
      ),
    ),
    'immediateProperties' => 
    array (
      'Priority' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Priority',
        'modifiers' => 1,
        'type' => NULL,
        'default' => NULL,
        'docComment' => '/**
 * Email priority.
 * Options: null (default), 1 = High, 3 = Normal, 5 = low.
 * When null, the header is not set at all.
 *
 * @var int|null
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 71,
        'endLine' => 71,
        'startColumn' => 5,
        'endColumn' => 21,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'CharSet' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CharSet',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'self::CHARSET_ISO88591',
          'attributes' => 
          array (
            'startLine' => 78,
            'endLine' => 78,
            'startTokenPos' => 257,
            'startFilePos' => 2674,
            'endTokenPos' => 259,
            'endFilePos' => 2695,
          ),
        ),
        'docComment' => '/**
 * The character set of the message.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 78,
        'endLine' => 78,
        'startColumn' => 5,
        'endColumn' => 45,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'ContentType' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ContentType',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'self::CONTENT_TYPE_PLAINTEXT',
          'attributes' => 
          array (
            'startLine' => 85,
            'endLine' => 85,
            'startTokenPos' => 270,
            'startFilePos' => 2812,
            'endTokenPos' => 272,
            'endFilePos' => 2839,
          ),
        ),
        'docComment' => '/**
 * The MIME Content-Type of the message.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 85,
        'endLine' => 85,
        'startColumn' => 5,
        'endColumn' => 55,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Encoding' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Encoding',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'self::ENCODING_8BIT',
          'attributes' => 
          array (
            'startLine' => 93,
            'endLine' => 93,
            'startTokenPos' => 283,
            'startFilePos' => 3013,
            'endTokenPos' => 285,
            'endFilePos' => 3031,
          ),
        ),
        'docComment' => '/**
 * The message encoding.
 * Options: "8bit", "7bit", "binary", "base64", and "quoted-printable".
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 93,
        'endLine' => 93,
        'startColumn' => 5,
        'endColumn' => 43,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'ErrorInfo' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ErrorInfo',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 100,
            'endLine' => 100,
            'startTokenPos' => 296,
            'startFilePos' => 3152,
            'endTokenPos' => 296,
            'endFilePos' => 3153,
          ),
        ),
        'docComment' => '/**
 * Holds the most recent mailer error message.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 100,
        'endLine' => 100,
        'startColumn' => 5,
        'endColumn' => 27,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'From' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'From',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 107,
            'endLine' => 107,
            'startTokenPos' => 307,
            'startFilePos' => 3265,
            'endTokenPos' => 307,
            'endFilePos' => 3266,
          ),
        ),
        'docComment' => '/**
 * The From email address for the message.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 107,
        'endLine' => 107,
        'startColumn' => 5,
        'endColumn' => 22,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'FromName' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'FromName',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 114,
            'endLine' => 114,
            'startTokenPos' => 318,
            'startFilePos' => 3372,
            'endTokenPos' => 318,
            'endFilePos' => 3373,
          ),
        ),
        'docComment' => '/**
 * The From name of the message.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 114,
        'endLine' => 114,
        'startColumn' => 5,
        'endColumn' => 26,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Sender' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Sender',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 124,
            'endLine' => 124,
            'startTokenPos' => 329,
            'startFilePos' => 3713,
            'endTokenPos' => 329,
            'endFilePos' => 3714,
          ),
        ),
        'docComment' => '/**
 * The envelope sender of the message.
 * This will usually be turned into a Return-Path header by the receiver,
 * and is the address that bounces will be sent to.
 * If not empty, will be passed via `-f` to sendmail or as the \'MAIL FROM\' value over SMTP.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 124,
        'endLine' => 124,
        'startColumn' => 5,
        'endColumn' => 24,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Subject' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Subject',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 131,
            'endLine' => 131,
            'startTokenPos' => 340,
            'startFilePos' => 3817,
            'endTokenPos' => 340,
            'endFilePos' => 3818,
          ),
        ),
        'docComment' => '/**
 * The Subject of the message.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 131,
        'endLine' => 131,
        'startColumn' => 5,
        'endColumn' => 25,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Body' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Body',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 139,
            'endLine' => 139,
            'startTokenPos' => 351,
            'startFilePos' => 3965,
            'endTokenPos' => 351,
            'endFilePos' => 3966,
          ),
        ),
        'docComment' => '/**
 * An HTML or plain text message body.
 * If HTML then call isHTML(true).
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 139,
        'endLine' => 139,
        'startColumn' => 5,
        'endColumn' => 22,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'AltBody' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'AltBody',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 149,
            'endLine' => 149,
            'startTokenPos' => 362,
            'startFilePos' => 4245,
            'endTokenPos' => 362,
            'endFilePos' => 4246,
          ),
        ),
        'docComment' => '/**
 * The plain-text message body.
 * This body can be read by mail clients that do not have HTML email
 * capability such as mutt & Eudora.
 * Clients that can read HTML will view the normal Body.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 149,
        'endLine' => 149,
        'startColumn' => 5,
        'endColumn' => 25,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Ical' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Ical',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 160,
            'endLine' => 160,
            'startTokenPos' => 373,
            'startFilePos' => 4551,
            'endTokenPos' => 373,
            'endFilePos' => 4552,
          ),
        ),
        'docComment' => '/**
 * An iCal message part body.
 * Only supported in simple alt or alt_inline message types
 * To generate iCal event structures, use classes like EasyPeasyICS or iCalcreator.
 *
 * @see https://kigkonsult.se/iCalcreator/
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 160,
        'endLine' => 160,
        'startColumn' => 5,
        'endColumn' => 22,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'IcalMethods' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'IcalMethods',
        'modifiers' => 18,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[self::ICAL_METHOD_REQUEST, self::ICAL_METHOD_PUBLISH, self::ICAL_METHOD_REPLY, self::ICAL_METHOD_ADD, self::ICAL_METHOD_CANCEL, self::ICAL_METHOD_REFRESH, self::ICAL_METHOD_COUNTER, self::ICAL_METHOD_DECLINECOUNTER]',
          'attributes' => 
          array (
            'startLine' => 167,
            'endLine' => 176,
            'startTokenPos' => 386,
            'startFilePos' => 4706,
            'endTokenPos' => 428,
            'endFilePos' => 4992,
          ),
        ),
        'docComment' => '/**
 * Value-array of "method" in Content-Type header "text/calendar"
 *
 * @var string[]
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 167,
        'endLine' => 176,
        'startColumn' => 5,
        'endColumn' => 6,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'MIMEBody' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'MIMEBody',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 183,
            'endLine' => 183,
            'startTokenPos' => 439,
            'startFilePos' => 5112,
            'endTokenPos' => 439,
            'endFilePos' => 5113,
          ),
        ),
        'docComment' => '/**
 * The complete compiled MIME message body.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 183,
        'endLine' => 183,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'MIMEHeader' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'MIMEHeader',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 190,
            'endLine' => 190,
            'startTokenPos' => 450,
            'startFilePos' => 5238,
            'endTokenPos' => 450,
            'endFilePos' => 5239,
          ),
        ),
        'docComment' => '/**
 * The complete compiled MIME message headers.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 190,
        'endLine' => 190,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'mailHeader' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'mailHeader',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 197,
            'endLine' => 197,
            'startTokenPos' => 461,
            'startFilePos' => 5371,
            'endTokenPos' => 461,
            'endFilePos' => 5372,
          ),
        ),
        'docComment' => '/**
 * Extra headers that createHeader() doesn\'t fold in.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 197,
        'endLine' => 197,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'WordWrap' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'WordWrap',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '0',
          'attributes' => 
          array (
            'startLine' => 207,
            'endLine' => 207,
            'startTokenPos' => 472,
            'startFilePos' => 5634,
            'endTokenPos' => 472,
            'endFilePos' => 5634,
          ),
        ),
        'docComment' => '/**
 * Word-wrap the message body to this number of chars.
 * Set to 0 to not wrap. A useful value here is 78, for RFC2822 section 2.1.1 compliance.
 *
 * @see static::STD_LINE_LENGTH
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 207,
        'endLine' => 207,
        'startColumn' => 5,
        'endColumn' => 25,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Mailer' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Mailer',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'mail\'',
          'attributes' => 
          array (
            'startLine' => 215,
            'endLine' => 215,
            'startTokenPos' => 483,
            'startFilePos' => 5789,
            'endTokenPos' => 483,
            'endFilePos' => 5794,
          ),
        ),
        'docComment' => '/**
 * Which method to use to send mail.
 * Options: "mail", "sendmail", or "smtp".
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 215,
        'endLine' => 215,
        'startColumn' => 5,
        'endColumn' => 28,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Sendmail' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Sendmail',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'/usr/sbin/sendmail\'',
          'attributes' => 
          array (
            'startLine' => 222,
            'endLine' => 222,
            'startTokenPos' => 494,
            'startFilePos' => 5904,
            'endTokenPos' => 494,
            'endFilePos' => 5923,
          ),
        ),
        'docComment' => '/**
 * The path to the sendmail program.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 222,
        'endLine' => 222,
        'startColumn' => 5,
        'endColumn' => 44,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'UseSendmailOptions' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'UseSendmailOptions',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'true',
          'attributes' => 
          array (
            'startLine' => 230,
            'endLine' => 230,
            'startTokenPos' => 505,
            'startFilePos' => 6115,
            'endTokenPos' => 505,
            'endFilePos' => 6118,
          ),
        ),
        'docComment' => '/**
 * Whether mail() uses a fully sendmail-compatible MTA.
 * One which supports sendmail\'s "-oi -f" options.
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 230,
        'endLine' => 230,
        'startColumn' => 5,
        'endColumn' => 38,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'ConfirmReadingTo' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ConfirmReadingTo',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 237,
            'endLine' => 237,
            'startTokenPos' => 516,
            'startFilePos' => 6295,
            'endTokenPos' => 516,
            'endFilePos' => 6296,
          ),
        ),
        'docComment' => '/**
 * The email address that a reading confirmation should be sent to, also known as read receipt.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 237,
        'endLine' => 237,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Hostname' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Hostname',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 249,
            'endLine' => 249,
            'startTokenPos' => 527,
            'startFilePos' => 6653,
            'endTokenPos' => 527,
            'endFilePos' => 6654,
          ),
        ),
        'docComment' => '/**
 * The hostname to use in the Message-ID header and as default HELO string.
 * If empty, PHPMailer attempts to find one with, in order,
 * $_SERVER[\'SERVER_NAME\'], gethostname(), php_uname(\'n\'), or the value
 * \'localhost.localdomain\'.
 *
 * @see PHPMailer::$Helo
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 249,
        'endLine' => 249,
        'startColumn' => 5,
        'endColumn' => 26,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'MessageID' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'MessageID',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 261,
            'endLine' => 261,
            'startTokenPos' => 538,
            'startFilePos' => 7033,
            'endTokenPos' => 538,
            'endFilePos' => 7034,
          ),
        ),
        'docComment' => '/**
 * An ID to be used in the Message-ID header.
 * If empty, a unique id will be generated.
 * You can set your own, but it must be in the format "<id@domain>",
 * as defined in RFC5322 section 3.6.4 or it will be ignored.
 *
 * @see https://www.rfc-editor.org/rfc/rfc5322#section-3.6.4
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 261,
        'endLine' => 261,
        'startColumn' => 5,
        'endColumn' => 27,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'MessageDate' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'MessageDate',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 269,
            'endLine' => 269,
            'startTokenPos' => 549,
            'startFilePos' => 7210,
            'endTokenPos' => 549,
            'endFilePos' => 7211,
          ),
        ),
        'docComment' => '/**
 * The message Date to be used in the Date header.
 * If empty, the current date will be added.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 269,
        'endLine' => 269,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Host' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Host',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'localhost\'',
          'attributes' => 
          array (
            'startLine' => 283,
            'endLine' => 283,
            'startTokenPos' => 560,
            'startFilePos' => 7698,
            'endTokenPos' => 560,
            'endFilePos' => 7708,
          ),
        ),
        'docComment' => '/**
 * SMTP hosts.
 * Either a single hostname or multiple semicolon-delimited hostnames.
 * You can also specify a different port
 * for each host by using this format: [hostname:port]
 * (e.g. "smtp1.example.com:25;smtp2.example.com").
 * You can also specify encryption type, for example:
 * (e.g. "tls://smtp1.example.com:587;ssl://smtp2.example.com:465").
 * Hosts will be tried in order.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 283,
        'endLine' => 283,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Port' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Port',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '25',
          'attributes' => 
          array (
            'startLine' => 290,
            'endLine' => 290,
            'startTokenPos' => 571,
            'startFilePos' => 7807,
            'endTokenPos' => 571,
            'endFilePos' => 7808,
          ),
        ),
        'docComment' => '/**
 * The default SMTP server port.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 290,
        'endLine' => 290,
        'startColumn' => 5,
        'endColumn' => 22,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Helo' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Helo',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 301,
            'endLine' => 301,
            'startTokenPos' => 582,
            'startFilePos' => 8116,
            'endTokenPos' => 582,
            'endFilePos' => 8117,
          ),
        ),
        'docComment' => '/**
 * The SMTP HELO/EHLO name used for the SMTP connection.
 * Default is $Hostname. If $Hostname is empty, PHPMailer attempts to find
 * one with the same method described above for $Hostname.
 *
 * @see PHPMailer::$Hostname
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 301,
        'endLine' => 301,
        'startColumn' => 5,
        'endColumn' => 22,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SMTPSecure' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SMTPSecure',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 309,
            'endLine' => 309,
            'startTokenPos' => 593,
            'startFilePos' => 8328,
            'endTokenPos' => 593,
            'endFilePos' => 8329,
          ),
        ),
        'docComment' => '/**
 * What kind of encryption to use on the SMTP connection.
 * Options: \'\', static::ENCRYPTION_STARTTLS, or static::ENCRYPTION_SMTPS.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 309,
        'endLine' => 309,
        'startColumn' => 5,
        'endColumn' => 28,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SMTPAutoTLS' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SMTPAutoTLS',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'true',
          'attributes' => 
          array (
            'startLine' => 318,
            'endLine' => 318,
            'startTokenPos' => 604,
            'startFilePos' => 8618,
            'endTokenPos' => 604,
            'endFilePos' => 8621,
          ),
        ),
        'docComment' => '/**
 * Whether to enable TLS encryption automatically if a server supports it,
 * even if `SMTPSecure` is not set to \'tls\'.
 * Be aware that in PHP >= 5.6 this requires that the server\'s certificates are valid.
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 318,
        'endLine' => 318,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SMTPAuth' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SMTPAuth',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 329,
            'endLine' => 329,
            'startTokenPos' => 615,
            'startFilePos' => 8854,
            'endTokenPos' => 615,
            'endFilePos' => 8858,
          ),
        ),
        'docComment' => '/**
 * Whether to use SMTP authentication.
 * Uses the Username and Password properties.
 *
 * @see PHPMailer::$Username
 * @see PHPMailer::$Password
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 329,
        'endLine' => 329,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SMTPOptions' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SMTPOptions',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 336,
            'endLine' => 336,
            'startTokenPos' => 626,
            'startFilePos' => 9008,
            'endTokenPos' => 627,
            'endFilePos' => 9009,
          ),
        ),
        'docComment' => '/**
 * Options array passed to stream_context_create when connecting via SMTP.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 336,
        'endLine' => 336,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Username' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Username',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 343,
            'endLine' => 343,
            'startTokenPos' => 638,
            'startFilePos' => 9100,
            'endTokenPos' => 638,
            'endFilePos' => 9101,
          ),
        ),
        'docComment' => '/**
 * SMTP username.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 343,
        'endLine' => 343,
        'startColumn' => 5,
        'endColumn' => 26,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Password' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Password',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 350,
            'endLine' => 350,
            'startTokenPos' => 649,
            'startFilePos' => 9192,
            'endTokenPos' => 649,
            'endFilePos' => 9193,
          ),
        ),
        'docComment' => '/**
 * SMTP password.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 350,
        'endLine' => 350,
        'startColumn' => 5,
        'endColumn' => 26,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'AuthType' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'AuthType',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 358,
            'endLine' => 358,
            'startTokenPos' => 660,
            'startFilePos' => 9437,
            'endTokenPos' => 660,
            'endFilePos' => 9438,
          ),
        ),
        'docComment' => '/**
 * SMTP authentication type. Options are CRAM-MD5, LOGIN, PLAIN, XOAUTH2.
 * If not specified, the first one from that list that the server supports will be selected.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 358,
        'endLine' => 358,
        'startColumn' => 5,
        'endColumn' => 26,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SMTPXClient' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SMTPXClient',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 365,
            'endLine' => 365,
            'startTokenPos' => 671,
            'startFilePos' => 9555,
            'endTokenPos' => 672,
            'endFilePos' => 9556,
          ),
        ),
        'docComment' => '/**
 * SMTP SMTPXClient command attributes
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 365,
        'endLine' => 365,
        'startColumn' => 5,
        'endColumn' => 32,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'oauth' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'oauth',
        'modifiers' => 2,
        'type' => NULL,
        'default' => NULL,
        'docComment' => '/**
 * An implementation of the PHPMailer OAuthTokenProvider interface.
 *
 * @var OAuthTokenProvider
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 372,
        'endLine' => 372,
        'startColumn' => 5,
        'endColumn' => 21,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Timeout' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Timeout',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '300',
          'attributes' => 
          array (
            'startLine' => 380,
            'endLine' => 380,
            'startTokenPos' => 690,
            'startFilePos' => 9883,
            'endTokenPos' => 690,
            'endFilePos' => 9885,
          ),
        ),
        'docComment' => '/**
 * The SMTP server timeout in seconds.
 * Default of 5 minutes (300sec) is from RFC2821 section 4.5.3.2.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 380,
        'endLine' => 380,
        'startColumn' => 5,
        'endColumn' => 26,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'dsn' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'dsn',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 393,
            'endLine' => 393,
            'startTokenPos' => 701,
            'startFilePos' => 10544,
            'endTokenPos' => 701,
            'endFilePos' => 10545,
          ),
        ),
        'docComment' => '/**
 * Comma separated list of DSN notifications
 * \'NEVER\' under no circumstances a DSN must be returned to the sender.
 *         If you use NEVER all other notifications will be ignored.
 * \'SUCCESS\' will notify you when your mail has arrived at its destination.
 * \'FAILURE\' will arrive if an error occurred during delivery.
 * \'DELAY\'   will notify you if there is an unusual delay in delivery, but the actual
 *           delivery\'s outcome (success or failure) is not yet decided.
 *
 * @see https://www.rfc-editor.org/rfc/rfc3461.html#section-4.1 for more information about NOTIFY
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 393,
        'endLine' => 393,
        'startColumn' => 5,
        'endColumn' => 21,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SMTPDebug' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SMTPDebug',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '0',
          'attributes' => 
          array (
            'startLine' => 409,
            'endLine' => 409,
            'startTokenPos' => 712,
            'startFilePos' => 11020,
            'endTokenPos' => 712,
            'endFilePos' => 11020,
          ),
        ),
        'docComment' => '/**
 * SMTP class debug output mode.
 * Debug output level.
 * Options:
 * @see SMTP::DEBUG_OFF: No output
 * @see SMTP::DEBUG_CLIENT: Client messages
 * @see SMTP::DEBUG_SERVER: Client and server messages
 * @see SMTP::DEBUG_CONNECTION: As SERVER plus connection status
 * @see SMTP::DEBUG_LOWLEVEL: Noisy, low-level data output, rarely needed
 *
 * @see SMTP::$do_debug
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 409,
        'endLine' => 409,
        'startColumn' => 5,
        'endColumn' => 26,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'Debugoutput' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'Debugoutput',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'echo\'',
          'attributes' => 
          array (
            'startLine' => 435,
            'endLine' => 435,
            'startTokenPos' => 723,
            'startFilePos' => 11993,
            'endTokenPos' => 723,
            'endFilePos' => 11998,
          ),
        ),
        'docComment' => '/**
 * How to handle debug output.
 * Options:
 * * `echo` Output plain-text as-is, appropriate for CLI
 * * `html` Output escaped, line breaks converted to `<br>`, appropriate for browser output
 * * `error_log` Output to error log as configured in php.ini
 * By default PHPMailer will use `echo` if run from a `cli` or `cli-server` SAPI, `html` otherwise.
 * Alternatively, you can provide a callable expecting two params: a message string and the debug level:
 *
 * ```php
 * $mail->Debugoutput = function($str, $level) {echo "debug level $level; message: $str";};
 * ```
 *
 * Alternatively, you can pass in an instance of a PSR-3 compatible logger, though only `debug`
 * level output is used:
 *
 * ```php
 * $mail->Debugoutput = new myPsr3Logger;
 * ```
 *
 * @see SMTP::$Debugoutput
 *
 * @var string|callable|\\Psr\\Log\\LoggerInterface
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 435,
        'endLine' => 435,
        'startColumn' => 5,
        'endColumn' => 33,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SMTPKeepAlive' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SMTPKeepAlive',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 446,
            'endLine' => 446,
            'startTokenPos' => 734,
            'startFilePos' => 12451,
            'endTokenPos' => 734,
            'endFilePos' => 12455,
          ),
        ),
        'docComment' => '/**
 * Whether to keep the SMTP connection open after each message.
 * If this is set to true then the connection will remain open after a send,
 * and closing the connection will require an explicit call to smtpClose().
 * It\'s a good idea to use this if you are sending multiple messages as it reduces overhead.
 * See the mailing list example for how to use it.
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 446,
        'endLine' => 446,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SingleTo' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SingleTo',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 457,
            'endLine' => 457,
            'startTokenPos' => 745,
            'startFilePos' => 12775,
            'endTokenPos' => 745,
            'endFilePos' => 12779,
          ),
        ),
        'docComment' => '/**
 * Whether to split multiple to addresses into multiple messages
 * or send them all in one message.
 * Only supported in `mail` and `sendmail` transports, not in SMTP.
 *
 * @var bool
 *
 * @deprecated 6.0.0 PHPMailer isn\'t a mailing list manager!
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 457,
        'endLine' => 457,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'SingleToArray' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'SingleToArray',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 464,
            'endLine' => 464,
            'startTokenPos' => 756,
            'startFilePos' => 12910,
            'endTokenPos' => 757,
            'endFilePos' => 12911,
          ),
        ),
        'docComment' => '/**
 * Storage for addresses when SingleTo is enabled.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 464,
        'endLine' => 464,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'do_verp' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'do_verp',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 475,
            'endLine' => 475,
            'startTokenPos' => 768,
            'startFilePos' => 13224,
            'endTokenPos' => 768,
            'endFilePos' => 13228,
          ),
        ),
        'docComment' => '/**
 * Whether to generate VERP addresses on send.
 * Only applicable when sending via SMTP.
 *
 * @see https://en.wikipedia.org/wiki/Variable_envelope_return_path
 * @see https://www.postfix.org/VERP_README.html Postfix VERP info
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 475,
        'endLine' => 475,
        'startColumn' => 5,
        'endColumn' => 28,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'AllowEmpty' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'AllowEmpty',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 482,
            'endLine' => 482,
            'startTokenPos' => 779,
            'startFilePos' => 13358,
            'endTokenPos' => 779,
            'endFilePos' => 13362,
          ),
        ),
        'docComment' => '/**
 * Whether to allow sending messages with an empty body.
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 482,
        'endLine' => 482,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_selector' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_selector',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 489,
            'endLine' => 489,
            'startTokenPos' => 790,
            'startFilePos' => 13458,
            'endTokenPos' => 790,
            'endFilePos' => 13459,
          ),
        ),
        'docComment' => '/**
 * DKIM selector.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 489,
        'endLine' => 489,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_identity' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_identity',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 497,
            'endLine' => 497,
            'startTokenPos' => 801,
            'startFilePos' => 13621,
            'endTokenPos' => 801,
            'endFilePos' => 13622,
          ),
        ),
        'docComment' => '/**
 * DKIM Identity.
 * Usually the email address used as the source of the email.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 497,
        'endLine' => 497,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_passphrase' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_passphrase',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 505,
            'endLine' => 505,
            'startTokenPos' => 812,
            'startFilePos' => 13760,
            'endTokenPos' => 812,
            'endFilePos' => 13761,
          ),
        ),
        'docComment' => '/**
 * DKIM passphrase.
 * Used if your key is encrypted.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 505,
        'endLine' => 505,
        'startColumn' => 5,
        'endColumn' => 33,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_domain' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_domain',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 514,
            'endLine' => 514,
            'startTokenPos' => 823,
            'startFilePos' => 13903,
            'endTokenPos' => 823,
            'endFilePos' => 13904,
          ),
        ),
        'docComment' => '/**
 * DKIM signing domain name.
 *
 * @example \'example.com\'
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 514,
        'endLine' => 514,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_copyHeaderFields' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_copyHeaderFields',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'true',
          'attributes' => 
          array (
            'startLine' => 521,
            'endLine' => 521,
            'startTokenPos' => 834,
            'startFilePos' => 14041,
            'endTokenPos' => 834,
            'endFilePos' => 14044,
          ),
        ),
        'docComment' => '/**
 * DKIM Copy header field values for diagnostic use.
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 521,
        'endLine' => 521,
        'startColumn' => 5,
        'endColumn' => 41,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_extraHeaders' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_extraHeaders',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 530,
            'endLine' => 530,
            'startTokenPos' => 845,
            'startFilePos' => 14213,
            'endTokenPos' => 846,
            'endFilePos' => 14214,
          ),
        ),
        'docComment' => '/**
 * DKIM Extra signing headers.
 *
 * @example [\'List-Unsubscribe\', \'List-Help\']
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 530,
        'endLine' => 530,
        'startColumn' => 5,
        'endColumn' => 35,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_private' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_private',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 537,
            'endLine' => 537,
            'startTokenPos' => 857,
            'startFilePos' => 14322,
            'endTokenPos' => 857,
            'endFilePos' => 14323,
          ),
        ),
        'docComment' => '/**
 * DKIM private key file path.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 537,
        'endLine' => 537,
        'startColumn' => 5,
        'endColumn' => 30,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'DKIM_private_string' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'DKIM_private_string',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 546,
            'endLine' => 546,
            'startTokenPos' => 868,
            'startFilePos' => 14496,
            'endTokenPos' => 868,
            'endFilePos' => 14497,
          ),
        ),
        'docComment' => '/**
 * DKIM private key string.
 *
 * If set, takes precedence over `$DKIM_private`.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 546,
        'endLine' => 546,
        'startColumn' => 5,
        'endColumn' => 37,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'action_function' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'action_function',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 569,
            'endLine' => 569,
            'startTokenPos' => 879,
            'startFilePos' => 15386,
            'endTokenPos' => 879,
            'endFilePos' => 15387,
          ),
        ),
        'docComment' => '/**
 * Callback Action function name.
 *
 * The function that handles the result of the send email action.
 * It is called out by send() for each email sent.
 *
 * Value can be any php callable: https://www.php.net/is_callable
 *
 * Parameters:
 *   bool $result           result of the send action
 *   array   $to            email addresses of the recipients
 *   array   $cc            cc email addresses
 *   array   $bcc           bcc email addresses
 *   string  $subject       the subject
 *   string  $body          the email body
 *   string  $from          email address of sender
 *   string  $extra         extra information of possible use
 *                          \'smtp_transaction_id\' => last smtp transaction id
 *
 * @var callable|callable-string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 569,
        'endLine' => 569,
        'startColumn' => 5,
        'endColumn' => 33,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'XMailer' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'XMailer',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 577,
            'endLine' => 577,
            'startTokenPos' => 890,
            'startFilePos' => 15604,
            'endTokenPos' => 890,
            'endFilePos' => 15605,
          ),
        ),
        'docComment' => '/**
 * What to put in the X-Mailer header.
 * Options: An empty string for PHPMailer default, whitespace/null for none, or a string to use.
 *
 * @var string|null
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 577,
        'endLine' => 577,
        'startColumn' => 5,
        'endColumn' => 25,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'validator' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'validator',
        'modifiers' => 17,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'php\'',
          'attributes' => 
          array (
            'startLine' => 592,
            'endLine' => 592,
            'startTokenPos' => 903,
            'startFilePos' => 16203,
            'endTokenPos' => 903,
            'endFilePos' => 16207,
          ),
        ),
        'docComment' => '/**
 * Which validator to use by default when validating email addresses.
 * May be a callable to inject your own validator, but there are several built-in validators.
 * The default validator uses PHP\'s FILTER_VALIDATE_EMAIL filter_var option.
 *
 * If CharSet is UTF8, the validator is left at the default value,
 * and you send to addresses that use non-ASCII local parts, then
 * PHPMailer automatically changes to the \'eai\' validator.
 *
 * @see PHPMailer::validateAddress()
 *
 * @var string|callable
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 592,
        'endLine' => 592,
        'startColumn' => 5,
        'endColumn' => 37,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'smtp' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'smtp',
        'modifiers' => 2,
        'type' => NULL,
        'default' => NULL,
        'docComment' => '/**
 * An instance of the SMTP sender class.
 *
 * @var SMTP
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 599,
        'endLine' => 599,
        'startColumn' => 5,
        'endColumn' => 20,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'to' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'to',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 606,
            'endLine' => 606,
            'startTokenPos' => 921,
            'startFilePos' => 16425,
            'endTokenPos' => 922,
            'endFilePos' => 16426,
          ),
        ),
        'docComment' => '/**
 * The array of \'to\' names and addresses.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 606,
        'endLine' => 606,
        'startColumn' => 5,
        'endColumn' => 23,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'cc' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'cc',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 613,
            'endLine' => 613,
            'startTokenPos' => 933,
            'startFilePos' => 16537,
            'endTokenPos' => 934,
            'endFilePos' => 16538,
          ),
        ),
        'docComment' => '/**
 * The array of \'cc\' names and addresses.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 613,
        'endLine' => 613,
        'startColumn' => 5,
        'endColumn' => 23,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'bcc' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'bcc',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 620,
            'endLine' => 620,
            'startTokenPos' => 945,
            'startFilePos' => 16651,
            'endTokenPos' => 946,
            'endFilePos' => 16652,
          ),
        ),
        'docComment' => '/**
 * The array of \'bcc\' names and addresses.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 620,
        'endLine' => 620,
        'startColumn' => 5,
        'endColumn' => 24,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'ReplyTo' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ReplyTo',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 627,
            'endLine' => 627,
            'startTokenPos' => 957,
            'startFilePos' => 16772,
            'endTokenPos' => 958,
            'endFilePos' => 16773,
          ),
        ),
        'docComment' => '/**
 * The array of reply-to names and addresses.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 627,
        'endLine' => 627,
        'startColumn' => 5,
        'endColumn' => 28,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'all_recipients' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'all_recipients',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 639,
            'endLine' => 639,
            'startTokenPos' => 969,
            'startFilePos' => 17021,
            'endTokenPos' => 970,
            'endFilePos' => 17022,
          ),
        ),
        'docComment' => '/**
 * An array of all kinds of addresses.
 * Includes all of $to, $cc, $bcc.
 *
 * @see PHPMailer::$to
 * @see PHPMailer::$cc
 * @see PHPMailer::$bcc
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 639,
        'endLine' => 639,
        'startColumn' => 5,
        'endColumn' => 35,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'RecipientsQueue' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'RecipientsQueue',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 654,
            'endLine' => 654,
            'startTokenPos' => 981,
            'startFilePos' => 17461,
            'endTokenPos' => 982,
            'endFilePos' => 17462,
          ),
        ),
        'docComment' => '/**
 * An array of names and addresses queued for validation.
 * In send(), valid and non duplicate entries are moved to $all_recipients
 * and one of $to, $cc, or $bcc.
 * This array is used only for addresses with IDN.
 *
 * @see PHPMailer::$to
 * @see PHPMailer::$cc
 * @see PHPMailer::$bcc
 * @see PHPMailer::$all_recipients
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 654,
        'endLine' => 654,
        'startColumn' => 5,
        'endColumn' => 36,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'ReplyToQueue' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'ReplyToQueue',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 665,
            'endLine' => 665,
            'startTokenPos' => 993,
            'startFilePos' => 17775,
            'endTokenPos' => 994,
            'endFilePos' => 17776,
          ),
        ),
        'docComment' => '/**
 * An array of reply-to names and addresses queued for validation.
 * In send(), valid and non duplicate entries are moved to $ReplyTo.
 * This array is used only for addresses with IDN.
 *
 * @see PHPMailer::$ReplyTo
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 665,
        'endLine' => 665,
        'startColumn' => 5,
        'endColumn' => 33,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'UseSMTPUTF8' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'UseSMTPUTF8',
        'modifiers' => 1,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 673,
            'endLine' => 673,
            'startTokenPos' => 1005,
            'startFilePos' => 17940,
            'endTokenPos' => 1005,
            'endFilePos' => 17944,
          ),
        ),
        'docComment' => '/**
 * Whether the need for SMTPUTF8 has been detected. Set by
 * preSend() if necessary.
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 673,
        'endLine' => 673,
        'startColumn' => 5,
        'endColumn' => 32,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'attachment' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'attachment',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 680,
            'endLine' => 680,
            'startTokenPos' => 1016,
            'startFilePos' => 18050,
            'endTokenPos' => 1017,
            'endFilePos' => 18051,
          ),
        ),
        'docComment' => '/**
 * The array of attachments.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 680,
        'endLine' => 680,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'CustomHeader' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'CustomHeader',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 687,
            'endLine' => 687,
            'startTokenPos' => 1028,
            'startFilePos' => 18162,
            'endTokenPos' => 1029,
            'endFilePos' => 18163,
          ),
        ),
        'docComment' => '/**
 * The array of custom headers.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 687,
        'endLine' => 687,
        'startColumn' => 5,
        'endColumn' => 33,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'lastMessageID' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'lastMessageID',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 694,
            'endLine' => 694,
            'startTokenPos' => 1040,
            'startFilePos' => 18304,
            'endTokenPos' => 1040,
            'endFilePos' => 18305,
          ),
        ),
        'docComment' => '/**
 * The most recent Message-ID (including angular brackets).
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 694,
        'endLine' => 694,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'message_type' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'message_type',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 701,
            'endLine' => 701,
            'startTokenPos' => 1051,
            'startFilePos' => 18413,
            'endTokenPos' => 1051,
            'endFilePos' => 18414,
          ),
        ),
        'docComment' => '/**
 * The message\'s MIME type.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 701,
        'endLine' => 701,
        'startColumn' => 5,
        'endColumn' => 33,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'boundary' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'boundary',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 708,
            'endLine' => 708,
            'startTokenPos' => 1062,
            'startFilePos' => 18528,
            'endTokenPos' => 1063,
            'endFilePos' => 18529,
          ),
        ),
        'docComment' => '/**
 * The array of MIME boundary strings.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 708,
        'endLine' => 708,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'language' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'language',
        'modifiers' => 18,
        'type' => NULL,
        'default' => 
        array (
          'code' => '[]',
          'attributes' => 
          array (
            'startLine' => 715,
            'endLine' => 715,
            'startTokenPos' => 1076,
            'startFilePos' => 18676,
            'endTokenPos' => 1077,
            'endFilePos' => 18677,
          ),
        ),
        'docComment' => '/**
 * The array of available text strings for the current language.
 *
 * @var array
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 715,
        'endLine' => 715,
        'startColumn' => 5,
        'endColumn' => 36,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'error_count' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'error_count',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '0',
          'attributes' => 
          array (
            'startLine' => 722,
            'endLine' => 722,
            'startTokenPos' => 1088,
            'startFilePos' => 18790,
            'endTokenPos' => 1088,
            'endFilePos' => 18790,
          ),
        ),
        'docComment' => '/**
 * The number of errors encountered.
 *
 * @var int
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 722,
        'endLine' => 722,
        'startColumn' => 5,
        'endColumn' => 31,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'sign_cert_file' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'sign_cert_file',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 729,
            'endLine' => 729,
            'startTokenPos' => 1099,
            'startFilePos' => 18909,
            'endTokenPos' => 1099,
            'endFilePos' => 18910,
          ),
        ),
        'docComment' => '/**
 * The S/MIME certificate file path.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 729,
        'endLine' => 729,
        'startColumn' => 5,
        'endColumn' => 35,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'sign_key_file' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'sign_key_file',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 736,
            'endLine' => 736,
            'startTokenPos' => 1110,
            'startFilePos' => 19020,
            'endTokenPos' => 1110,
            'endFilePos' => 19021,
          ),
        ),
        'docComment' => '/**
 * The S/MIME key file path.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 736,
        'endLine' => 736,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'sign_extracerts_file' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'sign_extracerts_file',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 743,
            'endLine' => 743,
            'startTokenPos' => 1121,
            'startFilePos' => 19175,
            'endTokenPos' => 1121,
            'endFilePos' => 19176,
          ),
        ),
        'docComment' => '/**
 * The optional S/MIME extra certificates ("CA Chain") file path.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 743,
        'endLine' => 743,
        'startColumn' => 5,
        'endColumn' => 41,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'sign_key_pass' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'sign_key_pass',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 751,
            'endLine' => 751,
            'startTokenPos' => 1132,
            'startFilePos' => 19335,
            'endTokenPos' => 1132,
            'endFilePos' => 19336,
          ),
        ),
        'docComment' => '/**
 * The S/MIME password for the key.
 * Used only if the key is encrypted.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 751,
        'endLine' => 751,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'exceptions' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'exceptions',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'false',
          'attributes' => 
          array (
            'startLine' => 758,
            'endLine' => 758,
            'startTokenPos' => 1143,
            'startFilePos' => 19455,
            'endTokenPos' => 1143,
            'endFilePos' => 19459,
          ),
        ),
        'docComment' => '/**
 * Whether to throw exceptions for errors.
 *
 * @var bool
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 758,
        'endLine' => 758,
        'startColumn' => 5,
        'endColumn' => 34,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'uniqueid' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'uniqueid',
        'modifiers' => 2,
        'type' => NULL,
        'default' => 
        array (
          'code' => '\'\'',
          'attributes' => 
          array (
            'startLine' => 765,
            'endLine' => 765,
            'startTokenPos' => 1154,
            'startFilePos' => 19584,
            'endTokenPos' => 1154,
            'endFilePos' => 19585,
          ),
        ),
        'docComment' => '/**
 * Unique ID used for message ID and boundaries.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 765,
        'endLine' => 765,
        'startColumn' => 5,
        'endColumn' => 29,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'LE' => 
      array (
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'name' => 'LE',
        'modifiers' => 18,
        'type' => NULL,
        'default' => 
        array (
          'code' => 'self::CRLF',
          'attributes' => 
          array (
            'startLine' => 811,
            'endLine' => 811,
            'startTokenPos' => 1233,
            'startFilePos' => 20508,
            'endTokenPos' => 1235,
            'endFilePos' => 20517,
          ),
        ),
        'docComment' => '/**
 * SMTP RFC standard line ending; Carriage Return, Line Feed.
 *
 * @var string
 */',
        'attributes' => 
        array (
        ),
        'startLine' => 811,
        'endLine' => 811,
        'startColumn' => 5,
        'endColumn' => 38,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
          'exceptions' => 
          array (
            'name' => 'exceptions',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 845,
                'endLine' => 845,
                'startTokenPos' => 1283,
                'startFilePos' => 21389,
                'endTokenPos' => 1283,
                'endFilePos' => 21392,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 845,
            'endLine' => 845,
            'startColumn' => 33,
            'endColumn' => 50,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Constructor.
 *
 * @param bool $exceptions Should we throw external exceptions?
 */',
        'startLine' => 845,
        'endLine' => 852,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      '__destruct' => 
      array (
        'name' => '__destruct',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Destructor.
 */',
        'startLine' => 857,
        'endLine' => 861,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'mailPassthru' => 
      array (
        'name' => 'mailPassthru',
        'parameters' => 
        array (
          'to' => 
          array (
            'name' => 'to',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 877,
            'endLine' => 877,
            'startColumn' => 35,
            'endColumn' => 37,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'subject' => 
          array (
            'name' => 'subject',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 877,
            'endLine' => 877,
            'startColumn' => 40,
            'endColumn' => 47,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'body' => 
          array (
            'name' => 'body',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 877,
            'endLine' => 877,
            'startColumn' => 50,
            'endColumn' => 54,
            'parameterIndex' => 2,
            'isOptional' => false,
          ),
          'header' => 
          array (
            'name' => 'header',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 877,
            'endLine' => 877,
            'startColumn' => 57,
            'endColumn' => 63,
            'parameterIndex' => 3,
            'isOptional' => false,
          ),
          'params' => 
          array (
            'name' => 'params',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 877,
            'endLine' => 877,
            'startColumn' => 66,
            'endColumn' => 72,
            'parameterIndex' => 4,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Call mail() in a safe_mode-aware fashion.
 * Also, unless sendmail_path points to sendmail (or something that
 * claims to be sendmail), don\'t pass params (not a perfect fix,
 * but it will do).
 *
 * @param string      $to      To
 * @param string      $subject Subject
 * @param string      $body    Message Body
 * @param string      $header  Additional Header(s)
 * @param string|null $params  Params
 *
 * @return bool
 */',
        'startLine' => 877,
        'endLine' => 901,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 4,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'edebug' => 
      array (
        'name' => 'edebug',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 912,
            'endLine' => 912,
            'startColumn' => 31,
            'endColumn' => 34,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Output debugging info via a user-defined method.
 * Only generates output if debug output is enabled.
 *
 * @see PHPMailer::$Debugoutput
 * @see PHPMailer::$SMTPDebug
 *
 * @param string $str
 */',
        'startLine' => 912,
        'endLine' => 960,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isHTML' => 
      array (
        'name' => 'isHTML',
        'parameters' => 
        array (
          'isHtml' => 
          array (
            'name' => 'isHtml',
            'default' => 
            array (
              'code' => 'true',
              'attributes' => 
              array (
                'startLine' => 967,
                'endLine' => 967,
                'startTokenPos' => 1916,
                'startFilePos' => 25603,
                'endTokenPos' => 1916,
                'endFilePos' => 25606,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 967,
            'endLine' => 967,
            'startColumn' => 28,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Sets message type to HTML or plain.
 *
 * @param bool $isHtml True for HTML mode
 */',
        'startLine' => 967,
        'endLine' => 974,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isSMTP' => 
      array (
        'name' => 'isSMTP',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Send messages using SMTP.
 */',
        'startLine' => 979,
        'endLine' => 982,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isMail' => 
      array (
        'name' => 'isMail',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Send messages using PHP\'s mail() function.
 */',
        'startLine' => 987,
        'endLine' => 990,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'parseSendmailPath' => 
      array (
        'name' => 'parseSendmailPath',
        'parameters' => 
        array (
          'sendmailPath' => 
          array (
            'name' => 'sendmailPath',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 999,
            'endLine' => 999,
            'startColumn' => 40,
            'endColumn' => 52,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Extract sendmail path and parse to deal with known parameters.
 *
 * @param string $sendmailPath The sendmail path as set in php.ini
 *
 * @return string The sendmail path without the known parameters
 */',
        'startLine' => 999,
        'endLine' => 1038,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 4,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isSendmail' => 
      array (
        'name' => 'isSendmail',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Send messages using $Sendmail.
 */',
        'startLine' => 1043,
        'endLine' => 1052,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isQmail' => 
      array (
        'name' => 'isQmail',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Send messages using qmail.
 */',
        'startLine' => 1057,
        'endLine' => 1066,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addAddress' => 
      array (
        'name' => 'addAddress',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1078,
            'endLine' => 1078,
            'startColumn' => 32,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 1078,
                'endLine' => 1078,
                'startTokenPos' => 2474,
                'startFilePos' => 28627,
                'endTokenPos' => 2474,
                'endFilePos' => 28628,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1078,
            'endLine' => 1078,
            'startColumn' => 42,
            'endColumn' => 51,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add a "To" address.
 *
 * @param string $address The email address to send to
 * @param string $name
 *
 * @throws Exception
 *
 * @return bool true on success, false if address already used or invalid in some way
 */',
        'startLine' => 1078,
        'endLine' => 1081,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addCC' => 
      array (
        'name' => 'addCC',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1093,
            'endLine' => 1093,
            'startColumn' => 27,
            'endColumn' => 34,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 1093,
                'endLine' => 1093,
                'startTokenPos' => 2512,
                'startFilePos' => 29021,
                'endTokenPos' => 2512,
                'endFilePos' => 29022,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1093,
            'endLine' => 1093,
            'startColumn' => 37,
            'endColumn' => 46,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add a "CC" address.
 *
 * @param string $address The email address to send to
 * @param string $name
 *
 * @throws Exception
 *
 * @return bool true on success, false if address already used or invalid in some way
 */',
        'startLine' => 1093,
        'endLine' => 1096,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addBCC' => 
      array (
        'name' => 'addBCC',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1108,
            'endLine' => 1108,
            'startColumn' => 28,
            'endColumn' => 35,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 1108,
                'endLine' => 1108,
                'startTokenPos' => 2550,
                'startFilePos' => 29417,
                'endTokenPos' => 2550,
                'endFilePos' => 29418,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1108,
            'endLine' => 1108,
            'startColumn' => 38,
            'endColumn' => 47,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add a "BCC" address.
 *
 * @param string $address The email address to send to
 * @param string $name
 *
 * @throws Exception
 *
 * @return bool true on success, false if address already used or invalid in some way
 */',
        'startLine' => 1108,
        'endLine' => 1111,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addReplyTo' => 
      array (
        'name' => 'addReplyTo',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1123,
            'endLine' => 1123,
            'startColumn' => 32,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 1123,
                'endLine' => 1123,
                'startTokenPos' => 2588,
                'startFilePos' => 29824,
                'endTokenPos' => 2588,
                'endFilePos' => 29825,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1123,
            'endLine' => 1123,
            'startColumn' => 42,
            'endColumn' => 51,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add a "Reply-To" address.
 *
 * @param string $address The email address to reply to
 * @param string $name
 *
 * @throws Exception
 *
 * @return bool true on success, false if address already used or invalid in some way
 */',
        'startLine' => 1123,
        'endLine' => 1126,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addOrEnqueueAnAddress' => 
      array (
        'name' => 'addOrEnqueueAnAddress',
        'parameters' => 
        array (
          'kind' => 
          array (
            'name' => 'kind',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1142,
            'endLine' => 1142,
            'startColumn' => 46,
            'endColumn' => 50,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1142,
            'endLine' => 1142,
            'startColumn' => 53,
            'endColumn' => 60,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1142,
            'endLine' => 1142,
            'startColumn' => 63,
            'endColumn' => 67,
            'parameterIndex' => 2,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add an address to one of the recipient arrays or to the ReplyTo array. Because PHPMailer
 * can\'t validate addresses with an IDN without knowing the PHPMailer::$CharSet (that can still
 * be modified after calling this function), addition of such addresses is delayed until send().
 * Addresses that have been added already return false, but do not throw exceptions.
 *
 * @param string $kind    One of \'to\', \'cc\', \'bcc\', or \'Reply-To\'
 * @param string $address The email address
 * @param string $name    An optional username associated with the address
 *
 * @throws Exception
 *
 * @return bool true on success, false if address already used or invalid in some way
 */',
        'startLine' => 1142,
        'endLine' => 1194,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setBoundaries' => 
      array (
        'name' => 'setBoundaries',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set the boundaries to use for delimiting MIME parts.
 * If you override this, ensure you set all 3 boundaries to unique values.
 * The default boundaries include a "=_" sequence which cannot occur in quoted-printable bodies,
 * as suggested by https://www.rfc-editor.org/rfc/rfc2045#section-6.7
 *
 * @return void
 */',
        'startLine' => 1204,
        'endLine' => 1210,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addAnAddress' => 
      array (
        'name' => 'addAnAddress',
        'parameters' => 
        array (
          'kind' => 
          array (
            'name' => 'kind',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1224,
            'endLine' => 1224,
            'startColumn' => 37,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1224,
            'endLine' => 1224,
            'startColumn' => 44,
            'endColumn' => 51,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 1224,
                'endLine' => 1224,
                'startTokenPos' => 3083,
                'startFilePos' => 33792,
                'endTokenPos' => 3083,
                'endFilePos' => 33793,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1224,
            'endLine' => 1224,
            'startColumn' => 54,
            'endColumn' => 63,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add an address to one of the recipient arrays or to the ReplyTo array.
 * Addresses that have been added already return false, but do not throw exceptions.
 *
 * @param string $kind    One of \'to\', \'cc\', \'bcc\', or \'ReplyTo\'
 * @param string $address The email address to send, resp. to reply to
 * @param string $name
 *
 * @throws Exception
 *
 * @return bool true on success, false if address already used or invalid in some way
 */',
        'startLine' => 1224,
        'endLine' => 1282,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'parseAddresses' => 
      array (
        'name' => 'parseAddresses',
        'parameters' => 
        array (
          'addrstr' => 
          array (
            'name' => 'addrstr',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1301,
            'endLine' => 1301,
            'startColumn' => 43,
            'endColumn' => 50,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'useimap' => 
          array (
            'name' => 'useimap',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 1301,
                'endLine' => 1301,
                'startTokenPos' => 3492,
                'startFilePos' => 36668,
                'endTokenPos' => 3492,
                'endFilePos' => 36671,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1301,
            'endLine' => 1301,
            'startColumn' => 53,
            'endColumn' => 67,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
          'charset' => 
          array (
            'name' => 'charset',
            'default' => 
            array (
              'code' => 'self::CHARSET_ISO88591',
              'attributes' => 
              array (
                'startLine' => 1301,
                'endLine' => 1301,
                'startTokenPos' => 3499,
                'startFilePos' => 36685,
                'endTokenPos' => 3501,
                'endFilePos' => 36706,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1301,
            'endLine' => 1301,
            'startColumn' => 70,
            'endColumn' => 102,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Parse and validate a string containing one or more RFC822-style comma-separated email addresses
 * of the form "display name <address>" into an array of name/address pairs.
 * Uses the imap_rfc822_parse_adrlist function if the IMAP extension is available and
 * the deprecated $useimap argument is truthy.
 * Note that quotes in the name part are removed.
 *
 * @see https://www.andrew.cmu.edu/user/agreen1/testing/mrbs/web/Mail/RFC822.php A more careful implementation
 *
 * @param string $addrstr The address list string
 * @param bool|null $useimap Deprecated in PHPMailer 6.11.0.
 *                           Truthy values request the deprecated IMAP parser
 *                           and trigger a deprecation warning.
 * @param string $charset The charset to use when decoding the address list string.
 *
 * @return array
 */',
        'startLine' => 1301,
        'endLine' => 1340,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'parseSimplerAddresses' => 
      array (
        'name' => 'parseSimplerAddresses',
        'parameters' => 
        array (
          'addrstr' => 
          array (
            'name' => 'addrstr',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1353,
            'endLine' => 1353,
            'startColumn' => 53,
            'endColumn' => 60,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'charset' => 
          array (
            'name' => 'charset',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1353,
            'endLine' => 1353,
            'startColumn' => 63,
            'endColumn' => 70,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Parse a string containing one or more RFC822-style comma-separated email addresses
 * with the form "display name <address>" into an array of name/address pairs.
 * Uses a simpler parser that does not require the IMAP extension but doesnt support
 * the full RFC822 spec. For full RFC822 support, use the PHP IMAP extension.
 *
 * @param string $addrstr The address list string
 * @param string $charset The charset to use when decoding the address list string.
 *
 * @return array
 */',
        'startLine' => 1353,
        'endLine' => 1386,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'parseEmailString' => 
      array (
        'name' => 'parseEmailString',
        'parameters' => 
        array (
          'input' => 
          array (
            'name' => 'input',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1396,
            'endLine' => 1396,
            'startColumn' => 46,
            'endColumn' => 51,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Parse a string containing an email address with an optional name
 * and divide it into a name and email address.
 *
 * @param string $input The email with name.
 *
 * @return array{name: string, email: string}
 */',
        'startLine' => 1396,
        'endLine' => 1422,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 20,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setFrom' => 
      array (
        'name' => 'setFrom',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1435,
            'endLine' => 1435,
            'startColumn' => 29,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 1435,
                'endLine' => 1435,
                'startTokenPos' => 4292,
                'startFilePos' => 42000,
                'endTokenPos' => 4292,
                'endFilePos' => 42001,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1435,
            'endLine' => 1435,
            'startColumn' => 39,
            'endColumn' => 48,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
          'auto' => 
          array (
            'name' => 'auto',
            'default' => 
            array (
              'code' => 'true',
              'attributes' => 
              array (
                'startLine' => 1435,
                'endLine' => 1435,
                'startTokenPos' => 4299,
                'startFilePos' => 42012,
                'endTokenPos' => 4299,
                'endFilePos' => 42015,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1435,
            'endLine' => 1435,
            'startColumn' => 51,
            'endColumn' => 62,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set the From and FromName properties.
 *
 * @param string $address
 * @param string $name
 * @param bool   $auto    Whether to also set the Sender address, defaults to true
 *
 * @throws Exception
 *
 * @return bool
 */',
        'startLine' => 1435,
        'endLine' => 1470,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getLastMessageID' => 
      array (
        'name' => 'getLastMessageID',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Return the Message-ID header of the last email.
 * Technically this is the value from the last time the headers were created,
 * but it\'s also the message ID of the last sent message except in
 * pathological cases.
 *
 * @return string
 */',
        'startLine' => 1480,
        'endLine' => 1483,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'validateAddress' => 
      array (
        'name' => 'validateAddress',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1510,
            'endLine' => 1510,
            'startColumn' => 44,
            'endColumn' => 51,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'patternselect' => 
          array (
            'name' => 'patternselect',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 1510,
                'endLine' => 1510,
                'startTokenPos' => 4588,
                'startFilePos' => 44780,
                'endTokenPos' => 4588,
                'endFilePos' => 44783,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1510,
            'endLine' => 1510,
            'startColumn' => 54,
            'endColumn' => 74,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check that a string looks like an email address.
 * Validation patterns supported:
 * * `auto` Pick best pattern automatically;
 * * `pcre8` Use the squiloople.com pattern, requires PCRE > 8.0;
 * * `pcre` Use old PCRE implementation;
 * * `php` Use PHP built-in FILTER_VALIDATE_EMAIL;
 * * `html5` Use the pattern given by the HTML5 spec for \'email\' type form input elements.
 * * `eai` Use a pattern similar to the HTML5 spec for \'email\' and to firefox, extended to support EAI (RFC6530).
 * * `noregex` Don\'t use a regex: super fast, really dumb.
 * Alternatively you may pass in a callable to inject your own validator, for example:
 *
 * ```php
 * PHPMailer::validateAddress(\'user@example.com\', function($address) {
 *     return (strpos($address, \'@\') !== false);
 * });
 * ```
 *
 * You can also set the PHPMailer::$validator static to a callable, allowing built-in methods to use your validator.
 *
 * @param string          $address       The email address to check
 * @param string|callable $patternselect Which pattern to use
 *
 * @return bool
 */',
        'startLine' => 1510,
        'endLine' => 1586,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'idnSupported' => 
      array (
        'name' => 'idnSupported',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Tells whether IDNs (Internationalized Domain Names) are supported or not. This requires the
 * `intl` and `mbstring` PHP extensions.
 *
 * @return bool `true` if required functions for IDN support are present
 */',
        'startLine' => 1594,
        'endLine' => 1597,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'punyencodeAddress' => 
      array (
        'name' => 'punyencodeAddress',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1613,
            'endLine' => 1613,
            'startColumn' => 39,
            'endColumn' => 46,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Converts IDN in given email address to its ASCII form, also known as punycode, if possible.
 * Important: Address must be passed in same encoding as currently set in PHPMailer::$CharSet.
 * This function silently returns unmodified address if:
 * - No conversion is necessary (i.e. domain name is not an IDN, or is already in ASCII form)
 * - Conversion to punycode is impossible (e.g. required PHP functions are not available)
 *   or fails for any reason (e.g. domain contains characters not allowed in an IDN).
 *
 * @see PHPMailer::$CharSet
 *
 * @param string $address The email address to convert
 *
 * @return string The encoded address in ASCII form
 */',
        'startLine' => 1613,
        'endLine' => 1653,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'send' => 
      array (
        'name' => 'send',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Create a message and send it.
 * Uses the sending method specified by $Mailer.
 *
 * @throws Exception
 *
 * @return bool false on error - See the ErrorInfo property for details of the error
 */',
        'startLine' => 1663,
        'endLine' => 1680,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'preSend' => 
      array (
        'name' => 'preSend',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Prepare a message for sending.
 *
 * @throws Exception
 *
 * @return bool
 */',
        'startLine' => 1689,
        'endLine' => 1837,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'postSend' => 
      array (
        'name' => 'postSend',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Actually send a message via the selected mechanism.
 *
 * @throws Exception
 *
 * @return bool
 */',
        'startLine' => 1846,
        'endLine' => 1878,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'sendmailSend' => 
      array (
        'name' => 'sendmailSend',
        'parameters' => 
        array (
          'header' => 
          array (
            'name' => 'header',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1892,
            'endLine' => 1892,
            'startColumn' => 37,
            'endColumn' => 43,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'body' => 
          array (
            'name' => 'body',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 1892,
            'endLine' => 1892,
            'startColumn' => 46,
            'endColumn' => 50,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Send mail using the $Sendmail program.
 *
 * @see PHPMailer::$Sendmail
 *
 * @param string $header The message headers
 * @param string $body   The message body
 *
 * @throws Exception
 *
 * @return bool
 */',
        'startLine' => 1892,
        'endLine' => 1993,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isShellSafe' => 
      array (
        'name' => 'isShellSafe',
        'parameters' => 
        array (
          'string' => 
          array (
            'name' => 'string',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2005,
            'endLine' => 2005,
            'startColumn' => 43,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Fix CVE-2016-10033 and CVE-2016-10045 by disallowing potentially unsafe shell characters.
 * Note that escapeshellarg and escapeshellcmd are inadequate for our purposes, especially on Windows.
 *
 * @see https://github.com/PHPMailer/PHPMailer/issues/924 CVE-2016-10045 bug report
 *
 * @param string $string The string to be validated
 *
 * @return bool
 */',
        'startLine' => 2005,
        'endLine' => 2035,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isPermittedPath' => 
      array (
        'name' => 'isPermittedPath',
        'parameters' => 
        array (
          'path' => 
          array (
            'name' => 'path',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2046,
            'endLine' => 2046,
            'startColumn' => 47,
            'endColumn' => 51,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check whether a file path is of a permitted type.
 * Used to reject URLs and phar files from functions that access local file paths,
 * such as addAttachment.
 *
 * @param string $path A relative or absolute path to a file
 *
 * @return bool
 */',
        'startLine' => 2046,
        'endLine' => 2050,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'fileIsAccessible' => 
      array (
        'name' => 'fileIsAccessible',
        'parameters' => 
        array (
          'path' => 
          array (
            'name' => 'path',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2059,
            'endLine' => 2059,
            'startColumn' => 48,
            'endColumn' => 52,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check whether a file path is safe, accessible, and readable.
 *
 * @param string $path A relative or absolute path to a file
 *
 * @return bool
 */',
        'startLine' => 2059,
        'endLine' => 2070,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'mailSend' => 
      array (
        'name' => 'mailSend',
        'parameters' => 
        array (
          'header' => 
          array (
            'name' => 'header',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2084,
            'endLine' => 2084,
            'startColumn' => 33,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'body' => 
          array (
            'name' => 'body',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2084,
            'endLine' => 2084,
            'startColumn' => 42,
            'endColumn' => 46,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Send mail using the PHP mail() function.
 *
 * @see https://www.php.net/manual/en/book.mail.php
 *
 * @param string $header The message headers
 * @param string $body   The message body
 *
 * @throws Exception
 *
 * @return bool
 */',
        'startLine' => 2084,
        'endLine' => 2154,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getSMTPInstance' => 
      array (
        'name' => 'getSMTPInstance',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get an instance to use for SMTP operations.
 * Override this function to load your own SMTP implementation,
 * or set one with setSMTPInstance.
 *
 * @return SMTP
 */',
        'startLine' => 2163,
        'endLine' => 2170,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setSMTPInstance' => 
      array (
        'name' => 'setSMTPInstance',
        'parameters' => 
        array (
          'smtp' => 
          array (
            'name' => 'smtp',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'PHPMailer\\PHPMailer\\SMTP',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2177,
            'endLine' => 2177,
            'startColumn' => 37,
            'endColumn' => 46,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Provide an instance to use for SMTP operations.
 *
 * @return SMTP
 */',
        'startLine' => 2177,
        'endLine' => 2182,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setSMTPXclientAttribute' => 
      array (
        'name' => 'setSMTPXclientAttribute',
        'parameters' => 
        array (
          'name' => 
          array (
            'name' => 'name',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2192,
            'endLine' => 2192,
            'startColumn' => 45,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'value' => 
          array (
            'name' => 'value',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2192,
            'endLine' => 2192,
            'startColumn' => 52,
            'endColumn' => 57,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Provide SMTP XCLIENT attributes
 *
 * @param string $name  Attribute name
 * @param ?string $value Attribute value
 *
 * @return bool
 */',
        'startLine' => 2192,
        'endLine' => 2204,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getSMTPXclientAttributes' => 
      array (
        'name' => 'getSMTPXclientAttributes',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get SMTP XCLIENT attributes
 *
 * @return array
 */',
        'startLine' => 2211,
        'endLine' => 2214,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'smtpSend' => 
      array (
        'name' => 'smtpSend',
        'parameters' => 
        array (
          'header' => 
          array (
            'name' => 'header',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2231,
            'endLine' => 2231,
            'startColumn' => 33,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'body' => 
          array (
            'name' => 'body',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2231,
            'endLine' => 2231,
            'startColumn' => 42,
            'endColumn' => 46,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Send mail via SMTP.
 * Returns false if there is a bad MAIL FROM, RCPT, or DATA input.
 *
 * @see PHPMailer::setSMTPInstance() to use a different class.
 *
 * @uses \\PHPMailer\\PHPMailer\\SMTP
 *
 * @param string $header The message headers
 * @param string $body   The message body
 *
 * @throws Exception
 *
 * @return bool
 */',
        'startLine' => 2231,
        'endLine' => 2310,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'smtpConnect' => 
      array (
        'name' => 'smtpConnect',
        'parameters' => 
        array (
          'options' => 
          array (
            'name' => 'options',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 2324,
                'endLine' => 2324,
                'startTokenPos' => 9367,
                'startFilePos' => 76691,
                'endTokenPos' => 9367,
                'endFilePos' => 76694,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2324,
            'endLine' => 2324,
            'startColumn' => 33,
            'endColumn' => 47,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Initiate a connection to an SMTP server.
 * Returns false if the operation failed.
 *
 * @param array $options An array of options compatible with stream_context_create()
 *
 * @throws Exception
 *
 * @uses \\PHPMailer\\PHPMailer\\SMTP
 *
 * @return bool
 */',
        'startLine' => 2324,
        'endLine' => 2469,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'smtpClose' => 
      array (
        'name' => 'smtpClose',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Close the active SMTP session if one exists.
 */',
        'startLine' => 2474,
        'endLine' => 2480,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setLanguage' => 
      array (
        'name' => 'setLanguage',
        'parameters' => 
        array (
          'langcode' => 
          array (
            'name' => 'langcode',
            'default' => 
            array (
              'code' => '\'en\'',
              'attributes' => 
              array (
                'startLine' => 2494,
                'endLine' => 2494,
                'startTokenPos' => 10458,
                'startFilePos' => 83633,
                'endTokenPos' => 10458,
                'endFilePos' => 83636,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2494,
            'endLine' => 2494,
            'startColumn' => 40,
            'endColumn' => 55,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
          'lang_path' => 
          array (
            'name' => 'lang_path',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 2494,
                'endLine' => 2494,
                'startTokenPos' => 10465,
                'startFilePos' => 83652,
                'endTokenPos' => 10465,
                'endFilePos' => 83653,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2494,
            'endLine' => 2494,
            'startColumn' => 58,
            'endColumn' => 72,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set the language for error messages.
 * The default language is English.
 *
 * @param string $langcode  ISO 639-1 2-character language code (e.g. French is "fr")
 *                          Optionally, the language code can be enhanced with a 4-character
 *                          script annotation and/or a 2-character country annotation.
 * @param string $lang_path Path to the language file directory, with trailing separator (slash)
 *                          Do not set this from user input!
 *
 * @return bool Returns true if the requested language was loaded, false otherwise.
 */',
        'startLine' => 2494,
        'endLine' => 2615,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getTranslations' => 
      array (
        'name' => 'getTranslations',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the array of strings for the current language.
 *
 * @return array
 */',
        'startLine' => 2622,
        'endLine' => 2629,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addrAppend' => 
      array (
        'name' => 'addrAppend',
        'parameters' => 
        array (
          'type' => 
          array (
            'name' => 'type',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2642,
            'endLine' => 2642,
            'startColumn' => 32,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'addr' => 
          array (
            'name' => 'addr',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2642,
            'endLine' => 2642,
            'startColumn' => 39,
            'endColumn' => 43,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Create recipient headers.
 *
 * @param string $type
 * @param array  $addr An array of recipients,
 *                     where each recipient is a 2-element indexed array with element 0 containing an address
 *                     and element 1 containing a name, like:
 *                     [[\'joe@example.com\', \'Joe User\'], [\'zoe@example.com\', \'Zoe User\']]
 *
 * @return string
 */',
        'startLine' => 2642,
        'endLine' => 2650,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addrFormat' => 
      array (
        'name' => 'addrFormat',
        'parameters' => 
        array (
          'addr' => 
          array (
            'name' => 'addr',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2660,
            'endLine' => 2660,
            'startColumn' => 32,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Format an address for use in a message header.
 *
 * @param array $addr A 2-element indexed array, element 0 containing an address, element 1 containing a name like
 *                    [\'joe@example.com\', \'Joe User\']
 *
 * @return string
 */',
        'startLine' => 2660,
        'endLine' => 2668,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'wrapText' => 
      array (
        'name' => 'wrapText',
        'parameters' => 
        array (
          'message' => 
          array (
            'name' => 'message',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2682,
            'endLine' => 2682,
            'startColumn' => 30,
            'endColumn' => 37,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'length' => 
          array (
            'name' => 'length',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2682,
            'endLine' => 2682,
            'startColumn' => 40,
            'endColumn' => 46,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'qp_mode' => 
          array (
            'name' => 'qp_mode',
            'default' => 
            array (
              'code' => 'false',
              'attributes' => 
              array (
                'startLine' => 2682,
                'endLine' => 2682,
                'startTokenPos' => 11503,
                'startFilePos' => 91349,
                'endTokenPos' => 11503,
                'endFilePos' => 91353,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2682,
            'endLine' => 2682,
            'startColumn' => 49,
            'endColumn' => 64,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Word-wrap message.
 * For use with mailers that do not automatically perform wrapping
 * and for quoted-printable encoded messages.
 * Original written by philippe.
 *
 * @param string $message The message to wrap
 * @param int    $length  The line length to wrap to
 * @param bool   $qp_mode Whether to run in Quoted-Printable mode
 *
 * @return string
 */',
        'startLine' => 2682,
        'endLine' => 2770,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'utf8CharBoundary' => 
      array (
        'name' => 'utf8CharBoundary',
        'parameters' => 
        array (
          'encodedText' => 
          array (
            'name' => 'encodedText',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2782,
            'endLine' => 2782,
            'startColumn' => 38,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'maxLength' => 
          array (
            'name' => 'maxLength',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 2782,
            'endLine' => 2782,
            'startColumn' => 52,
            'endColumn' => 61,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Find the last character boundary prior to $maxLength in a utf-8
 * quoted-printable encoded string.
 * Original written by Colin Brown.
 *
 * @param string $encodedText utf-8 QP text
 * @param int    $maxLength   Find the last character boundary prior to this length
 *
 * @return int
 */',
        'startLine' => 2782,
        'endLine' => 2818,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setWordWrap' => 
      array (
        'name' => 'setWordWrap',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Apply word wrapping to the message body.
 * Wraps the message body to the number of chars set in the WordWrap property.
 * You should only do this to plain-text bodies as wrapping HTML tags may break them.
 * This is called automatically by createBody(), so you don\'t need to call it yourself.
 */',
        'startLine' => 2826,
        'endLine' => 2843,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'createHeader' => 
      array (
        'name' => 'createHeader',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Assemble message headers.
 *
 * @return string The assembled headers
 */',
        'startLine' => 2850,
        'endLine' => 2946,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getMailMIME' => 
      array (
        'name' => 'getMailMIME',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the message MIME type headers.
 *
 * @return string
 */',
        'startLine' => 2953,
        'endLine' => 3001,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getSentMIMEMessage' => 
      array (
        'name' => 'getSentMIMEMessage',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Returns the whole MIME message.
 * Includes complete headers and body.
 * Only valid post preSend().
 *
 * @see PHPMailer::preSend()
 *
 * @return string
 */',
        'startLine' => 3012,
        'endLine' => 3016,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'generateId' => 
      array (
        'name' => 'generateId',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Create a unique ID to use for boundaries.
 *
 * @return string
 */',
        'startLine' => 3023,
        'endLine' => 3046,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'createBody' => 
      array (
        'name' => 'createBody',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Assemble the message body.
 * Returns an empty string on failure.
 *
 * @throws Exception
 *
 * @return string The assembled message body
 */',
        'startLine' => 3056,
        'endLine' => 3337,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getBoundaries' => 
      array (
        'name' => 'getBoundaries',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the boundaries that this message will use
 * @return array
 */',
        'startLine' => 3343,
        'endLine' => 3349,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getBoundary' => 
      array (
        'name' => 'getBoundary',
        'parameters' => 
        array (
          'boundary' => 
          array (
            'name' => 'boundary',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3361,
            'endLine' => 3361,
            'startColumn' => 36,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'charSet' => 
          array (
            'name' => 'charSet',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3361,
            'endLine' => 3361,
            'startColumn' => 47,
            'endColumn' => 54,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'contentType' => 
          array (
            'name' => 'contentType',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3361,
            'endLine' => 3361,
            'startColumn' => 57,
            'endColumn' => 68,
            'parameterIndex' => 2,
            'isOptional' => false,
          ),
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3361,
            'endLine' => 3361,
            'startColumn' => 71,
            'endColumn' => 79,
            'parameterIndex' => 3,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Return the start of a message boundary.
 *
 * @param string $boundary
 * @param string $charSet
 * @param string $contentType
 * @param string $encoding
 *
 * @return string
 */',
        'startLine' => 3361,
        'endLine' => 3383,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'endBoundary' => 
      array (
        'name' => 'endBoundary',
        'parameters' => 
        array (
          'boundary' => 
          array (
            'name' => 'boundary',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3392,
            'endLine' => 3392,
            'startColumn' => 36,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Return the end of a message boundary.
 *
 * @param string $boundary
 *
 * @return string
 */',
        'startLine' => 3392,
        'endLine' => 3395,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setMessageType' => 
      array (
        'name' => 'setMessageType',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set the message type.
 * PHPMailer only supports some preset message types, not arbitrary MIME structures.
 */',
        'startLine' => 3401,
        'endLine' => 3418,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'headerLine' => 
      array (
        'name' => 'headerLine',
        'parameters' => 
        array (
          'name' => 
          array (
            'name' => 'name',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3428,
            'endLine' => 3428,
            'startColumn' => 32,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'value' => 
          array (
            'name' => 'value',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3428,
            'endLine' => 3428,
            'startColumn' => 39,
            'endColumn' => 44,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Format a header line.
 *
 * @param string     $name
 * @param string|int $value
 *
 * @return string
 */',
        'startLine' => 3428,
        'endLine' => 3431,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'textLine' => 
      array (
        'name' => 'textLine',
        'parameters' => 
        array (
          'value' => 
          array (
            'name' => 'value',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3440,
            'endLine' => 3440,
            'startColumn' => 30,
            'endColumn' => 35,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Return a formatted mail line.
 *
 * @param string $value
 *
 * @return string
 */',
        'startLine' => 3440,
        'endLine' => 3443,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addAttachment' => 
      array (
        'name' => 'addAttachment',
        'parameters' => 
        array (
          'path' => 
          array (
            'name' => 'path',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3463,
            'endLine' => 3463,
            'startColumn' => 9,
            'endColumn' => 13,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 3464,
                'endLine' => 3464,
                'startTokenPos' => 17128,
                'startFilePos' => 122586,
                'endTokenPos' => 17128,
                'endFilePos' => 122587,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3464,
            'endLine' => 3464,
            'startColumn' => 9,
            'endColumn' => 18,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => 
            array (
              'code' => 'self::ENCODING_BASE64',
              'attributes' => 
              array (
                'startLine' => 3465,
                'endLine' => 3465,
                'startTokenPos' => 17135,
                'startFilePos' => 122610,
                'endTokenPos' => 17137,
                'endFilePos' => 122630,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3465,
            'endLine' => 3465,
            'startColumn' => 9,
            'endColumn' => 41,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
          'type' => 
          array (
            'name' => 'type',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 3466,
                'endLine' => 3466,
                'startTokenPos' => 17144,
                'startFilePos' => 122649,
                'endTokenPos' => 17144,
                'endFilePos' => 122650,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3466,
            'endLine' => 3466,
            'startColumn' => 9,
            'endColumn' => 18,
            'parameterIndex' => 3,
            'isOptional' => true,
          ),
          'disposition' => 
          array (
            'name' => 'disposition',
            'default' => 
            array (
              'code' => '\'attachment\'',
              'attributes' => 
              array (
                'startLine' => 3467,
                'endLine' => 3467,
                'startTokenPos' => 17151,
                'startFilePos' => 122676,
                'endTokenPos' => 17151,
                'endFilePos' => 122687,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3467,
            'endLine' => 3467,
            'startColumn' => 9,
            'endColumn' => 35,
            'parameterIndex' => 4,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add an attachment from a path on the filesystem.
 * Never use a user-supplied path to a file!
 * Returns false if the file could not be found or read.
 * Explicitly *does not* support passing URLs; PHPMailer is not an HTTP client.
 * If you need to do that, fetch the resource yourself and pass it in via a local file or string.
 *
 * @param string $path        Path to the attachment
 * @param string $name        Overrides the attachment name
 * @param string $encoding    File encoding (see $Encoding)
 * @param string $type        MIME type, e.g. `image/jpeg`; determined automatically from $path if not specified
 * @param string $disposition Disposition to use
 *
 * @throws Exception
 *
 * @return bool
 */',
        'startLine' => 3462,
        'endLine' => 3508,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getAttachments' => 
      array (
        'name' => 'getAttachments',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Return the array of attachments.
 *
 * @return array
 */',
        'startLine' => 3515,
        'endLine' => 3518,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'attachAll' => 
      array (
        'name' => 'attachAll',
        'parameters' => 
        array (
          'disposition_type' => 
          array (
            'name' => 'disposition_type',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3531,
            'endLine' => 3531,
            'startColumn' => 34,
            'endColumn' => 50,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'boundary' => 
          array (
            'name' => 'boundary',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3531,
            'endLine' => 3531,
            'startColumn' => 53,
            'endColumn' => 61,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Attach all file, string, and binary attachments to the message.
 * Returns an empty string on failure.
 *
 * @param string $disposition_type
 * @param string $boundary
 *
 * @throws Exception
 *
 * @return string
 */',
        'startLine' => 3531,
        'endLine' => 3630,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'encodeFile' => 
      array (
        'name' => 'encodeFile',
        'parameters' => 
        array (
          'path' => 
          array (
            'name' => 'path',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3641,
            'endLine' => 3641,
            'startColumn' => 35,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => 
            array (
              'code' => 'self::ENCODING_BASE64',
              'attributes' => 
              array (
                'startLine' => 3641,
                'endLine' => 3641,
                'startTokenPos' => 18201,
                'startFilePos' => 128632,
                'endTokenPos' => 18203,
                'endFilePos' => 128652,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3641,
            'endLine' => 3641,
            'startColumn' => 42,
            'endColumn' => 74,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Encode a file attachment in requested format.
 * Returns an empty string on failure.
 *
 * @param string $path     The full path to the file
 * @param string $encoding The encoding to use; one of \'base64\', \'7bit\', \'8bit\', \'binary\', \'quoted-printable\'
 *
 * @return string
 */',
        'startLine' => 3641,
        'endLine' => 3663,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'encodeString' => 
      array (
        'name' => 'encodeString',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3676,
            'endLine' => 3676,
            'startColumn' => 34,
            'endColumn' => 37,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => 
            array (
              'code' => 'self::ENCODING_BASE64',
              'attributes' => 
              array (
                'startLine' => 3676,
                'endLine' => 3676,
                'startTokenPos' => 18397,
                'startFilePos' => 129776,
                'endTokenPos' => 18399,
                'endFilePos' => 129796,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3676,
            'endLine' => 3676,
            'startColumn' => 40,
            'endColumn' => 72,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Encode a string in requested format.
 * Returns an empty string on failure.
 *
 * @param string $str      The text to encode
 * @param string $encoding The encoding to use; one of \'base64\', \'7bit\', \'8bit\', \'binary\', \'quoted-printable\'
 *
 * @throws Exception
 *
 * @return string
 */',
        'startLine' => 3676,
        'endLine' => 3710,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'encodeHeader' => 
      array (
        'name' => 'encodeHeader',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3723,
            'endLine' => 3723,
            'startColumn' => 34,
            'endColumn' => 37,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'position' => 
          array (
            'name' => 'position',
            'default' => 
            array (
              'code' => '\'text\'',
              'attributes' => 
              array (
                'startLine' => 3723,
                'endLine' => 3723,
                'startTokenPos' => 18644,
                'startFilePos' => 131468,
                'endTokenPos' => 18644,
                'endFilePos' => 131473,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3723,
            'endLine' => 3723,
            'startColumn' => 40,
            'endColumn' => 57,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Encode a header value (not including its label) optimally.
 * Picks shortest of Q, B, or none. Result includes folding if needed.
 * See RFC822 definitions for phrase, comment and text positions,
 * and RFC2047 for inline encodings.
 *
 * @param string $str      The header value to encode
 * @param string $position What context the string will be used in
 *
 * @return string
 */',
        'startLine' => 3723,
        'endLine' => 3808,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'decodeHeader' => 
      array (
        'name' => 'decodeHeader',
        'parameters' => 
        array (
          'value' => 
          array (
            'name' => 'value',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3819,
            'endLine' => 3819,
            'startColumn' => 41,
            'endColumn' => 46,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'charset' => 
          array (
            'name' => 'charset',
            'default' => 
            array (
              'code' => 'self::CHARSET_ISO88591',
              'attributes' => 
              array (
                'startLine' => 3819,
                'endLine' => 3819,
                'startTokenPos' => 19323,
                'startFilePos' => 135417,
                'endTokenPos' => 19325,
                'endFilePos' => 135438,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3819,
            'endLine' => 3819,
            'startColumn' => 49,
            'endColumn' => 81,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Decode an RFC2047-encoded header value
 * Attempts multiple strategies so it works even when the mbstring extension is disabled.
 *
 * @param string $value   The header value to decode
 * @param string $charset The target charset to convert to, defaults to ISO-8859-1 for BC
 *
 * @return string The decoded header value
 */',
        'startLine' => 3819,
        'endLine' => 3844,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'hasMultiBytes' => 
      array (
        'name' => 'hasMultiBytes',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3853,
            'endLine' => 3853,
            'startColumn' => 35,
            'endColumn' => 38,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check if a string contains multi-byte characters.
 *
 * @param string $str multi-byte text to wrap encode
 *
 * @return bool
 */',
        'startLine' => 3853,
        'endLine' => 3861,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'has8bitChars' => 
      array (
        'name' => 'has8bitChars',
        'parameters' => 
        array (
          'text' => 
          array (
            'name' => 'text',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3870,
            'endLine' => 3870,
            'startColumn' => 34,
            'endColumn' => 38,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Does a string contain any 8-bit chars (in any charset)?
 *
 * @param string $text
 *
 * @return bool
 */',
        'startLine' => 3870,
        'endLine' => 3873,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'base64EncodeWrapMB' => 
      array (
        'name' => 'base64EncodeWrapMB',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3887,
            'endLine' => 3887,
            'startColumn' => 40,
            'endColumn' => 43,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'linebreak' => 
          array (
            'name' => 'linebreak',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 3887,
                'endLine' => 3887,
                'startTokenPos' => 19589,
                'startFilePos' => 137720,
                'endTokenPos' => 19589,
                'endFilePos' => 137723,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3887,
            'endLine' => 3887,
            'startColumn' => 46,
            'endColumn' => 62,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Encode and wrap long multibyte strings for mail headers
 * without breaking lines within a character.
 * Adapted from a function by paravoid.
 *
 * @see https://www.php.net/manual/en/function.mb-encode-mimeheader.php#60283
 *
 * @param string $str       multi-byte text to wrap encode
 * @param string $linebreak string to use as linefeed/end-of-line
 *
 * @return string
 */',
        'startLine' => 3887,
        'endLine' => 3918,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'encodeQP' => 
      array (
        'name' => 'encodeQP',
        'parameters' => 
        array (
          'string' => 
          array (
            'name' => 'string',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3928,
            'endLine' => 3928,
            'startColumn' => 30,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Encode a string in quoted-printable format.
 * According to RFC2045 section 6.7.
 *
 * @param string $string The text to encode
 *
 * @return string
 */',
        'startLine' => 3928,
        'endLine' => 3931,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'encodeQ' => 
      array (
        'name' => 'encodeQ',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3943,
            'endLine' => 3943,
            'startColumn' => 29,
            'endColumn' => 32,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'position' => 
          array (
            'name' => 'position',
            'default' => 
            array (
              'code' => '\'text\'',
              'attributes' => 
              array (
                'startLine' => 3943,
                'endLine' => 3943,
                'startTokenPos' => 19906,
                'startFilePos' => 139446,
                'endTokenPos' => 19906,
                'endFilePos' => 139451,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 3943,
            'endLine' => 3943,
            'startColumn' => 35,
            'endColumn' => 52,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Encode a string using Q encoding.
 *
 * @see https://www.rfc-editor.org/rfc/rfc2047#section-4.2
 *
 * @param string $str      the text to encode
 * @param string $position Where the text is going to be used, see the RFC for what that means
 *
 * @return string
 */',
        'startLine' => 3943,
        'endLine' => 3984,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addStringAttachment' => 
      array (
        'name' => 'addStringAttachment',
        'parameters' => 
        array (
          'string' => 
          array (
            'name' => 'string',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4002,
            'endLine' => 4002,
            'startColumn' => 9,
            'endColumn' => 15,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'filename' => 
          array (
            'name' => 'filename',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4003,
            'endLine' => 4003,
            'startColumn' => 9,
            'endColumn' => 17,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => 
            array (
              'code' => 'self::ENCODING_BASE64',
              'attributes' => 
              array (
                'startLine' => 4004,
                'endLine' => 4004,
                'startTokenPos' => 20197,
                'startFilePos' => 141786,
                'endTokenPos' => 20199,
                'endFilePos' => 141806,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4004,
            'endLine' => 4004,
            'startColumn' => 9,
            'endColumn' => 41,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
          'type' => 
          array (
            'name' => 'type',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 4005,
                'endLine' => 4005,
                'startTokenPos' => 20206,
                'startFilePos' => 141825,
                'endTokenPos' => 20206,
                'endFilePos' => 141826,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4005,
            'endLine' => 4005,
            'startColumn' => 9,
            'endColumn' => 18,
            'parameterIndex' => 3,
            'isOptional' => true,
          ),
          'disposition' => 
          array (
            'name' => 'disposition',
            'default' => 
            array (
              'code' => '\'attachment\'',
              'attributes' => 
              array (
                'startLine' => 4006,
                'endLine' => 4006,
                'startTokenPos' => 20213,
                'startFilePos' => 141852,
                'endTokenPos' => 20213,
                'endFilePos' => 141863,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4006,
            'endLine' => 4006,
            'startColumn' => 9,
            'endColumn' => 35,
            'parameterIndex' => 4,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add a string or binary attachment (non-filesystem).
 * This method can be used to attach ascii or binary data,
 * such as a BLOB record from a database.
 *
 * @param string $string      String attachment data
 * @param string $filename    Name of the attachment
 * @param string $encoding    File encoding (see $Encoding)
 * @param string $type        File extension (MIME) type
 * @param string $disposition Disposition to use
 *
 * @throws Exception
 *
 * @return bool True on successfully adding an attachment
 */',
        'startLine' => 4001,
        'endLine' => 4040,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addEmbeddedImage' => 
      array (
        'name' => 'addEmbeddedImage',
        'parameters' => 
        array (
          'path' => 
          array (
            'name' => 'path',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4065,
            'endLine' => 4065,
            'startColumn' => 9,
            'endColumn' => 13,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'cid' => 
          array (
            'name' => 'cid',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4066,
            'endLine' => 4066,
            'startColumn' => 9,
            'endColumn' => 12,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 4067,
                'endLine' => 4067,
                'startTokenPos' => 20453,
                'startFilePos' => 144268,
                'endTokenPos' => 20453,
                'endFilePos' => 144269,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4067,
            'endLine' => 4067,
            'startColumn' => 9,
            'endColumn' => 18,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => 
            array (
              'code' => 'self::ENCODING_BASE64',
              'attributes' => 
              array (
                'startLine' => 4068,
                'endLine' => 4068,
                'startTokenPos' => 20460,
                'startFilePos' => 144292,
                'endTokenPos' => 20462,
                'endFilePos' => 144312,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4068,
            'endLine' => 4068,
            'startColumn' => 9,
            'endColumn' => 41,
            'parameterIndex' => 3,
            'isOptional' => true,
          ),
          'type' => 
          array (
            'name' => 'type',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 4069,
                'endLine' => 4069,
                'startTokenPos' => 20469,
                'startFilePos' => 144331,
                'endTokenPos' => 20469,
                'endFilePos' => 144332,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4069,
            'endLine' => 4069,
            'startColumn' => 9,
            'endColumn' => 18,
            'parameterIndex' => 4,
            'isOptional' => true,
          ),
          'disposition' => 
          array (
            'name' => 'disposition',
            'default' => 
            array (
              'code' => '\'inline\'',
              'attributes' => 
              array (
                'startLine' => 4070,
                'endLine' => 4070,
                'startTokenPos' => 20476,
                'startFilePos' => 144358,
                'endTokenPos' => 20476,
                'endFilePos' => 144365,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4070,
            'endLine' => 4070,
            'startColumn' => 9,
            'endColumn' => 31,
            'parameterIndex' => 5,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add an embedded (inline) attachment from a file.
 * This can include images, sounds, and just about any other document type.
 * These differ from \'regular\' attachments in that they are intended to be
 * displayed inline with the message, not just attached for download.
 * This is used in HTML messages that embed the images
 * the HTML refers to using the `$cid` value in `img` tags, for example `<img src="cid:mylogo">`.
 * Never use a user-supplied path to a file!
 *
 * @param string $path        Path to the attachment
 * @param string $cid         Content ID of the attachment; Use this to reference
 *                            the content when using an embedded image in HTML
 * @param string $name        Overrides the attachment filename
 * @param string $encoding    File encoding (see $Encoding) defaults to `base64`
 * @param string $type        File MIME type (by default mapped from the `$path` filename\'s extension)
 * @param string $disposition Disposition to use: `inline` (default) or `attachment`
 *                            (unlikely you want this – {@see `addAttachment()`} instead)
 *
 * @return bool True on successfully adding an attachment
 * @throws Exception
 *
 */',
        'startLine' => 4064,
        'endLine' => 4113,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addStringEmbeddedImage' => 
      array (
        'name' => 'addStringEmbeddedImage',
        'parameters' => 
        array (
          'string' => 
          array (
            'name' => 'string',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4135,
            'endLine' => 4135,
            'startColumn' => 9,
            'endColumn' => 15,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'cid' => 
          array (
            'name' => 'cid',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4136,
            'endLine' => 4136,
            'startColumn' => 9,
            'endColumn' => 12,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'name' => 
          array (
            'name' => 'name',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 4137,
                'endLine' => 4137,
                'startTokenPos' => 20786,
                'startFilePos' => 146881,
                'endTokenPos' => 20786,
                'endFilePos' => 146882,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4137,
            'endLine' => 4137,
            'startColumn' => 9,
            'endColumn' => 18,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => 
            array (
              'code' => 'self::ENCODING_BASE64',
              'attributes' => 
              array (
                'startLine' => 4138,
                'endLine' => 4138,
                'startTokenPos' => 20793,
                'startFilePos' => 146905,
                'endTokenPos' => 20795,
                'endFilePos' => 146925,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4138,
            'endLine' => 4138,
            'startColumn' => 9,
            'endColumn' => 41,
            'parameterIndex' => 3,
            'isOptional' => true,
          ),
          'type' => 
          array (
            'name' => 'type',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 4139,
                'endLine' => 4139,
                'startTokenPos' => 20802,
                'startFilePos' => 146944,
                'endTokenPos' => 20802,
                'endFilePos' => 146945,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4139,
            'endLine' => 4139,
            'startColumn' => 9,
            'endColumn' => 18,
            'parameterIndex' => 4,
            'isOptional' => true,
          ),
          'disposition' => 
          array (
            'name' => 'disposition',
            'default' => 
            array (
              'code' => '\'inline\'',
              'attributes' => 
              array (
                'startLine' => 4140,
                'endLine' => 4140,
                'startTokenPos' => 20809,
                'startFilePos' => 146971,
                'endTokenPos' => 20809,
                'endFilePos' => 146978,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4140,
            'endLine' => 4140,
            'startColumn' => 9,
            'endColumn' => 31,
            'parameterIndex' => 5,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add an embedded stringified attachment.
 * This can include images, sounds, and just about any other document type.
 * If your filename doesn\'t contain an extension, be sure to set the $type to an appropriate MIME type.
 *
 * @param string $string      The attachment binary data
 * @param string $cid         Content ID of the attachment; Use this to reference
 *                            the content when using an embedded image in HTML
 * @param string $name        A filename for the attachment. If this contains an extension,
 *                            PHPMailer will attempt to set a MIME type for the attachment.
 *                            For example \'file.jpg\' would get an \'image/jpeg\' MIME type.
 * @param string $encoding    File encoding (see $Encoding), defaults to \'base64\'
 * @param string $type        MIME type - will be used in preference to any automatically derived type
 * @param string $disposition Disposition to use
 *
 * @throws Exception
 *
 * @return bool True on successfully adding an attachment
 */',
        'startLine' => 4134,
        'endLine' => 4174,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'validateEncoding' => 
      array (
        'name' => 'validateEncoding',
        'parameters' => 
        array (
          'encoding' => 
          array (
            'name' => 'encoding',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4183,
            'endLine' => 4183,
            'startColumn' => 41,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Validate encodings.
 *
 * @param string $encoding
 *
 * @return bool
 */',
        'startLine' => 4183,
        'endLine' => 4196,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'cidExists' => 
      array (
        'name' => 'cidExists',
        'parameters' => 
        array (
          'cid' => 
          array (
            'name' => 'cid',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4205,
            'endLine' => 4205,
            'startColumn' => 34,
            'endColumn' => 37,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check if an embedded attachment is present with this cid.
 *
 * @param string $cid
 *
 * @return bool
 */',
        'startLine' => 4205,
        'endLine' => 4214,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'inlineImageExists' => 
      array (
        'name' => 'inlineImageExists',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check if an inline attachment is present.
 *
 * @return bool
 */',
        'startLine' => 4221,
        'endLine' => 4230,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'attachmentExists' => 
      array (
        'name' => 'attachmentExists',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check if an attachment (non-inline) is present.
 *
 * @return bool
 */',
        'startLine' => 4237,
        'endLine' => 4246,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'alternativeExists' => 
      array (
        'name' => 'alternativeExists',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check if this message has an alternative body set.
 *
 * @return bool
 */',
        'startLine' => 4253,
        'endLine' => 4256,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearQueuedAddresses' => 
      array (
        'name' => 'clearQueuedAddresses',
        'parameters' => 
        array (
          'kind' => 
          array (
            'name' => 'kind',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4263,
            'endLine' => 4263,
            'startColumn' => 42,
            'endColumn' => 46,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear queued addresses of given kind.
 *
 * @param string $kind \'to\', \'cc\', or \'bcc\'
 */',
        'startLine' => 4263,
        'endLine' => 4271,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearAddresses' => 
      array (
        'name' => 'clearAddresses',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear all To recipients.
 */',
        'startLine' => 4276,
        'endLine' => 4283,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearCCs' => 
      array (
        'name' => 'clearCCs',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear all CC recipients.
 */',
        'startLine' => 4288,
        'endLine' => 4295,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearBCCs' => 
      array (
        'name' => 'clearBCCs',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear all BCC recipients.
 */',
        'startLine' => 4300,
        'endLine' => 4307,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearReplyTos' => 
      array (
        'name' => 'clearReplyTos',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear all ReplyTo recipients.
 */',
        'startLine' => 4312,
        'endLine' => 4316,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearAllRecipients' => 
      array (
        'name' => 'clearAllRecipients',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear all recipient types.
 */',
        'startLine' => 4321,
        'endLine' => 4328,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearAttachments' => 
      array (
        'name' => 'clearAttachments',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear all filesystem, string, and binary attachments.
 */',
        'startLine' => 4333,
        'endLine' => 4336,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearCustomHeaders' => 
      array (
        'name' => 'clearCustomHeaders',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear all custom headers.
 */',
        'startLine' => 4341,
        'endLine' => 4344,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'clearCustomHeader' => 
      array (
        'name' => 'clearCustomHeader',
        'parameters' => 
        array (
          'name' => 
          array (
            'name' => 'name',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4356,
            'endLine' => 4356,
            'startColumn' => 39,
            'endColumn' => 43,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'value' => 
          array (
            'name' => 'value',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 4356,
                'endLine' => 4356,
                'startTokenPos' => 21717,
                'startFilePos' => 152017,
                'endTokenPos' => 21717,
                'endFilePos' => 152020,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4356,
            'endLine' => 4356,
            'startColumn' => 46,
            'endColumn' => 58,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Clear a specific custom header by name or name and value.
 * $name value can be overloaded to contain
 * both header name and value (name:value).
 *
 * @param string      $name  Custom header name
 * @param string|null $value Header value
 *
 * @return bool True if a header was replaced successfully
 */',
        'startLine' => 4356,
        'endLine' => 4375,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'replaceCustomHeader' => 
      array (
        'name' => 'replaceCustomHeader',
        'parameters' => 
        array (
          'name' => 
          array (
            'name' => 'name',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4388,
            'endLine' => 4388,
            'startColumn' => 41,
            'endColumn' => 45,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'value' => 
          array (
            'name' => 'value',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 4388,
                'endLine' => 4388,
                'startTokenPos' => 21905,
                'startFilePos' => 153053,
                'endTokenPos' => 21905,
                'endFilePos' => 153056,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4388,
            'endLine' => 4388,
            'startColumn' => 48,
            'endColumn' => 60,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Replace a custom header.
 * $name value can be overloaded to contain
 * both header name and value (name:value).
 *
 * @param string      $name  Custom header name
 * @param string|null $value Header value
 *
 * @return bool True if a header was replaced successfully
 * @throws Exception
 */',
        'startLine' => 4388,
        'endLine' => 4417,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setError' => 
      array (
        'name' => 'setError',
        'parameters' => 
        array (
          'msg' => 
          array (
            'name' => 'msg',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4424,
            'endLine' => 4424,
            'startColumn' => 33,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add an error message to the error container.
 *
 * @param string $msg
 */',
        'startLine' => 4424,
        'endLine' => 4443,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'rfcDate' => 
      array (
        'name' => 'rfcDate',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Return the current date and time as an RFC 822 formatted date.
 *
 * @return string
 */',
        'startLine' => 4450,
        'endLine' => 4457,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'sanitiseDate' => 
      array (
        'name' => 'sanitiseDate',
        'parameters' => 
        array (
          'date' => 
          array (
            'name' => 'date',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4477,
            'endLine' => 4477,
            'startColumn' => 42,
            'endColumn' => 46,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Normalise a user-supplied date into a correctly-formatted RFC 5322 date value
 * string suitable for use in the Date header.
 *
 * Accepts:
 *  - A {@see \\DateTime} (or \\DateTimeImmutable) object
 *  - Any date/time string understood by PHP\'s DateTime constructor (RFC 5322, ISO 8601,
 *    Unix timestamp with leading "@", natural-language strings, etc.)
 *
 * Dates in the future are not permitted for email headers; if the parsed date is later
 * than "now" the method falls back to the current time via {@see self::rfcDate()}.
 * An empty value, a non-string/non-DateTime argument, or any value that cannot be
 * parsed will likewise fall back to {@see self::rfcDate()}.
 *
 * @param \\DateTime|\\DateTimeImmutable|string $date The date to normalise
 *
 * @return string An RFC 5322-formatted date string
 */',
        'startLine' => 4477,
        'endLine' => 4501,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 20,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'serverHostname' => 
      array (
        'name' => 'serverHostname',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the server hostname.
 * Returns \'localhost.localdomain\' if unknown.
 *
 * @return string
 */',
        'startLine' => 4509,
        'endLine' => 4526,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isValidHost' => 
      array (
        'name' => 'isValidHost',
        'parameters' => 
        array (
          'host' => 
          array (
            'name' => 'host',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4536,
            'endLine' => 4536,
            'startColumn' => 40,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Validate whether a string contains a valid value to use as a hostname or IP address.
 * IPv6 addresses must include [], e.g. `[::1]`, not just `::1`.
 *
 * @param string $host The host name or IP address to check
 *
 * @return bool
 */',
        'startLine' => 4536,
        'endLine' => 4559,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addressHasUnicodeLocalPart' => 
      array (
        'name' => 'addressHasUnicodeLocalPart',
        'parameters' => 
        array (
          'address' => 
          array (
            'name' => 'address',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4566,
            'endLine' => 4566,
            'startColumn' => 51,
            'endColumn' => 58,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check whether the supplied address uses Unicode in the local part.
 *
 * @return bool
 */',
        'startLine' => 4566,
        'endLine' => 4569,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'anyAddressHasUnicodeLocalPart' => 
      array (
        'name' => 'anyAddressHasUnicodeLocalPart',
        'parameters' => 
        array (
          'addresses' => 
          array (
            'name' => 'addresses',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4576,
            'endLine' => 4576,
            'startColumn' => 54,
            'endColumn' => 63,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check whether any of the supplied addresses use Unicode in the local part.
 *
 * @return bool
 */',
        'startLine' => 4576,
        'endLine' => 4587,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'needsSMTPUTF8' => 
      array (
        'name' => 'needsSMTPUTF8',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check whether the message requires SMTPUTF8 based on what\'s known so far.
 *
 * @return bool
 */',
        'startLine' => 4594,
        'endLine' => 4597,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'lang' => 
      array (
        'name' => 'lang',
        'parameters' => 
        array (
          'key' => 
          array (
            'name' => 'key',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4607,
            'endLine' => 4607,
            'startColumn' => 36,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get an error message in the current language.
 *
 * @param string $key
 *
 * @return string
 */',
        'startLine' => 4607,
        'endLine' => 4626,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getSmtpErrorMessage' => 
      array (
        'name' => 'getSmtpErrorMessage',
        'parameters' => 
        array (
          'base_key' => 
          array (
            'name' => 'base_key',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4634,
            'endLine' => 4634,
            'startColumn' => 42,
            'endColumn' => 50,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Build an error message starting with a generic one and adding details if possible.
 *
 * @param string $base_key
 * @return string
 */',
        'startLine' => 4634,
        'endLine' => 4646,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 4,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'isError' => 
      array (
        'name' => 'isError',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Check if an error occurred.
 *
 * @return bool True if an error did occur
 */',
        'startLine' => 4653,
        'endLine' => 4656,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'addCustomHeader' => 
      array (
        'name' => 'addCustomHeader',
        'parameters' => 
        array (
          'name' => 
          array (
            'name' => 'name',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4669,
            'endLine' => 4669,
            'startColumn' => 37,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'value' => 
          array (
            'name' => 'value',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 4669,
                'endLine' => 4669,
                'startTokenPos' => 23357,
                'startFilePos' => 162146,
                'endTokenPos' => 23357,
                'endFilePos' => 162149,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4669,
            'endLine' => 4669,
            'startColumn' => 44,
            'endColumn' => 56,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Add a custom header.
 * $name value can be overloaded to contain
 * both header name and value (name:value).
 *
 * @param string      $name  Custom header name
 * @param string|null $value Header value
 *
 * @return bool True if a header was set successfully
 * @throws Exception
 */',
        'startLine' => 4669,
        'endLine' => 4688,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getCustomHeaders' => 
      array (
        'name' => 'getCustomHeaders',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Returns all custom headers.
 *
 * @return array
 */',
        'startLine' => 4695,
        'endLine' => 4698,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'msgHTML' => 
      array (
        'name' => 'msgHTML',
        'parameters' => 
        array (
          'message' => 
          array (
            'name' => 'message',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4721,
            'endLine' => 4721,
            'startColumn' => 29,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'basedir' => 
          array (
            'name' => 'basedir',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 4721,
                'endLine' => 4721,
                'startTokenPos' => 23572,
                'startFilePos' => 164242,
                'endTokenPos' => 23572,
                'endFilePos' => 164243,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4721,
            'endLine' => 4721,
            'startColumn' => 39,
            'endColumn' => 51,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
          'advanced' => 
          array (
            'name' => 'advanced',
            'default' => 
            array (
              'code' => 'false',
              'attributes' => 
              array (
                'startLine' => 4721,
                'endLine' => 4721,
                'startTokenPos' => 23579,
                'startFilePos' => 164258,
                'endTokenPos' => 23579,
                'endFilePos' => 164262,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4721,
            'endLine' => 4721,
            'startColumn' => 54,
            'endColumn' => 70,
            'parameterIndex' => 2,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Create a message body from an HTML string.
 * Automatically inlines images and creates a plain-text version by converting the HTML,
 * overwriting any existing values in Body and AltBody.
 * Do not source $message content from user input!
 * $basedir is prepended when handling relative URLs, e.g. <img src="/images/a.png"> and must not be empty
 * will look for an image file in $basedir/images/a.png and convert it to inline.
 * If you don\'t provide a $basedir, relative paths will be left untouched (and thus probably break in email)
 * Converts data-uri images into embedded attachments.
 * If you don\'t want to apply these transformations to your HTML, just set Body and AltBody directly.
 *
 * @param string        $message    HTML message string
 * @param string        $basedir    Absolute path to a base directory to prepend to relative paths to images
 * @param bool|callable $advanced   Whether to use the internal HTML to text converter
 *                                  or your own custom converter
 * @return string The transformed message body
 *
 * @throws Exception
 *
 * @see PHPMailer::html2text()
 */',
        'startLine' => 4721,
        'endLine' => 4819,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'html2text' => 
      array (
        'name' => 'html2text',
        'parameters' => 
        array (
          'html' => 
          array (
            'name' => 'html',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4845,
            'endLine' => 4845,
            'startColumn' => 31,
            'endColumn' => 35,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'advanced' => 
          array (
            'name' => 'advanced',
            'default' => 
            array (
              'code' => 'false',
              'attributes' => 
              array (
                'startLine' => 4845,
                'endLine' => 4845,
                'startTokenPos' => 24411,
                'startFilePos' => 170005,
                'endTokenPos' => 24411,
                'endFilePos' => 170009,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4845,
            'endLine' => 4845,
            'startColumn' => 38,
            'endColumn' => 54,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Convert an HTML string into plain text.
 * This is used by msgHTML().
 * Note - older versions of this function used a bundled advanced converter
 * which was removed for license reasons in #232.
 * Example usage:
 *
 * ```php
 * //Use default conversion
 * $plain = $mail->html2text($html);
 * //Use your own custom converter
 * $plain = $mail->html2text($html, function($html) {
 *     $converter = new MyHtml2text($html);
 *     return $converter->get_text();
 * });
 * ```
 *
 * @param string        $html     The HTML text to convert
 * @param bool|callable $advanced Any boolean value to use the internal converter,
 *                                or provide your own callable for custom conversion.
 *                                *Never* pass user-supplied data into this parameter
 *
 * @return string
 */',
        'startLine' => 4845,
        'endLine' => 4856,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      '_mime_types' => 
      array (
        'name' => '_mime_types',
        'parameters' => 
        array (
          'ext' => 
          array (
            'name' => 'ext',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 4865,
                'endLine' => 4865,
                'startTokenPos' => 24489,
                'startFilePos' => 170533,
                'endTokenPos' => 24489,
                'endFilePos' => 170534,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4865,
            'endLine' => 4865,
            'startColumn' => 40,
            'endColumn' => 48,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the MIME type for a file extension.
 *
 * @param string $ext File extension
 *
 * @return string MIME type of file
 */',
        'startLine' => 4865,
        'endLine' => 4988,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'filenameToType' => 
      array (
        'name' => 'filenameToType',
        'parameters' => 
        array (
          'filename' => 
          array (
            'name' => 'filename',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 4998,
            'endLine' => 4998,
            'startColumn' => 43,
            'endColumn' => 51,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Map a file name to a MIME type.
 * Defaults to \'application/octet-stream\', i.e.. arbitrary binary data.
 *
 * @param string $filename A file name or full path, does not need to exist as a file
 *
 * @return string
 */',
        'startLine' => 4998,
        'endLine' => 5008,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'mb_pathinfo' => 
      array (
        'name' => 'mb_pathinfo',
        'parameters' => 
        array (
          'path' => 
          array (
            'name' => 'path',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5022,
            'endLine' => 5022,
            'startColumn' => 40,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'options' => 
          array (
            'name' => 'options',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 5022,
                'endLine' => 5022,
                'startTokenPos' => 25439,
                'startFilePos' => 177138,
                'endTokenPos' => 25439,
                'endFilePos' => 177141,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5022,
            'endLine' => 5022,
            'startColumn' => 47,
            'endColumn' => 61,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Multi-byte-safe pathinfo replacement.
 * Drop-in replacement for pathinfo(), but multibyte- and cross-platform-safe.
 *
 * @see https://www.php.net/manual/en/function.pathinfo.php#107461
 *
 * @param string     $path    A filename or path, does not need to exist as a file
 * @param int|string $options Either a PATHINFO_* constant,
 *                            or a string name to return only the specified piece
 *
 * @return string|array
 */',
        'startLine' => 5022,
        'endLine' => 5056,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'set' => 
      array (
        'name' => 'set',
        'parameters' => 
        array (
          'name' => 
          array (
            'name' => 'name',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5072,
            'endLine' => 5072,
            'startColumn' => 25,
            'endColumn' => 29,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'value' => 
          array (
            'name' => 'value',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 5072,
                'endLine' => 5072,
                'startTokenPos' => 25728,
                'startFilePos' => 178919,
                'endTokenPos' => 25728,
                'endFilePos' => 178920,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5072,
            'endLine' => 5072,
            'startColumn' => 32,
            'endColumn' => 42,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set or reset instance properties.
 * You should avoid this function - it\'s more verbose, less efficient, more error-prone and
 * harder to debug than setting properties directly.
 * Usage Example:
 * `$mail->set(\'SMTPSecure\', static::ENCRYPTION_STARTTLS);`
 *   is the same as:
 * `$mail->SMTPSecure = static::ENCRYPTION_STARTTLS;`.
 *
 * @param string $name  The property name to set
 * @param mixed  $value The value to set the property to
 *
 * @return bool
 */',
        'startLine' => 5072,
        'endLine' => 5082,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'secureHeader' => 
      array (
        'name' => 'secureHeader',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5091,
            'endLine' => 5091,
            'startColumn' => 34,
            'endColumn' => 37,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Strip newlines to prevent header injection.
 *
 * @param string $str
 *
 * @return string
 */',
        'startLine' => 5091,
        'endLine' => 5094,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'normalizeBreaks' => 
      array (
        'name' => 'normalizeBreaks',
        'parameters' => 
        array (
          'text' => 
          array (
            'name' => 'text',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5106,
            'endLine' => 5106,
            'startColumn' => 44,
            'endColumn' => 48,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'breaktype' => 
          array (
            'name' => 'breaktype',
            'default' => 
            array (
              'code' => 'null',
              'attributes' => 
              array (
                'startLine' => 5106,
                'endLine' => 5106,
                'startTokenPos' => 25843,
                'startFilePos' => 179822,
                'endTokenPos' => 25843,
                'endFilePos' => 179825,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5106,
            'endLine' => 5106,
            'startColumn' => 51,
            'endColumn' => 67,
            'parameterIndex' => 1,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Normalize line breaks in a string.
 * Converts UNIX LF, Mac CR and Windows CRLF line breaks into a single line break format.
 * Defaults to CRLF (for message bodies) and preserves consecutive breaks.
 *
 * @param string $text
 * @param string $breaktype What kind of line break to use; defaults to static::$LE
 *
 * @return string
 */',
        'startLine' => 5106,
        'endLine' => 5119,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'stripTrailingWSP' => 
      array (
        'name' => 'stripTrailingWSP',
        'parameters' => 
        array (
          'text' => 
          array (
            'name' => 'text',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5128,
            'endLine' => 5128,
            'startColumn' => 45,
            'endColumn' => 49,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Remove trailing whitespace from a string.
 *
 * @param string $text
 *
 * @return string The text to remove whitespace from
 */',
        'startLine' => 5128,
        'endLine' => 5131,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'stripTrailingBreaks' => 
      array (
        'name' => 'stripTrailingBreaks',
        'parameters' => 
        array (
          'text' => 
          array (
            'name' => 'text',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5140,
            'endLine' => 5140,
            'startColumn' => 48,
            'endColumn' => 52,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Strip trailing line breaks from a string.
 *
 * @param string $text
 *
 * @return string The text to remove breaks from
 */',
        'startLine' => 5140,
        'endLine' => 5143,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getLE' => 
      array (
        'name' => 'getLE',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Return the current line break format string.
 *
 * @return string
 */',
        'startLine' => 5150,
        'endLine' => 5153,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setLE' => 
      array (
        'name' => 'setLE',
        'parameters' => 
        array (
          'le' => 
          array (
            'name' => 'le',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5160,
            'endLine' => 5160,
            'startColumn' => 37,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set the line break format string, e.g. "\\r\\n".
 *
 * @param string $le
 */',
        'startLine' => 5160,
        'endLine' => 5163,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 18,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'sign' => 
      array (
        'name' => 'sign',
        'parameters' => 
        array (
          'cert_filename' => 
          array (
            'name' => 'cert_filename',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5173,
            'endLine' => 5173,
            'startColumn' => 26,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'key_filename' => 
          array (
            'name' => 'key_filename',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5173,
            'endLine' => 5173,
            'startColumn' => 42,
            'endColumn' => 54,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'key_pass' => 
          array (
            'name' => 'key_pass',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5173,
            'endLine' => 5173,
            'startColumn' => 57,
            'endColumn' => 65,
            'parameterIndex' => 2,
            'isOptional' => false,
          ),
          'extracerts_filename' => 
          array (
            'name' => 'extracerts_filename',
            'default' => 
            array (
              'code' => '\'\'',
              'attributes' => 
              array (
                'startLine' => 5173,
                'endLine' => 5173,
                'startTokenPos' => 26061,
                'startFilePos' => 181464,
                'endTokenPos' => 26061,
                'endFilePos' => 181465,
              ),
            ),
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5173,
            'endLine' => 5173,
            'startColumn' => 68,
            'endColumn' => 92,
            'parameterIndex' => 3,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set the public and private key files and password for S/MIME signing.
 *
 * @param string $cert_filename
 * @param string $key_filename
 * @param string $key_pass            Password for private key
 * @param string $extracerts_filename Optional path to chain certificate
 */',
        'startLine' => 5173,
        'endLine' => 5179,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'DKIM_QP' => 
      array (
        'name' => 'DKIM_QP',
        'parameters' => 
        array (
          'txt' => 
          array (
            'name' => 'txt',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5188,
            'endLine' => 5188,
            'startColumn' => 29,
            'endColumn' => 32,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Quoted-Printable-encode a DKIM header.
 *
 * @param string $txt
 *
 * @return string
 */',
        'startLine' => 5188,
        'endLine' => 5202,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'DKIM_Sign' => 
      array (
        'name' => 'DKIM_Sign',
        'parameters' => 
        array (
          'signHeader' => 
          array (
            'name' => 'signHeader',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5213,
            'endLine' => 5213,
            'startColumn' => 31,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Generate a DKIM signature.
 *
 * @param string $signHeader
 *
 * @throws Exception
 *
 * @return string The DKIM signature value
 */',
        'startLine' => 5213,
        'endLine' => 5244,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'DKIM_HeaderC' => 
      array (
        'name' => 'DKIM_HeaderC',
        'parameters' => 
        array (
          'signHeader' => 
          array (
            'name' => 'signHeader',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5257,
            'endLine' => 5257,
            'startColumn' => 34,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Generate a DKIM canonicalization header.
 * Uses the \'relaxed\' algorithm from RFC6376 section 3.4.2.
 * Canonicalized headers should *always* use CRLF, regardless of mailer setting.
 *
 * @see https://www.rfc-editor.org/rfc/rfc6376#section-3.4.2
 *
 * @param string $signHeader Header
 *
 * @return string
 */',
        'startLine' => 5257,
        'endLine' => 5288,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'DKIM_BodyC' => 
      array (
        'name' => 'DKIM_BodyC',
        'parameters' => 
        array (
          'body' => 
          array (
            'name' => 'body',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5301,
            'endLine' => 5301,
            'startColumn' => 32,
            'endColumn' => 36,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Generate a DKIM canonicalization body.
 * Uses the \'simple\' algorithm from RFC6376 section 3.4.3.
 * Canonicalized bodies should *always* use CRLF, regardless of mailer setting.
 *
 * @see https://www.rfc-editor.org/rfc/rfc6376#section-3.4.3
 *
 * @param string $body Message Body
 *
 * @return string
 */',
        'startLine' => 5301,
        'endLine' => 5311,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'DKIM_Add' => 
      array (
        'name' => 'DKIM_Add',
        'parameters' => 
        array (
          'headers_line' => 
          array (
            'name' => 'headers_line',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5324,
            'endLine' => 5324,
            'startColumn' => 30,
            'endColumn' => 42,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'subject' => 
          array (
            'name' => 'subject',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5324,
            'endLine' => 5324,
            'startColumn' => 45,
            'endColumn' => 52,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'body' => 
          array (
            'name' => 'body',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5324,
            'endLine' => 5324,
            'startColumn' => 55,
            'endColumn' => 59,
            'parameterIndex' => 2,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Create the DKIM header and body in a new message header.
 *
 * @param string $headers_line Header lines
 * @param string $subject      Subject
 * @param string $body         Body
 *
 * @throws Exception
 *
 * @return string
 */',
        'startLine' => 5324,
        'endLine' => 5458,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'hasLineLongerThanMax' => 
      array (
        'name' => 'hasLineLongerThanMax',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5468,
            'endLine' => 5468,
            'startColumn' => 49,
            'endColumn' => 52,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Detect if a string contains a line longer than the maximum line length
 * allowed by RFC 2822 section 2.1.1.
 *
 * @param string $str
 *
 * @return bool
 */',
        'startLine' => 5468,
        'endLine' => 5471,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'quotedString' => 
      array (
        'name' => 'quotedString',
        'parameters' => 
        array (
          'str' => 
          array (
            'name' => 'str',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5483,
            'endLine' => 5483,
            'startColumn' => 41,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * If a string contains any "special" characters, double-quote the name,
 * and escape any double quotes with a backslash.
 *
 * @param string $str
 *
 * @return string
 *
 * @see RFC822 3.4.1
 */',
        'startLine' => 5483,
        'endLine' => 5493,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 17,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getToAddresses' => 
      array (
        'name' => 'getToAddresses',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Allows for public read access to \'to\' property.
 * Before the send() call, queued addresses (i.e. with IDN) are not yet included.
 *
 * @return array
 */',
        'startLine' => 5501,
        'endLine' => 5504,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getCcAddresses' => 
      array (
        'name' => 'getCcAddresses',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Allows for public read access to \'cc\' property.
 * Before the send() call, queued addresses (i.e. with IDN) are not yet included.
 *
 * @return array
 */',
        'startLine' => 5512,
        'endLine' => 5515,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getBccAddresses' => 
      array (
        'name' => 'getBccAddresses',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Allows for public read access to \'bcc\' property.
 * Before the send() call, queued addresses (i.e. with IDN) are not yet included.
 *
 * @return array
 */',
        'startLine' => 5523,
        'endLine' => 5526,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getReplyToAddresses' => 
      array (
        'name' => 'getReplyToAddresses',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Allows for public read access to \'ReplyTo\' property.
 * Before the send() call, queued addresses (i.e. with IDN) are not yet included.
 *
 * @return array
 */',
        'startLine' => 5534,
        'endLine' => 5537,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getAllRecipientAddresses' => 
      array (
        'name' => 'getAllRecipientAddresses',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Allows for public read access to \'all_recipients\' property.
 * Before the send() call, queued addresses (i.e. with IDN) are not yet included.
 *
 * @return array
 */',
        'startLine' => 5545,
        'endLine' => 5548,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'doCallback' => 
      array (
        'name' => 'doCallback',
        'parameters' => 
        array (
          'isSent' => 
          array (
            'name' => 'isSent',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 35,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'to' => 
          array (
            'name' => 'to',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 44,
            'endColumn' => 46,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
          'cc' => 
          array (
            'name' => 'cc',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 49,
            'endColumn' => 51,
            'parameterIndex' => 2,
            'isOptional' => false,
          ),
          'bcc' => 
          array (
            'name' => 'bcc',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 54,
            'endColumn' => 57,
            'parameterIndex' => 3,
            'isOptional' => false,
          ),
          'subject' => 
          array (
            'name' => 'subject',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 60,
            'endColumn' => 67,
            'parameterIndex' => 4,
            'isOptional' => false,
          ),
          'body' => 
          array (
            'name' => 'body',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 70,
            'endColumn' => 74,
            'parameterIndex' => 5,
            'isOptional' => false,
          ),
          'from' => 
          array (
            'name' => 'from',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 77,
            'endColumn' => 81,
            'parameterIndex' => 6,
            'isOptional' => false,
          ),
          'extra' => 
          array (
            'name' => 'extra',
            'default' => NULL,
            'type' => NULL,
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5562,
            'endLine' => 5562,
            'startColumn' => 84,
            'endColumn' => 89,
            'parameterIndex' => 7,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Perform a callback.
 *
 * @param bool   $isSent
 * @param array  $to
 * @param array  $cc
 * @param array  $bcc
 * @param string $subject
 * @param string $body
 * @param string $from
 * @param array  $extra
 */',
        'startLine' => 5562,
        'endLine' => 5567,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'getOAuth' => 
      array (
        'name' => 'getOAuth',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Get the OAuthTokenProvider instance.
 *
 * @return OAuthTokenProvider
 */',
        'startLine' => 5574,
        'endLine' => 5577,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
      'setOAuth' => 
      array (
        'name' => 'setOAuth',
        'parameters' => 
        array (
          'oauth' => 
          array (
            'name' => 'oauth',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'PHPMailer\\PHPMailer\\OAuthTokenProvider',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 5582,
            'endLine' => 5582,
            'startColumn' => 30,
            'endColumn' => 54,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * Set an OAuthTokenProvider instance.
 */',
        'startLine' => 5582,
        'endLine' => 5585,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PHPMailer\\PHPMailer',
        'declaringClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'implementingClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'currentClassName' => 'PHPMailer\\PHPMailer\\PHPMailer',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));