<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Middleware\MiddlewareInterface.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b731fd6df6551c27c2c43f78047d7688' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Middleware',
         'uses' => 
        array (
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
        ),
         'className' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareInterface',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '889d90b61a50cf87fcaec732f0ae6319' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Middleware',
         'uses' => 
        array (
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
        ),
         'className' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareInterface',
         'functionName' => 'process',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Middleware\\MiddlewareInterface.php' => 'f0fedf1854faa81d5114b87efdd25a6cf370dcd5ca7070c9ea981356b5ed1f24',
    ),
  ),
));