<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Route.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '4c3697ba4f958b778b5daaef9626ed05' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Route',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0a4389df59f5467b3883c760a1ec4934' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Route',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a749d6d73b90264fa607d2393a42f324' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Route',
         'functionName' => 'match',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Route.php' => 'c96487a3eaa03dc52c4aa86a8492bcfe4f0e4f0f98ed83120219b45942478730',
    ),
  ),
));