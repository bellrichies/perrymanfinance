<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Exceptions\ValidationException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '1512613ab7102340591f452449cc9fa9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Exceptions',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e489069204fc44b7f5439b77ddda256c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Exceptions',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Exceptions\\ValidationException.php' => 'f360128dccac0bb401e2ae8a6e16f30bdee604cdfa99e36213958f630468b4ea',
    ),
  ),
));