<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\app\Domain\Content\PublicationWorkflow.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PerrymanFinance\Domain\Content\PublicationWorkflow
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-7c9fa85a7cda56fddb1371706ba85d81ec8a98145172f9e5bb3e3ccd8baa6780',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
        'filename' => 'D:/Perryman/backend/app/Domain/Content/PublicationWorkflow.php',
      ),
    ),
    'namespace' => 'PerrymanFinance\\Domain\\Content',
    'name' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
    'shortName' => 'PublicationWorkflow',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 9,
    'endLine' => 25,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
      'TRANSITIONS' => 
      array (
        'declaringClassName' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
        'implementingClassName' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
        'name' => 'TRANSITIONS',
        'modifiers' => 4,
        'type' => NULL,
        'value' => 
        array (
          'code' => '[\'draft\' => [\'draft\', \'review\'], \'review\' => [\'review\', \'draft\', \'published\'], \'published\' => [\'published\', \'draft\', \'archived\'], \'archived\' => [\'archived\', \'draft\']]',
          'attributes' => 
          array (
            'startLine' => 12,
            'endLine' => 17,
            'startTokenPos' => 38,
            'startFilePos' => 244,
            'endTokenPos' => 94,
            'endFilePos' => 448,
          ),
        ),
        'docComment' => '/** @var array<string, list<string>> */',
        'attributes' => 
        array (
        ),
        'startLine' => 12,
        'endLine' => 17,
        'startColumn' => 5,
        'endColumn' => 6,
      ),
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'guard' => 
      array (
        'name' => 'guard',
        'parameters' => 
        array (
          'current' => 
          array (
            'name' => 'current',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 19,
            'endLine' => 19,
            'startColumn' => 27,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
          'next' => 
          array (
            'name' => 'next',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 19,
            'endLine' => 19,
            'startColumn' => 44,
            'endColumn' => 55,
            'parameterIndex' => 1,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 19,
        'endLine' => 24,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => true,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Domain\\Content',
        'declaringClassName' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
        'implementingClassName' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
        'currentClassName' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));