<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Domain\ClientAccount\ClientUser.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '851385fb4775da4e7475c3a2e9cd51ef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\ClientAccount',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e52e2d097960bfbf73b663524a3caaea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\ClientAccount',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3572f51f03612343df66ce648eb7054d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\ClientAccount',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
         'functionName' => 'canLogin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3f2e4d899536404a57bf59154f630028' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\ClientAccount',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
         'functionName' => 'publicData',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Domain\\ClientAccount\\ClientUser.php' => '9ae8358d40b1074dae38c894009dcb001df69d48c5f19449c075c3f8753782f7',
    ),
  ),
));