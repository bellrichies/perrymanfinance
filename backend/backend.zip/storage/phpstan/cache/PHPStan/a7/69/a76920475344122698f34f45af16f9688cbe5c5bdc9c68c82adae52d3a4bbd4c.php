<?php declare(strict_types = 1);

// osfsl-phar://D:/Perryman/backend/vendor/phpstan/phpstan/phpstan.phar/src/Analyser/ExpressionResultStorage.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-1ac0dbdc7201d6a9ed5918d08515f7d209c0646f8eac24f36a7991798411619c-8.3.33',
   'data' => 
  array (
    'classes' => 
    array (
      'phpstan\\analyser\\expressionresultstorage' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));