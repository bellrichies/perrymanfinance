<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Controllers\ClientAuthController.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'c0ea3955e57f3f200aef02c2ec4b8675' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9ce21c63b01e22da66b185855c156d69' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a62b3df522b3880090096a7d8701eca1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'register',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '99e766fdf729648092ee76165e1c3786' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'verifyEmail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b09025a875c60bb99103d4e1ad5dd9d1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'login',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6063ae5bdec0a241e3dce9496b044df8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'refresh',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3892d2ed7fe5ca57fed92a09333e6f47' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'logout',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '532e95dd31a7c93d5167890cc723231e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'forgotPassword',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6333d1f375ee876d59af1a39db679728' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'resetPassword',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7359b7f5daa04f9c8c0ad52a49c75243' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'me',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '36aad7bda66d44b69ba2c673ec764360' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'sessionResponse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '26cdec0c0359ae410ff455aee7328245' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'required',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '990454452e9a78497ca00f9790f4be00' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'cookie',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c2af467a60992ef7cd6f6adb724cbaab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'refreshCookie',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9032eca09168610dabdde0cd3c915839' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'expiredCookie',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c516bcf947117d1289595bd9fd53cb8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'ip',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '070a299c9767897b7b54e96966c4b0bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'apiresponsefactory' => 'PerrymanFinance\\Http\\ApiResponseFactory',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'clientidentityservice' => 'PerrymanFinance\\Services\\ClientAccount\\ClientIdentityService',
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\ClientAuthController',
         'functionName' => 'requestId',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Controllers\\ClientAuthController.php' => 'fab110e5f842b826b257b4de1d4f86fc10f72dce054668f2cf455e36b09ebf8f',
    ),
  ),
));