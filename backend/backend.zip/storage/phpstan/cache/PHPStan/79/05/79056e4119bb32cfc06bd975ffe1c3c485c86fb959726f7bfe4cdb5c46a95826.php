<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\app\Http\Exceptions\UnauthorizedException.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PerrymanFinance\Http\Exceptions\UnauthorizedException
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-04ac1de761bf556b267d46f9826d6c3c7681f70346f6dad574aedb186c50e530',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
        'filename' => 'D:/Perryman/backend/app/Http/Exceptions/UnauthorizedException.php',
      ),
    ),
    'namespace' => 'PerrymanFinance\\Http\\Exceptions',
    'name' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
    'shortName' => 'UnauthorizedException',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 13,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PerrymanFinance\\Http\\Exceptions\\HttpException',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
          'message' => 
          array (
            'name' => 'message',
            'default' => 
            array (
              'code' => '\'Authentication is required.\'',
              'attributes' => 
              array (
                'startLine' => 9,
                'endLine' => 9,
                'startTokenPos' => 39,
                'startFilePos' => 185,
                'endTokenPos' => 39,
                'endFilePos' => 213,
              ),
            ),
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 9,
            'endLine' => 9,
            'startColumn' => 33,
            'endColumn' => 79,
            'parameterIndex' => 0,
            'isOptional' => true,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 9,
        'endLine' => 12,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Http\\Exceptions',
        'declaringClassName' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
        'implementingClassName' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
        'currentClassName' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));