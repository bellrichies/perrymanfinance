<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Http\RouterTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Http\RouterTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-aa56709e1f4e99c18e6def837c4c195d841254c55e4cac01280a3617baf8142f',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Http\\RouterTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Http/RouterTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Http',
    'name' => 'Tests\\Unit\\Http\\RouterTest',
    'shortName' => 'RouterTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 15,
    'endLine' => 40,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testGroupsAndRouteParametersAreMatched' => 
      array (
        'name' => 'testGroupsAndRouteParametersAreMatched',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 17,
        'endLine' => 31,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Http',
        'declaringClassName' => 'Tests\\Unit\\Http\\RouterTest',
        'implementingClassName' => 'Tests\\Unit\\Http\\RouterTest',
        'currentClassName' => 'Tests\\Unit\\Http\\RouterTest',
        'aliasName' => NULL,
      ),
      'testKnownPathWithWrongMethodThrowsMethodNotAllowed' => 
      array (
        'name' => 'testKnownPathWithWrongMethodThrowsMethodNotAllowed',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 32,
        'endLine' => 39,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Http',
        'declaringClassName' => 'Tests\\Unit\\Http\\RouterTest',
        'implementingClassName' => 'Tests\\Unit\\Http\\RouterTest',
        'currentClassName' => 'Tests\\Unit\\Http\\RouterTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));