<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-UPLOAD_ERR_OK
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'UPLOAD_ERR_OK',
        'filename' => 'phpstorm-stubs:Core/Core_d.stub',
        'extensionName' => 'Core',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'UPLOAD_ERR_OK',
    'shortName' => 'UPLOAD_ERR_OK',
    'value' => 
    array (
      'code' => '0',
      'attributes' => 
      array (
        'startLine' => 3,
        'endLine' => 3,
        'startTokenPos' => 7,
        'startFilePos' => 31,
        'endTokenPos' => 7,
        'endFilePos' => 31,
      ),
    ),
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 3,
    'endLine' => 3,
    'startColumn' => 1,
    'endColumn' => 26,
    'namespace' => NULL,
  ),
));