<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\app\Http\Exceptions\ForbiddenException.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PerrymanFinance\Http\Exceptions\ForbiddenException
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-933f25ff33d9ce9ef5eec1894e09c24c6517e930e1d73666d2de085d4a614e16',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PerrymanFinance\\Http\\Exceptions\\ForbiddenException',
        'filename' => 'D:/Perryman/backend/app/Http/Exceptions/ForbiddenException.php',
      ),
    ),
    'namespace' => 'PerrymanFinance\\Http\\Exceptions',
    'name' => 'PerrymanFinance\\Http\\Exceptions\\ForbiddenException',
    'shortName' => 'ForbiddenException',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 13,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PerrymanFinance\\Http\\Exceptions\\HttpException',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 9,
        'endLine' => 12,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Http\\Exceptions',
        'declaringClassName' => 'PerrymanFinance\\Http\\Exceptions\\ForbiddenException',
        'implementingClassName' => 'PerrymanFinance\\Http\\Exceptions\\ForbiddenException',
        'currentClassName' => 'PerrymanFinance\\Http\\Exceptions\\ForbiddenException',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));