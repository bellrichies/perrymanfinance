<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\AuditLogRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '1dfb2ff9fdf347ebf8306b115d031015' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bbe647098ba4f0f7c042ec0b7175e8aa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
         'functionName' => 'record',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\AuditLogRepository.php' => '5018cb8cbc1776664b12fef1b3fe2b2eab174859eeb549e6c19f36e66dfb1b3b',
    ),
  ),
));