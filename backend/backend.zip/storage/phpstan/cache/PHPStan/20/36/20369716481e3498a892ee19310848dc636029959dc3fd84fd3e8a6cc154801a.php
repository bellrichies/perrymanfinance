<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\ContentRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'df91142880b2e47243f520e864f85b15' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ed8835cce5cd2d0d1184d7e673e8ba72' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'pages',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa243b35d6748d2592d268162f040221' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'page',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '249cc92247b31b5f7b0f78d7a14a2a05' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'insertPage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd05dcdfb843e29b8092a9d0692f58b5a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'updatePage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4c509ace22b5561c01876854c6015bbc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'replaceSections',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '42ff67736478c8968b5ce4d5018618d4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'deletePage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5786f6be92711843824b55005fab0f2d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'legalDocuments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0811d9f8efbb9830676d3d8ce64cf9b2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'legal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4bc2833cbd9cf9671111985f2f1e9ba5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'insertLegal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '11332fd77c45a870f74c105920b13f1c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'updateLegal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '284e493ca2cbccb22f3a98d42515a38f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'settings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9ccbce7db1655b65cf7e5806d2275d71' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'upsertSetting',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '929aacf6881b4e736ae352deb8779c50' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'deleteSetting',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '44af3d126efc84e9d4aa6331251cc53e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'seo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '009ebb65cb345beadcbaa34a5c3b8b8f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'upsertSeo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c29aff789b408faec8727bfbcdec1af4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'deleteSeo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '65b5aad7dc8d02551366536c7e7a3d9b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'sitemapEntries',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f6bba4b3ab096d061e838afa79b329b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'publishedFaqs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3499aa518a8ce2ddee7c733fe86173c6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'redirect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b1d392658c366174ad9ece56fa33034f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'upsertRedirect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '15f6182f3f361e70d2fc8d631cd68717' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'retargetRedirectDestinations',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '11638394e578500666a75157db31ff3c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'ownerColumn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3ae50c0e2d0f7c80ebf4fcb5089a1a60' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dfe222b5d12cf2a89e86b50cc1801a75' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'decodePage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0b5b62574d690a5617430e97f1dea7bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'decodeSeo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cbead92a5d69952f85cb32be6172bbe0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ContentRepository',
         'functionName' => 'decodeSeoEntry',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\ContentRepository.php' => '4f5016942b4a0938107f24842452c282083cbdea6ccde55bc5da1cf1d749ce52',
    ),
  ),
));