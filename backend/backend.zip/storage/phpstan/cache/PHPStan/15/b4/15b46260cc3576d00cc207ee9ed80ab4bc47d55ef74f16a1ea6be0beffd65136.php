<?php declare(strict_types = 1);

// osfsl-phar://D:/Perryman/backend/vendor/phpstan/phpstan/phpstan.phar/src/Cache/ArenaCache.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6e8e297c42a5c238ab88d309b3f96f6ea78fc7cccf8a67b87c93a866d52edba9-8.3.33',
   'data' => 
  array (
    'classes' => 
    array (
      'phpstan\\cache\\arenacache' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));