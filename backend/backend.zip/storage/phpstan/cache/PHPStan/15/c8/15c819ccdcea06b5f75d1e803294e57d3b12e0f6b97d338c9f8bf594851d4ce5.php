<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Feature\CoreFrameworkTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Feature\CoreFrameworkTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-8e178de0e4f9f9a7af8b0e09bc076539b5b7255f6258ea31f4e1867e156a5807',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Feature\\CoreFrameworkTest',
        'filename' => 'D:/Perryman/backend/tests/Feature/CoreFrameworkTest.php',
      ),
    ),
    'namespace' => 'Tests\\Feature',
    'name' => 'Tests\\Feature\\CoreFrameworkTest',
    'shortName' => 'CoreFrameworkTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 14,
    'endLine' => 54,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testProductionMasksErrorsEvenWithDebugEnabled' => 
      array (
        'name' => 'testProductionMasksErrorsEvenWithDebugEnabled',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 16,
        'endLine' => 27,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => true,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'implementingClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'currentClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'aliasName' => NULL,
      ),
      'testNotFoundAndMethodNotAllowedAreMappedToSafeApiErrors' => 
      array (
        'name' => 'testNotFoundAndMethodNotAllowedAreMappedToSafeApiErrors',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 29,
        'endLine' => 39,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'implementingClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'currentClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'aliasName' => NULL,
      ),
      'testUnexpectedExceptionIsMasked' => 
      array (
        'name' => 'testUnexpectedExceptionIsMasked',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 40,
        'endLine' => 53,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => true,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'implementingClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'currentClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));