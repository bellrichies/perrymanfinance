<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Feature\CoreFrameworkTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Feature\CoreFrameworkTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-3212b535521e37841c4d2938223ce5d171a4c538423157218146e9c676783566',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Feature\\CoreFrameworkTest',
        'filename' => 'D:/Perryman/backend/tests/Feature/CoreFrameworkTest.php',
      ),
    ),
    'namespace' => 'Tests\\Feature',
    'name' => 'Tests\\Feature\\CoreFrameworkTest',
    'shortName' => 'CoreFrameworkTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 14,
    'endLine' => 50,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testProductionMasksErrorsEvenWithDebugEnabled' => 
      array (
        'name' => 'testProductionMasksErrorsEvenWithDebugEnabled',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 16,
        'endLine' => 25,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => true,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'implementingClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'currentClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'aliasName' => NULL,
      ),
      'testNotFoundAndMethodNotAllowedAreMappedToSafeApiErrors' => 
      array (
        'name' => 'testNotFoundAndMethodNotAllowedAreMappedToSafeApiErrors',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 27,
        'endLine' => 37,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'implementingClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'currentClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'aliasName' => NULL,
      ),
      'testUnexpectedExceptionIsMasked' => 
      array (
        'name' => 'testUnexpectedExceptionIsMasked',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 38,
        'endLine' => 49,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => true,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'implementingClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'currentClassName' => 'Tests\\Feature\\CoreFrameworkTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));