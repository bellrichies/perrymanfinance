<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Http\SecurityHeadersMiddlewareTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Http\SecurityHeadersMiddlewareTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-7d543d4440ac23a1c2aa3b1747b1f95ceeda1bf744efdbd4d8e0f561ca031e67',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Http/SecurityHeadersMiddlewareTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Http',
    'name' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
    'shortName' => 'SecurityHeadersMiddlewareTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 13,
    'endLine' => 39,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testProductionHttpsResponseIncludesSecurityAndPublicCacheHeaders' => 
      array (
        'name' => 'testProductionHttpsResponseIncludesSecurityAndPublicCacheHeaders',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 15,
        'endLine' => 27,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Http',
        'declaringClassName' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
        'implementingClassName' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
        'currentClassName' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
        'aliasName' => NULL,
      ),
      'testAdminResponsesAreNotGivenPublicCacheHeaders' => 
      array (
        'name' => 'testAdminResponsesAreNotGivenPublicCacheHeaders',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 29,
        'endLine' => 38,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Http',
        'declaringClassName' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
        'implementingClassName' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
        'currentClassName' => 'Tests\\Unit\\Http\\SecurityHeadersMiddlewareTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));