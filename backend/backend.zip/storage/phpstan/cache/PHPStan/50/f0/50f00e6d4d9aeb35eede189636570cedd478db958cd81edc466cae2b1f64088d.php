<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\database\seeders\DevAdminSeeder.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PerrymanFinance\Database\Seeders\DevAdminSeeder
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-1ce9a56d8b3b9d78d51ed257e0cf2720fbaf5c3a5824e78730c739858fc1e099',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'filename' => 'D:/Perryman/backend/database/seeders/DevAdminSeeder.php',
      ),
    ),
    'namespace' => 'PerrymanFinance\\Database\\Seeders',
    'name' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
    'shortName' => 'DevAdminSeeder',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 11,
    'endLine' => 64,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
      0 => 'PerrymanFinance\\Database\\Seeders\\Seeder',
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
      'EMAIL' => 
      array (
        'declaringClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'implementingClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'name' => 'EMAIL',
        'modifiers' => 4,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'admin@example.test\'',
          'attributes' => 
          array (
            'startLine' => 13,
            'endLine' => 13,
            'startTokenPos' => 50,
            'startFilePos' => 202,
            'endTokenPos' => 50,
            'endFilePos' => 221,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 13,
        'endLine' => 13,
        'startColumn' => 5,
        'endColumn' => 47,
      ),
      'PASSWORD' => 
      array (
        'declaringClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'implementingClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'name' => 'PASSWORD',
        'modifiers' => 4,
        'type' => NULL,
        'value' => 
        array (
          'code' => '\'Correct-password-123\'',
          'attributes' => 
          array (
            'startLine' => 14,
            'endLine' => 14,
            'startTokenPos' => 61,
            'startFilePos' => 253,
            'endTokenPos' => 61,
            'endFilePos' => 274,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 14,
        'endLine' => 14,
        'startColumn' => 5,
        'endColumn' => 52,
      ),
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'name' => 
      array (
        'name' => 'name',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 16,
        'endLine' => 19,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Database\\Seeders',
        'declaringClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'implementingClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'currentClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'aliasName' => NULL,
      ),
      'run' => 
      array (
        'name' => 'run',
        'parameters' => 
        array (
          'connection' => 
          array (
            'name' => 'connection',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'PDO',
                'isIdentifier' => false,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 21,
            'endLine' => 21,
            'startColumn' => 25,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 21,
        'endLine' => 57,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Database\\Seeders',
        'declaringClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'implementingClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'currentClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'aliasName' => NULL,
      ),
      'uuid' => 
      array (
        'name' => 'uuid',
        'parameters' => 
        array (
          'key' => 
          array (
            'name' => 'key',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 59,
            'endLine' => 59,
            'startColumn' => 27,
            'endColumn' => 37,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 59,
        'endLine' => 63,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 4,
        'namespace' => 'PerrymanFinance\\Database\\Seeders',
        'declaringClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'implementingClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'currentClassName' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));