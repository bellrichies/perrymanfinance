<?php declare(strict_types = 1);

// ftm-phar://D:\Perryman\backend\vendor\phpstan\phpstan\phpstan.phar\vendor\jetbrains\phpstorm-stubs\random\random.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '1d65bb36f1e329e030bca687d5753262' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'lcg_value',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4698e433447b85cabff4274bf7654568' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'mt_srand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd6b2d693b78c718b69b5d7536cba595d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'srand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2a129a1db52d2f959e205785e4372d0e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'rand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '83790c9145a7972a8dae2bfe2af57363' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'mt_rand',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '06a4196642170f49ced9a34fadee34b1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'mt_getrandmax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8a0f840860ae100c8bde880fccdc1415' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'getrandmax',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0404972898570eadedfd85d09513bcce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'random_bytes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5f76d12b11fc711435f62fff4105fa2d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'random_int',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ab549145b2d50ca1b25b9c0c30b16aea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dc5415405ef7dbcef5e526ecfdbf4684' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '33ae15b21856fb0f17a5ce5fd329f8c7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '47dc838f1d2ca7fa0a4f1397a5a78735' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd20687a11ee3a1f691e90da87670526d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '52c21ed6dc9805161f787588aa9b8d81' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Mt19937',
         'functionName' => '__debugInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Mt19937',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e672656b4eedd0991bded6bc7d2b31e8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '87dd8eef6e43d3823c17b4d933ef3256' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec7e53ece72693b3914c3705d5154818' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ce52e48359b1690a221ac93f43477c41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => 'jump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '541532041ce1ea4b7cd9a991ed19de7c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8e5a4d0566bb60fb521c3b02065609fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '544bc7faa9b3487bf927b2923c52666c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
         'functionName' => '__debugInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\PcgOneseq128XslRr64',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '691b765147b2aeb5753ec4d3928bb5fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2b5c3db5ab2a6e87f59edd933f7ada6b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a01b0e278e626dd144c3c982bb9bc02d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1373d283d84256a7486e952a03af3767' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => 'jump',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '342d0bcf4b2663faeaf3e8a861132d06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => 'jumpLong',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c184a2d9cbcc48a2a5c3260a2f041adf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7744d0102ea5bbf17f48cefbede98f32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '08023ef103394622d7592e9e381e714d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Xoshiro256StarStar',
         'functionName' => '__debugInfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Xoshiro256StarStar',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '29280485f6dedd9a179bde9635e2a5cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Secure',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a5ce25f8a51bd5de3ddba35de3b0df06' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random\\Engine',
         'uses' => 
        array (
        ),
         'className' => 'Random\\Engine\\Secure',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random\\Engine',
           'uses' => 
          array (
          ),
           'className' => 'Random\\Engine\\Secure',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
            'mt_rand_mt19937' => 'MT_RAND_MT19937',
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
          'mt_rand_mt19937' => 'MT_RAND_MT19937',
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c936eef86261ffa3602a7f19f211209b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Engine',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9b47ac90c2bdc0107c6c1fe1b88d7794' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Engine',
         'functionName' => 'generate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Engine',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '08d8dc43a251c1108a504da2c6732db2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\CryptoSafeEngine',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '823367ff28fe3fb89033a94b157fe425' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4bb6685c61630bfa01084f248a8711fe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6850f87ccbf29362105cea697eff3e07' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'nextInt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fe70360fb3ba0b6aaf773e274f12591b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getInt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '533607f084db7be48f15f1c790810828' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getBytes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '23fad37b78fde39f45931e01cdcc8370' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'shuffleArray',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '86cbd3b10990bc4c9a8dc830fcbe8ce7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'shuffleBytes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '28b48260f8c96c797fffe49656230711' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'pickArrayKeys',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '42059675912a8099cdb3924952d7a891' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => '__serialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0fca88371868195af63d2c97c612a1ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => '__unserialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c241aba51d561969d28957965e653693' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'nextFloat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c72a2805b9df5c093a549f5064e58b55' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getFloat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ffe5b6726583a14b190e46ac0c756f3c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\Randomizer',
         'functionName' => 'getBytesFromString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\Randomizer',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '175ba4a8a9a8ff1758a5fd5dcaa18026' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\RandomError',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5e0b73436ffb38a4b0d506f7b35e2650' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\BrokenRandomEngineError',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '95501421669eb5e253cf7aa5832a4942' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\RandomException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c93e3a132a05e44a002c255590d1cc18' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\IntervalBoundary',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '34b37f1cf7c57dee892715b70f06b9a4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Random',
         'uses' => 
        array (
          'error' => 'Error',
          'exception' => 'Exception',
        ),
         'className' => 'Random\\IntervalBoundary',
         'functionName' => 'cases',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'Random',
           'uses' => 
          array (
            'error' => 'Error',
            'exception' => 'Exception',
          ),
           'className' => 'Random\\IntervalBoundary',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar://D:\\Perryman\\backend\\vendor\\phpstan\\phpstan\\phpstan.phar\\vendor\\jetbrains\\phpstorm-stubs\\random\\random.stub' => '1267cf5900cb646cb69e4421289b8c2ec8921073610dd3499800524d7becb853',
    ),
  ),
));