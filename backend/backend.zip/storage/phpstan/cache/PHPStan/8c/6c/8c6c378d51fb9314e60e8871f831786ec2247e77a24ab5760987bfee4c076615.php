<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Middleware\MiddlewareDispatcher.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '6983744f8fd4917d271a6adba41aca93' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Middleware',
         'uses' => 
        array (
          'container' => 'PerrymanFinance\\Core\\Container',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
        ),
         'className' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fc3e92b033e1407299ea28dcd2107f85' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Middleware',
         'uses' => 
        array (
          'container' => 'PerrymanFinance\\Core\\Container',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
        ),
         'className' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0bf92a6ba0126febe93413b3535c3e17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Middleware',
         'uses' => 
        array (
          'container' => 'PerrymanFinance\\Core\\Container',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
        ),
         'className' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
         'functionName' => 'dispatch',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Middleware\\MiddlewareDispatcher.php' => '5d01157c43662c0454551234e7dd9399f678e4428243b371d01e6784d6df3d63',
    ),
  ),
));