<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\Exception\ExpectationFailedException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '5fa186cb1664715fe4b1450e04b27f41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
          'exception' => 'Exception',
          'comparisonfailure' => 'SebastianBergmann\\Comparator\\ComparisonFailure',
        ),
         'className' => 'PHPUnit\\Framework\\ExpectationFailedException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '55cb64782fefc6286af3896cec970ab2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
          'exception' => 'Exception',
          'comparisonfailure' => 'SebastianBergmann\\Comparator\\ComparisonFailure',
        ),
         'className' => 'PHPUnit\\Framework\\ExpectationFailedException',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'PHPUnit\\Framework',
           'uses' => 
          array (
            'exception' => 'Exception',
            'comparisonfailure' => 'SebastianBergmann\\Comparator\\ComparisonFailure',
          ),
           'className' => 'PHPUnit\\Framework\\ExpectationFailedException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f36483c486d01f287cd0add8604a60b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
          'exception' => 'Exception',
          'comparisonfailure' => 'SebastianBergmann\\Comparator\\ComparisonFailure',
        ),
         'className' => 'PHPUnit\\Framework\\ExpectationFailedException',
         'functionName' => 'getComparisonFailure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'PHPUnit\\Framework',
           'uses' => 
          array (
            'exception' => 'Exception',
            'comparisonfailure' => 'SebastianBergmann\\Comparator\\ComparisonFailure',
          ),
           'className' => 'PHPUnit\\Framework\\ExpectationFailedException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\vendor\\phpunit\\phpunit\\src\\Framework\\Exception\\ExpectationFailedException.php' => 'b294cec8909f3f976246ca047847f2340291481e3b6ee6789708a31dbdaf5471',
    ),
  ),
));