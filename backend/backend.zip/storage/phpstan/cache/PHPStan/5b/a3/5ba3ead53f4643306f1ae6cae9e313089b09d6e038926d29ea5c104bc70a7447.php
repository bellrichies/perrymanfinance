<?php declare(strict_types = 1);

// osfsl-D:\Perryman\backend\database\seeders\PublicContentSeeder.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-3f8eed782f43af8ca001781260a8ab7d8b9b613b43e6204268595a08da45596b-8.2.12',
   'data' => 
  array (
    'classes' => 
    array (
      'perrymanfinance\\database\\seeders\\publiccontentseeder' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));