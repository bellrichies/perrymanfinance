<?php declare(strict_types = 1);

// ftm-phar://D:\Perryman\backend\vendor\phpstan\phpstan\phpstan.phar\vendor\jetbrains\phpstorm-stubs\json\json.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '6e8a776502d9a2ac0df635f98e9e7c3a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonSerializable',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd28e674422a57142fc1b79a45f22d1ce' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonSerializable',
         'functionName' => 'jsonSerialize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'language' => 'JetBrains\\PhpStorm\\Language',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'JsonSerializable',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c6ec4ee332e69491c0c30c08b0e44449' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonIncrementalParser',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '793f95194d1c8c6e823e9d01ba57d5ca' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonIncrementalParser',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0fdcc1524250b87b78d68a955b59f245' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonIncrementalParser',
         'functionName' => 'getError',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27f2332c573d29962690ce44ce4266c9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonIncrementalParser',
         'functionName' => 'reset',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2f3fb4595118d848e4362cc6bb21c39b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonIncrementalParser',
         'functionName' => 'parse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa297342443544bd9f22c78e3a7591fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonIncrementalParser',
         'functionName' => 'parseFile',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '445a1513107d6180d562b4f5acca88d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonIncrementalParser',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '169f003adc5827622137873bbc45eddc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'json_encode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a0a69a4b70dd68a34557609db7822f49' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'json_decode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7e5b0ba546b3c81cd98673f41cd08183' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'json_last_error',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '361cd56639cd10afb470912747537e32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'json_last_error_msg',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '979c627565832342db60e0cf1fff5a07' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'json_validate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8026480ba8a69b7035b5000e334f3361' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '872823deaf8312d511dcfb0e65f4225c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'language' => 'JetBrains\\PhpStorm\\Language',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'JsonException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar://D:\\Perryman\\backend\\vendor\\phpstan\\phpstan\\phpstan.phar\\vendor\\jetbrains\\phpstorm-stubs\\json\\json.stub' => 'bf40f097538a36d530cb510f4d8f719d53eca0049aba1f9840f5312018caf485',
    ),
  ),
));