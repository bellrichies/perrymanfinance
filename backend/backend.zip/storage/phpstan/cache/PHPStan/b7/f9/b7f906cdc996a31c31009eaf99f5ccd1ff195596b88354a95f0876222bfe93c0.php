<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Core\Application.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'bc2b7f2ddf1b277f3f3e056479ba7836' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'exceptionhandler' => 'PerrymanFinance\\Http\\Exceptions\\ExceptionHandler',
          'middlewaredispatcher' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'router' => 'PerrymanFinance\\Http\\Router',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Core\\Application',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '656483b2207230d13aae18f1bfb9d7ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'exceptionhandler' => 'PerrymanFinance\\Http\\Exceptions\\ExceptionHandler',
          'middlewaredispatcher' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'router' => 'PerrymanFinance\\Http\\Router',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Core\\Application',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b7e9bfe47c817b74e1375697c0df35d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'exceptionhandler' => 'PerrymanFinance\\Http\\Exceptions\\ExceptionHandler',
          'middlewaredispatcher' => 'PerrymanFinance\\Http\\Middleware\\MiddlewareDispatcher',
          'request' => 'PerrymanFinance\\Http\\Request',
          'response' => 'PerrymanFinance\\Http\\Response',
          'router' => 'PerrymanFinance\\Http\\Router',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Core\\Application',
         'functionName' => 'handle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Core\\Application.php' => 'fdc81bc1c466d636aa311517f379ef9d7fc34c701fcf488f5bbb865f7ac373ab',
    ),
  ),
));