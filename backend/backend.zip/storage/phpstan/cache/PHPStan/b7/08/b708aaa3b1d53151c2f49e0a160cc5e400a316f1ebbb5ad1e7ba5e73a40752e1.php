<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Database\SeedRunnerTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Database\SeedRunnerTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-050ccd5124834df7d8041b7a075f3dd64a51808f1edb7e975b899d3e351172dc',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Database\\SeedRunnerTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Database/SeedRunnerTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Database',
    'name' => 'Tests\\Unit\\Database\\SeedRunnerTest',
    'shortName' => 'SeedRunnerTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 12,
    'endLine' => 20,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testProductionSeedingIsRejected' => 
      array (
        'name' => 'testProductionSeedingIsRejected',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 14,
        'endLine' => 19,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Database',
        'declaringClassName' => 'Tests\\Unit\\Database\\SeedRunnerTest',
        'implementingClassName' => 'Tests\\Unit\\Database\\SeedRunnerTest',
        'currentClassName' => 'Tests\\Unit\\Database\\SeedRunnerTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));