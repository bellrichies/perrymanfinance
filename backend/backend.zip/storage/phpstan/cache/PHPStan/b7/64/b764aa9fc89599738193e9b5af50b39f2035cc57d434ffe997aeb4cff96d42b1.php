<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\app\Http\Exceptions\TooManyRequestsException.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PerrymanFinance\Http\Exceptions\TooManyRequestsException
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-36c281661095a50b1e2c410021d2ef01582ac0ea6177756ee71012f58660cc5f',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PerrymanFinance\\Http\\Exceptions\\TooManyRequestsException',
        'filename' => 'D:/Perryman/backend/app/Http/Exceptions/TooManyRequestsException.php',
      ),
    ),
    'namespace' => 'PerrymanFinance\\Http\\Exceptions',
    'name' => 'PerrymanFinance\\Http\\Exceptions\\TooManyRequestsException',
    'shortName' => 'TooManyRequestsException',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 13,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PerrymanFinance\\Http\\Exceptions\\HttpException',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      '__construct' => 
      array (
        'name' => '__construct',
        'parameters' => 
        array (
          'retryAfter' => 
          array (
            'name' => 'retryAfter',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'int',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 9,
            'endLine' => 9,
            'startColumn' => 33,
            'endColumn' => 47,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => NULL,
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 9,
        'endLine' => 12,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Http\\Exceptions',
        'declaringClassName' => 'PerrymanFinance\\Http\\Exceptions\\TooManyRequestsException',
        'implementingClassName' => 'PerrymanFinance\\Http\\Exceptions\\TooManyRequestsException',
        'currentClassName' => 'PerrymanFinance\\Http\\Exceptions\\TooManyRequestsException',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));