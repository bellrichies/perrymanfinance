<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\Exception\InvalidArgumentException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b431df2a173cae8f7ca5a09a13b23b67' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
        ),
         'className' => 'PHPUnit\\Framework\\InvalidArgumentException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\vendor\\phpunit\\phpunit\\src\\Framework\\Exception\\InvalidArgumentException.php' => '873604f0f81fb8c6ecb132a12a70df25a18139a2b5e3128afff8156509d54024',
    ),
  ),
));