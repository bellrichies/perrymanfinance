<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-PHP_EOL
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'PHP_EOL',
        'filename' => 'phpstorm-stubs:Core/Core_d.stub',
        'extensionName' => 'Core',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'PHP_EOL',
    'shortName' => 'PHP_EOL',
    'value' => 
    array (
      'code' => '\'
\'',
      'attributes' => 
      array (
        'startLine' => 3,
        'endLine' => 4,
        'startTokenPos' => 7,
        'startFilePos' => 25,
        'endTokenPos' => 7,
        'endFilePos' => 28,
      ),
    ),
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 3,
    'endLine' => 4,
    'startColumn' => 1,
    'endColumn' => 2,
    'namespace' => NULL,
  ),
));