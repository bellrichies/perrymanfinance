<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\bin\seed.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '0cf87231221a8135ab93714703721072' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'config' => 'PerrymanFinance\\Config\\Config',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'devadminseeder' => 'PerrymanFinance\\Database\\Seeders\\DevAdminSeeder',
          'publiccontentseeder' => 'PerrymanFinance\\Database\\Seeders\\PublicContentSeeder',
          'referencedataseeder' => 'PerrymanFinance\\Database\\Seeders\\ReferenceDataSeeder',
          'seedrunner' => 'PerrymanFinance\\Database\\Seeders\\SeedRunner',
        ),
         'className' => NULL,
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\bin\\seed.php' => '09b13e2b03a405aaed1289e1cd60e9a3c8381e88f1fac87d60c66b48a553d7a1',
    ),
  ),
));