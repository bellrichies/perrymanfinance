<?php declare(strict_types = 1);

// ftm-phar://D:\Perryman\backend\vendor\phpstan\phpstan\phpstan.phar\vendor\jetbrains\phpstorm-stubs\Reflection\ReflectionFunctionAbstract.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '911f30c2bd419ca528afd66f03d1230b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8adede47fe5160432ad71264f2d4e7c9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => '__clone',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e5916caa94276e6b9cfa55565eed7950' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'inNamespace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9f7d33f552ac76e767febd0870591fb3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'isClosure',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c24ffaf91a687e4ad614b467fa0c266e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'isDeprecated',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ef3ea7744a51677e3cba0510966b34aa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'isInternal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3354f78321f6df6ede9489fb2fa1c1b8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'isUserDefined',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9fb9ead17212cd36f95904678f210b71' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'isGenerator',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12f2ce87e11a7395af94c2d58cf12f09' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'isVariadic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '283e8f0d2c5b1f0c164dd2f17f82dff4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getClosureThis',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8d538e1141c94eb4b2890b91aae06148' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getClosureScopeClass',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '30fbf6837b821f6555f7ac7e31c230f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getClosureCalledClass',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '125e2fa5c3516a699e4e6e46775f22d5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getDocComment',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '99a3af04bba13b0e2efc37d8a1a6a690' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getEndLine',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '03e2c4b4b12dcbf3183532fb23878306' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getExtension',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd44bf3a5a4e3b64bf2fc202575ce44f3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getExtensionName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ebcac8b66363a5742d295781086d44f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getFileName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5cd02fee75d133b58e57a69e75342051' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b76cf79cfd5684db9548ce9a5be92589' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getNamespaceName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '99626b74de46cdb1c6c433a59347c0ea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getNumberOfParameters',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a44737402572293be7ab88764e391569' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getNumberOfRequiredParameters',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '35e3b233a077ff931338e00d28debd44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getParameters',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9062ceaae7117f163da8074145d2e4bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getReturnType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8aa39e185770b35cc4cde4fa9216d94e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getShortName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12f7abc80cd1233a903ba1bb68f1e767' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getStartLine',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c4ace7bfe59be1f1f6b62f33eca50ecb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getStaticVariables',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '83abbe20d077db7f02d560a2c7dae7f7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'returnsReference',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e4e06689714050cac93e61d1c8970435' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'hasReturnType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '04df15db639d08a1be15cf091c5300be' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getAttributes',
         'templatePhpDocNodes' => 
        array (
          'T' => 
          array (
            0 => '@template',
            1 => 
            \PHPStan\PhpDocParser\Ast\PhpDoc\TemplateTagValueNode::__set_state(array(
               'name' => 'T',
               'bound' => NULL,
               'default' => NULL,
               'lowerBound' => NULL,
               'description' => '

Returns an array of function attributes.',
               'attributes' => 
              array (
                'startLine' => 2,
                'endLine' => 4,
              ),
            )),
          ),
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd383193db794a2c10b610cd03bbb7fba' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getClosureUsedVariables',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '66e744339df1ad506bed02dce940d6a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'hasTentativeReturnType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a9893fa36861c9384975f6522134b02d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'getTentativeReturnType',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0881179753bd27969983f1392241ac64' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => 'isStatic',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e44ec5460f5477fdb040c097f4b37411' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'immutable' => 'JetBrains\\PhpStorm\\Immutable',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'ReflectionFunctionAbstract',
         'functionName' => '__toString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'immutable' => 'JetBrains\\PhpStorm\\Immutable',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'ReflectionFunctionAbstract',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar://D:\\Perryman\\backend\\vendor\\phpstan\\phpstan\\phpstan.phar\\vendor\\jetbrains\\phpstorm-stubs\\Reflection\\ReflectionFunctionAbstract.stub' => '33eafb8d0927bbc9a3d035ea26fc15cd4ec68e8ba7ec89643a8abf36534013c6',
    ),
  ),
));