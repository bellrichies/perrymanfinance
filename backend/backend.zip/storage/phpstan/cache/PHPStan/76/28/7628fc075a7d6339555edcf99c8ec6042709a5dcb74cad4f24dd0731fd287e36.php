<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\ClientAccount\ClientPortalService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'c13e61dfac939914882ccbf085455e6a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16008b283114f9e2ee8160204882cf40' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2de2112bc34e4a3af2fd191d6aae909d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'dashboard',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c98d00b4e2e9ae42780318d399794f5e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'eligiblePlans',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5dbfabc33b17db01e9447d3e095ed945' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'submitPlanRequest',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '72ff97349c078f00d026ce338d34adc0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'adminClients',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '814f2c9b17aa447eabbb1b38224005f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'adminClientDetail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8f45eb5cb176c8287c851efdc04457eb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'adminPlanRequests',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f547cae4a10dde8cadfc9c1326deef4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'review',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b96d151ae957afd34cae63a78bc78a3e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'required',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '76ff053b6de0e683c169b4d437932c3c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'optionalAmount',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd55437a646fcc057ec4554aa7f55fe21' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '476c98e05ec8435b4db91b096eb2e334' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\ClientAccount',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'badrequestexception' => 'PerrymanFinance\\Http\\Exceptions\\BadRequestException',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'clientauditrepository' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
          'clientplanrepository' => 'PerrymanFinance\\Repositories\\ClientPlanRepository',
          'clientuserrepository' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\ClientAccount\\ClientPortalService',
         'functionName' => 'uuid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\ClientAccount\\ClientPortalService.php' => 'df07d256ccce66f43726c2de817e8116687868bc4247a713a6c438557c814fe2',
    ),
  ),
));