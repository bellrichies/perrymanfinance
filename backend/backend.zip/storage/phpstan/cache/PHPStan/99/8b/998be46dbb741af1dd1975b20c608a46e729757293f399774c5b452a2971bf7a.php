<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Feature\AdminEnquiryTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Feature\AdminEnquiryTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-d80e6b79054017c2269f009918ad4f20d3a8f2b4f3d5481cab7aa91225095f11',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Feature\\AdminEnquiryTest',
        'filename' => 'D:/Perryman/backend/tests/Feature/AdminEnquiryTest.php',
      ),
    ),
    'namespace' => 'Tests\\Feature',
    'name' => 'Tests\\Feature\\AdminEnquiryTest',
    'shortName' => 'AdminEnquiryTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 17,
    'endLine' => 104,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
      'pdo' => 
      array (
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'name' => 'pdo',
        'modifiers' => 4,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'PDO',
            'isIdentifier' => false,
          ),
        ),
        'default' => NULL,
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 19,
        'endLine' => 19,
        'startColumn' => 5,
        'endColumn' => 21,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
      'service' => 
      array (
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'name' => 'service',
        'modifiers' => 4,
        'type' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'PerrymanFinance\\Services\\Enquiries\\AdminEnquiryService',
            'isIdentifier' => false,
          ),
        ),
        'default' => NULL,
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 20,
        'endLine' => 20,
        'startColumn' => 5,
        'endColumn' => 41,
        'isPromoted' => false,
        'declaredAtCompileTime' => true,
        'immediateVirtual' => false,
        'immediateHooks' => 
        array (
        ),
      ),
    ),
    'immediateMethods' => 
    array (
      'setUp' => 
      array (
        'name' => 'setUp',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 22,
        'endLine' => 30,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 2,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'currentClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'aliasName' => NULL,
      ),
      'testStatusWorkflowRecordsAuditWithoutPersonalData' => 
      array (
        'name' => 'testStatusWorkflowRecordsAuditWithoutPersonalData',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 32,
        'endLine' => 45,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'currentClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'aliasName' => NULL,
      ),
      'testInvalidTransitionAndExtraFieldsAreRejected' => 
      array (
        'name' => 'testInvalidTransitionAndExtraFieldsAreRejected',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 47,
        'endLine' => 57,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'currentClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'aliasName' => NULL,
      ),
      'testAuditFailureRollsBackStatus' => 
      array (
        'name' => 'testAuditFailureRollsBackStatus',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 59,
        'endLine' => 68,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'currentClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'aliasName' => NULL,
      ),
      'testSearchFilterAndPagination' => 
      array (
        'name' => 'testSearchFilterAndPagination',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 70,
        'endLine' => 76,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'currentClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'aliasName' => NULL,
      ),
      'testActualAdminRoutesRejectAnonymousAccess' => 
      array (
        'name' => 'testActualAdminRoutesRejectAnonymousAccess',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 78,
        'endLine' => 94,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'currentClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'aliasName' => NULL,
      ),
      'testViewerCannotUpdateStatus' => 
      array (
        'name' => 'testViewerCannotUpdateStatus',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 96,
        'endLine' => 103,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Feature',
        'declaringClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'implementingClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'currentClassName' => 'Tests\\Feature\\AdminEnquiryTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));