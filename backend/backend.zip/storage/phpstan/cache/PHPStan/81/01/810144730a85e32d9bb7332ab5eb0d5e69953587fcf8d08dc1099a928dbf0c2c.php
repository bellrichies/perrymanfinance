<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\vendor\phpunit\phpunit\src\Event\Exception\NoPreviousThrowableException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '8670e67361c167bec7583ef880ad112b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Event',
         'uses' => 
        array (
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'PHPUnit\\Event\\NoPreviousThrowableException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\vendor\\phpunit\\phpunit\\src\\Event\\Exception\\NoPreviousThrowableException.php' => '695121b6b80d42ec50720dbc19cdcbbc0352a24d12ae091ccffe48680540751e',
    ),
  ),
));