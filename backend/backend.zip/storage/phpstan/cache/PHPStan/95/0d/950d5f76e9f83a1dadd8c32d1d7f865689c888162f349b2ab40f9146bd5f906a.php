<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Identity\AuthService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '82a0cd3c1cb221ea1c440f9c71bb2abe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3eb43991756a60affd1831c03e7493c7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b5fa121953fb89531477de2dd6d17106' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'login',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e8e9198c9995253ac60fc1ffccc1ac5a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'refresh',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0ee3305e1350da3f24793e37f48b9d32' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'logout',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9cbe9352fc57b36ef6f77c1dfebbcc03' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'forgotPassword',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '30d59e66d0fd0d9dc3fc283decdf6ebf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'resetPassword',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'db7406c760e337222c6f191c8d227305' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'createSession',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3dcb688e9504d9b9d4bec9aa9b99d5a5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '85097f5ebc3405a86861082fb21345da' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Identity',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
          'unauthorizedexception' => 'PerrymanFinance\\Http\\Exceptions\\UnauthorizedException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'adminuserrepository' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'passwordresetrepository' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
          'refreshtokenrepository' => 'PerrymanFinance\\Repositories\\RefreshTokenRepository',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Services\\Identity\\AuthService',
         'functionName' => 'future',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Identity\\AuthService.php' => '445807185fe6fc8ae96628bed5d585e4b9e958034ea5cc9dca314905f7912446',
    ),
  ),
));