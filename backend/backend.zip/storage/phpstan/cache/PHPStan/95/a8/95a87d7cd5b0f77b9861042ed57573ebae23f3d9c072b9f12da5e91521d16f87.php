<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\ClientUserRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b57c0368f417f3a32db5feb1101b9beb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c8a8df7bd06ab74c2ff65280046402fc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'findByEmail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd22db8446760e6ac9ab26776c912f058' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'findById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ca5a1ee6c02f6628630b4258960dc125' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'findByUuid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b3c1fcb774efc48149e7ecdce92ab3ea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'create',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '611e26ea8f60c493a12886d5ffa17f1c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'verifyEmail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '66d9c0f10f436e847a75099b7765e274' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'recordLogin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cf52a702a3be8c8f84b1bd4f9d922db7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'updatePassword',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7096bc25206eeaf3f8f58aa1b0f6b66c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'list',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9886aaeec3550b995cc533358931966b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'clientuser' => 'PerrymanFinance\\Domain\\ClientAccount\\ClientUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientUserRepository',
         'functionName' => 'map',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\ClientUserRepository.php' => 'db4bcfa0b31a96012937520fb90a302f65da02b8b030ecdf452817893d228a87',
    ),
  ),
));