<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Validation\ValidatorTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Validation\ValidatorTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-eb88369c017fff6e8a0e1966bf3ca93f64118bfbff336cf17f1eafbbf636df88',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Validation\\ValidatorTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Validation/ValidatorTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Validation',
    'name' => 'Tests\\Unit\\Validation\\ValidatorTest',
    'shortName' => 'ValidatorTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 11,
    'endLine' => 31,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testValidDataIsReturnedAndUnknownFieldsAreExcluded' => 
      array (
        'name' => 'testValidDataIsReturnedAndUnknownFieldsAreExcluded',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 13,
        'endLine' => 20,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Validation',
        'declaringClassName' => 'Tests\\Unit\\Validation\\ValidatorTest',
        'implementingClassName' => 'Tests\\Unit\\Validation\\ValidatorTest',
        'currentClassName' => 'Tests\\Unit\\Validation\\ValidatorTest',
        'aliasName' => NULL,
      ),
      'testInvalidDataProducesFieldErrors' => 
      array (
        'name' => 'testInvalidDataProducesFieldErrors',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 21,
        'endLine' => 30,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Validation',
        'declaringClassName' => 'Tests\\Unit\\Validation\\ValidatorTest',
        'implementingClassName' => 'Tests\\Unit\\Validation\\ValidatorTest',
        'currentClassName' => 'Tests\\Unit\\Validation\\ValidatorTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));