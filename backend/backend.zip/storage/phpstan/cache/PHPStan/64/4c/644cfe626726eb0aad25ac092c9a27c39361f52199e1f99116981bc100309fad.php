<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Seo\SeoService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b717aa2aaf232e8a34bd798ff7d54dab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f1cf01383516cfabeeaf2096d7ffe381' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ea16f0b2c117a1a5de2a300624fb4536' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'sitemapXml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bbd3d20a3bfb271f71e076b5429bb2f3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'robotsTxt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3e79df88957651e258be1f4094812a9c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'sitemapEntries',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b1091fe98d06c21bfe35d29d917ea49a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'redirect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a7885006c718e29397b3966ac1d9747c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'recordRedirect',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b1838cc6a5051353467b8d68b324266f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'sitemapUrl',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7619a2666e7b31527865079dd8fb9984' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'canonical',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f765354e371b2507dc364b693faec1af' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'origin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f0eb8172c64991b6c35b261e13a008a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'pathFor',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9e4fdeba8f106a04c5f92f264ceb5fd0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'internalPath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f32f027089f3a15b94547cacbf1901f2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'xml',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '37a91ff91d1bd5d3685b994714a8b9f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Seo',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'config' => 'PerrymanFinance\\Config\\Config',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Seo\\SeoService',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Seo\\SeoService.php' => '85f3ed6f0cc118e9b50bc4d55a4e69c7b103a8b5e2653b905934178100136015',
    ),
  ),
));