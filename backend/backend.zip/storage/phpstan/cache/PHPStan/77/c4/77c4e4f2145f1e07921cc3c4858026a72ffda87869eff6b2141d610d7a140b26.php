<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Investment\InvestmentService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b098c7c9ac7c1a2d66b9ddd14a53640d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '403b02f7b735449e641eee2047b4303f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3b447dd097e31033e0df5b76e504d013' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'categories',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3c1449541a6c864f216f2f3a5adc70f2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'saveCategory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa922833b7cb60198218ec0ac88f9731' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'deleteCategory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '39c9a1794d849ebb2acbb510aa2b93c4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'opportunities',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '35dbb23502f80792509bba4938ae0988' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'opportunity',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '935700d6df1a9093ae3f12bfb6a227b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'saveOpportunity',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '97db11be9f6c3544ff36570c40e1658b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'archive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c7e3ded3dd08279c4b7c305f37df9b7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'seo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '34e43fdc200e291d1bc6edd395ebc71a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'string',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c8f3c26f1ba12546328c3bc22916c55' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'optional',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f8f09a8e3606db06cda64122ff159ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'optionalRich',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bdd4133f060adacdad652c787942f697' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'status',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6457b56097c848f25b64157ed2fedc27' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'slug',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5c0600c4f4ddb8bc0ccf6a8e945a455b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'nullablePositiveInt',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e293a5c235147a40947094f36cfd23ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'duplicate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7292d084a6067df7fc085554d572bbf5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2792c7ffc4d29ffd70541d6d913f5968' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Investment',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'pdoexception' => 'PDOException',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'investmentrepository' => 'PerrymanFinance\\Repositories\\InvestmentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Investment\\InvestmentService',
         'functionName' => 'uuid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Investment\\InvestmentService.php' => '60b59ca3638ad3156f0e2fa6bbc08a6c4dbe63e9513490721a6dbf7bf3da9d9f',
    ),
  ),
));