<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Content\CmsService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'adf63cd8f6b7cf2f5b0877673851e754' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bcef1ff7686acf45598b076675de925e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '952ae162aac76c9582b02e962ea03610' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'pages',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '36236f25835010f480e6862c9828ce12' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'page',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3106269aec004c7108b0b437989ac35a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'savePage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd3475ffd09e3a0173e02c3e177abf9b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'deletePage',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '393284cc0fe14d3df471f302f19ba0e3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'legalDocuments',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '75a50d14cec0534450ebb47c2fc3744e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'legal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '01eeeb01cb7283a73cfe263a6dcdf0d2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'saveLegal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6b4278d4f0fca1faaf39a63653f7158b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'archiveLegal',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '34564f0d6ef594427f4488a456f52f01' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'settings',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5201ff52f1616733967f7d93d7b4ea24' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'saveSetting',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd564ee2dd41680f06b1f98c156902377' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'deleteSetting',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bce1318ea95a34f3271a7d82bc3a8ddd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'saveSeo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7fb4c6e06f8e4158d424582af218bb76' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'seo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '63a06925e14b351d063458ffc29475f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'deleteSeo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b3d07e4c56c9a902744c6e7570904ed6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'string',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3ad51b067bf8dd09c218d6185ee390b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'optionalString',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e21a4c622b54a56981d0219bc03bcb44' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'slug',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c40eb0417cc75d22912e2908b862e21' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'status',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9fda5369a790764b33aa976bdd92e3d3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'date',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '605e4cf60efe8a37399d44fd6c230aeb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6e580a74255b6a26aa5c459414886487' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'uuid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b160811a796687524afadc501015984b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Content',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'contentsanitizer' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
          'publicationworkflow' => 'PerrymanFinance\\Domain\\Content\\PublicationWorkflow',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'contentrepository' => 'PerrymanFinance\\Repositories\\ContentRepository',
          'seoservice' => 'PerrymanFinance\\Services\\Seo\\SeoService',
        ),
         'className' => 'PerrymanFinance\\Services\\Content\\CmsService',
         'functionName' => 'pagePath',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Content\\CmsService.php' => '66b70592553bed853716e3cfc893d8844fc652c28a295be690c13444a545dc7b',
    ),
  ),
));