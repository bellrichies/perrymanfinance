<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\MockObject\Exception\Exception.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PHPUnit\Framework\MockObject\Exception
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-22dd6286a484a6e9d755b1a39de0613d076d1680da010ef212727dcfacedc4e4',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PHPUnit\\Framework\\MockObject\\Exception',
        'filename' => 'D:/Perryman/backend/vendor/phpunit/phpunit/src/Framework/MockObject/Exception/Exception.php',
      ),
    ),
    'namespace' => 'PHPUnit\\Framework\\MockObject',
    'name' => 'PHPUnit\\Framework\\MockObject\\Exception',
    'shortName' => 'Exception',
    'isInterface' => true,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 0,
    'docComment' => '/**
 * @no-named-arguments Parameter names are not covered by the backward compatibility promise for PHPUnit
 *
 * @internal This interface is not covered by the backward compatibility promise for PHPUnit
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 17,
    'endLine' => 19,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
      0 => 'PHPUnit\\Exception',
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));