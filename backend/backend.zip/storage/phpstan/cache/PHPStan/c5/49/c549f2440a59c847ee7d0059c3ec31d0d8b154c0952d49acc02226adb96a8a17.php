<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\tests\Support\InMemoryLogger.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'b7beaee247a94ae759cbd8ad599e0c0c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Support',
         'uses' => 
        array (
          'loggerinterface' => 'PerrymanFinance\\Logging\\LoggerInterface',
        ),
         'className' => 'Tests\\Support\\InMemoryLogger',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa2a28d04d69614a5dbdcdc4d33e1c02' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'Tests\\Support',
         'uses' => 
        array (
          'loggerinterface' => 'PerrymanFinance\\Logging\\LoggerInterface',
        ),
         'className' => 'Tests\\Support\\InMemoryLogger',
         'functionName' => 'log',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\tests\\Support\\InMemoryLogger.php' => '938f0ba3d7462004e6e0c049bac114a8fd3deb9e1d281f90b561fb76b9063b7f',
    ),
  ),
));