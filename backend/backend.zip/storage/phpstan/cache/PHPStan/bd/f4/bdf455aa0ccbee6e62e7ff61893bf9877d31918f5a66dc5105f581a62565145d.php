<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Controllers\HealthController.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '8421a37bd8680d5843c5902d5cc38407' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\HealthController',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ae30b17509c9ecca16233564ee049824' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\HealthController',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '081a6ba54d807f69069f389b4be21bee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http\\Controllers',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\Controllers\\HealthController',
         'functionName' => 'show',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Controllers\\HealthController.php' => '3625bac906fc707ffe78d8a6bb6a55ff88676740a212d08db5900af7111b44b4',
    ),
  ),
));