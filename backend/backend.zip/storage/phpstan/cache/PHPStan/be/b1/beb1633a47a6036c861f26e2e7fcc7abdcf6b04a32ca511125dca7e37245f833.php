<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\PasswordResetRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'dd69cb76439306be5759c4df291afd6b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '96907869bb9979bcf9269f3317d4dbf8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
         'functionName' => 'replaceForUser',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b14f0523b9982dee9e5596049786dc90' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
         'functionName' => 'findUsable',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1e15569be7cf81da5a35c60e8a1a1ed5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\PasswordResetRepository',
         'functionName' => 'markUsed',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\PasswordResetRepository.php' => '0b930501bc7231f1dd80e7f903c2eab21bffa7f769e4e3bffa59db0c2714ebc2',
    ),
  ),
));