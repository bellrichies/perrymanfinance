<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Services\Enquiries\AdminEnquiryService.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'fec83da3b7a3499b9a799779a2223441' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\AdminEnquiryService',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '521589425b856dd22c9a22aa53ddc588' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\AdminEnquiryService',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2a9e7d19de1c7623fc3cddec7eb4d65d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\AdminEnquiryService',
         'functionName' => 'listing',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6be6c5b54fb92a1f4da5533e380e3349' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\AdminEnquiryService',
         'functionName' => 'detail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1a1006ab4443228f240d2641a6c355e5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Services\\Enquiries',
         'uses' => 
        array (
          'transactionmanager' => 'PerrymanFinance\\Database\\TransactionManager',
          'notfoundexception' => 'PerrymanFinance\\Http\\Exceptions\\NotFoundException',
          'validationexception' => 'PerrymanFinance\\Http\\Exceptions\\ValidationException',
          'auditlogrepository' => 'PerrymanFinance\\Repositories\\AuditLogRepository',
          'enquiryrepository' => 'PerrymanFinance\\Repositories\\EnquiryRepository',
        ),
         'className' => 'PerrymanFinance\\Services\\Enquiries\\AdminEnquiryService',
         'functionName' => 'update',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Services\\Enquiries\\AdminEnquiryService.php' => '6e9126e9df3900dda166cb66498b93b62221204ac52d6a748adb643f7e0a6c16',
    ),
  ),
));