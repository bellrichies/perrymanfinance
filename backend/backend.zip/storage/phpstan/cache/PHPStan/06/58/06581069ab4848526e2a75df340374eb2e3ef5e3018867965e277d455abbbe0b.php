<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Core\ContainerTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Core\ContainerTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-0d8240da1ec6b9c77a63c3da83fe80475c5f15e3854e6d5352d07d2c13cdcd73',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Core\\ContainerTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Core/ContainerTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Core',
    'name' => 'Tests\\Unit\\Core\\ContainerTest',
    'shortName' => 'ContainerTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 12,
    'endLine' => 21,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testInterfaceBindingAndSingletonLifecycle' => 
      array (
        'name' => 'testInterfaceBindingAndSingletonLifecycle',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 14,
        'endLine' => 20,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Core',
        'declaringClassName' => 'Tests\\Unit\\Core\\ContainerTest',
        'implementingClassName' => 'Tests\\Unit\\Core\\ContainerTest',
        'currentClassName' => 'Tests\\Unit\\Core\\ContainerTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));