<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Database\PdoConnectionManager.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'bf02da7d4e2841b61a626368d4d9b0b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
        ),
         'className' => 'PerrymanFinance\\Database\\PdoConnectionManager',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fbcf3b08c4649e9023f551d2c0e95aab' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
        ),
         'className' => 'PerrymanFinance\\Database\\PdoConnectionManager',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd79cf3413ff70a8caabeece15af609b1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'config' => 'PerrymanFinance\\Config\\Config',
        ),
         'className' => 'PerrymanFinance\\Database\\PdoConnectionManager',
         'functionName' => 'connection',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Database\\PdoConnectionManager.php' => 'f72437aaf9ea8981c70ea12ca1795cacecc5fdcf9adf6947dc47e52bba1dab92',
    ),
  ),
));