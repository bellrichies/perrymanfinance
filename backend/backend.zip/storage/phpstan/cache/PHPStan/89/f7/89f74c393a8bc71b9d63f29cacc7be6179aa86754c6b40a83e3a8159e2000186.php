<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Domain\Identity\AdminUser.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'fb4e7472d6f65fcd0724a080fca700a7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\Identity',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bc5451c320f48875305d73db081efe54' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\Identity',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '29255e6ef9af27f144f0d8adfad5a843' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\Identity',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
         'functionName' => 'isActive',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '531b1b184110a8c320ba84753208e21d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Domain\\Identity',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
         'functionName' => 'publicData',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Domain\\Identity\\AdminUser.php' => 'dc82ddc276f39badaa5211a8416920b402fbf8d58c5a4b4a611d376bc6e574a4',
    ),
  ),
));