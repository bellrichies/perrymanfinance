<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\app\Domain\Content\ContentSanitizer.php-PHPStan\BetterReflection\Reflection\ReflectionClass-PerrymanFinance\Domain\Content\ContentSanitizer
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-6760b70a2f7d9b734520e534051ce44ca114cf694e5bfb86f15ed253157f5d59',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'filename' => 'D:/Perryman/backend/app/Domain/Content/ContentSanitizer.php',
      ),
    ),
    'namespace' => 'PerrymanFinance\\Domain\\Content',
    'name' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
    'shortName' => 'ContentSanitizer',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 9,
    'endLine' => 60,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => NULL,
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
      'SECTION_TYPES' => 
      array (
        'declaringClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'implementingClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'name' => 'SECTION_TYPES',
        'modifiers' => 4,
        'type' => NULL,
        'value' => 
        array (
          'code' => '[\'hero\', \'rich_text\', \'service_grid\', \'feature_grid\', \'process_steps\', \'cta\', \'image_text\', \'statistics\', \'testimonials\', \'faq_preview\', \'investment_preview\', \'insights_preview\']',
          'attributes' => 
          array (
            'startLine' => 11,
            'endLine' => 14,
            'startTokenPos' => 36,
            'startFilePos' => 199,
            'endTokenPos' => 74,
            'endFilePos' => 399,
          ),
        ),
        'docComment' => NULL,
        'attributes' => 
        array (
        ),
        'startLine' => 11,
        'endLine' => 14,
        'startColumn' => 5,
        'endColumn' => 6,
      ),
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'sections' => 
      array (
        'name' => 'sections',
        'parameters' => 
        array (
          'sections' => 
          array (
            'name' => 'sections',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'array',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 20,
            'endLine' => 20,
            'startColumn' => 30,
            'endColumn' => 44,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'array',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => '/**
 * @param list<array<string, mixed>> $sections
 * @return list<array<string, mixed>>
 */',
        'startLine' => 20,
        'endLine' => 31,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => true,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Domain\\Content',
        'declaringClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'implementingClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'currentClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'aliasName' => NULL,
      ),
      'richText' => 
      array (
        'name' => 'richText',
        'parameters' => 
        array (
          'html' => 
          array (
            'name' => 'html',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'string',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 33,
            'endLine' => 33,
            'startColumn' => 30,
            'endColumn' => 41,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'string',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 33,
        'endLine' => 39,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Domain\\Content',
        'declaringClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'implementingClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'currentClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'aliasName' => NULL,
      ),
      'structuredValue' => 
      array (
        'name' => 'structuredValue',
        'parameters' => 
        array (
          'value' => 
          array (
            'name' => 'value',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'mixed',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 41,
            'endLine' => 41,
            'startColumn' => 37,
            'endColumn' => 48,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'mixed',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 41,
        'endLine' => 44,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'PerrymanFinance\\Domain\\Content',
        'declaringClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'implementingClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'currentClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'aliasName' => NULL,
      ),
      'value' => 
      array (
        'name' => 'value',
        'parameters' => 
        array (
          'value' => 
          array (
            'name' => 'value',
            'default' => NULL,
            'type' => 
            array (
              'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
              'data' => 
              array (
                'name' => 'mixed',
                'isIdentifier' => true,
              ),
            ),
            'isVariadic' => false,
            'byRef' => false,
            'isPromoted' => false,
            'attributes' => 
            array (
            ),
            'startLine' => 46,
            'endLine' => 46,
            'startColumn' => 28,
            'endColumn' => 39,
            'parameterIndex' => 0,
            'isOptional' => false,
          ),
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'mixed',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 46,
        'endLine' => 59,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 4,
        'namespace' => 'PerrymanFinance\\Domain\\Content',
        'declaringClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'implementingClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'currentClassName' => 'PerrymanFinance\\Domain\\Content\\ContentSanitizer',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));