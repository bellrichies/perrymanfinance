<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\Exception\UnknownClassOrInterfaceException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '0e3d9b10438ccdf9167c9e4637188e88' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
        ),
         'className' => 'PHPUnit\\Framework\\UnknownClassOrInterfaceException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2c0ddd40ce5baad9f99de4418d95260f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
        ),
         'className' => 'PHPUnit\\Framework\\UnknownClassOrInterfaceException',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'PHPUnit\\Framework',
           'uses' => 
          array (
          ),
           'className' => 'PHPUnit\\Framework\\UnknownClassOrInterfaceException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\vendor\\phpunit\\phpunit\\src\\Framework\\Exception\\UnknownClassOrInterfaceException.php' => 'a1ae446907f9b2f70f7577368d73b33146eabf97c6fadcbafa795278645e2b3c',
    ),
  ),
));