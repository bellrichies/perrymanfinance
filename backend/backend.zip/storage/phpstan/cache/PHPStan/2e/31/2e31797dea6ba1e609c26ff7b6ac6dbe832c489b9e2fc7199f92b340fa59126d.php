<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Core\Container.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '749df3a4d43387b1fbd061d2ee683c17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionnamedtype' => 'ReflectionNamedType',
        ),
         'className' => 'PerrymanFinance\\Core\\Container',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '47d0a688ed87abfea7ae53f4fc649be7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionnamedtype' => 'ReflectionNamedType',
        ),
         'className' => 'PerrymanFinance\\Core\\Container',
         'functionName' => 'bind',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7ed74853f87aba96a5a7b171390805f6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionnamedtype' => 'ReflectionNamedType',
        ),
         'className' => 'PerrymanFinance\\Core\\Container',
         'functionName' => 'singleton',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0cdc528ea6a2694fd6caeade3ee5a2bc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionnamedtype' => 'ReflectionNamedType',
        ),
         'className' => 'PerrymanFinance\\Core\\Container',
         'functionName' => 'instance',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c06871c3fc752ec2820bccc70fb6f36f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionnamedtype' => 'ReflectionNamedType',
        ),
         'className' => 'PerrymanFinance\\Core\\Container',
         'functionName' => 'get',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b01863a4f353fb9a761c80f36e5bbadb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionnamedtype' => 'ReflectionNamedType',
        ),
         'className' => 'PerrymanFinance\\Core\\Container',
         'functionName' => 'factory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f2468b3adf3cd71dd7e7a8d22a0bd15f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Core',
         'uses' => 
        array (
          'closure' => 'Closure',
          'reflectionclass' => 'ReflectionClass',
          'reflectionnamedtype' => 'ReflectionNamedType',
        ),
         'className' => 'PerrymanFinance\\Core\\Container',
         'functionName' => 'build',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Core\\Container.php' => 'a15529441e573ce1f39e2d7a3b2837d09d7241b3b7ab2084b35fbd4243a09de9',
    ),
  ),
));