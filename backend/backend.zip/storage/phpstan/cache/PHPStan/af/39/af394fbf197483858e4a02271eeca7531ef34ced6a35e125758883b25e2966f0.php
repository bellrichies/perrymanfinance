<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Logging\LoggerInterface.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '3e32e6526eb0406ab0786d0239f467ae' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Logging',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Logging\\LoggerInterface',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '356395dcf7d4c8d18b7b221cddfeeb23' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Logging',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Logging\\LoggerInterface',
         'functionName' => 'log',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Logging\\LoggerInterface.php' => 'ae18d93ac79ee554bcafd450afd11a2d4a7dbcfada71d010f001ac7001ef03a0',
    ),
  ),
));