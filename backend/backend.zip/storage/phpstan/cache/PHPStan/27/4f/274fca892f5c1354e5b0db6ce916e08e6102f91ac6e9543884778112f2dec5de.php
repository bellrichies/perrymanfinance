<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Http\RequestTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Http\RequestTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-c3605c8ca51b50aef971e6256637f4046f96779daf66c2652fff2ec3aa6f345b',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Http\\RequestTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Http/RequestTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Http',
    'name' => 'Tests\\Unit\\Http\\RequestTest',
    'shortName' => 'RequestTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 10,
    'endLine' => 27,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testRequestExposesInputsAndRouteParameters' => 
      array (
        'name' => 'testRequestExposesInputsAndRouteParameters',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 12,
        'endLine' => 26,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Http',
        'declaringClassName' => 'Tests\\Unit\\Http\\RequestTest',
        'implementingClassName' => 'Tests\\Unit\\Http\\RequestTest',
        'currentClassName' => 'Tests\\Unit\\Http\\RequestTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));