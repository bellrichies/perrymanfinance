<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\AbstractRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '9ede7dd1af1fdf7f493e7b64454bfb1b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'pdostatement' => 'PDOStatement',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AbstractRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6c4c4001e67c3d7f3cbd783f8685ede5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'pdostatement' => 'PDOStatement',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AbstractRepository',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dc85034126a4cc3da25baaf686ba2b47' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'pdostatement' => 'PDOStatement',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AbstractRepository',
         'functionName' => 'connection',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '10fd92115b582a26df8a735e930b4b97' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'pdostatement' => 'PDOStatement',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AbstractRepository',
         'functionName' => 'execute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '96f86100cebea8b3b634978f41f7da7a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'pdostatement' => 'PDOStatement',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'invalidargumentexception' => 'InvalidArgumentException',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AbstractRepository',
         'functionName' => 'allowedIdentifier',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\AbstractRepository.php' => '50897d0c0a50ec744bebabcbceace454384dd92002ffb3c57f881c764b1b6139',
    ),
  ),
));