<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Database\Seeders\SeedRunner.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'aee3121dedd97d49179261e0ba70a8bb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Seeders',
         'uses' => 
        array (
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Seeders\\SeedRunner',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '51aed75ae6fb5257fc292badd037b7f8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Seeders',
         'uses' => 
        array (
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Seeders\\SeedRunner',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd7b56fe02d09ee63eb0455b5f1bd9332' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Seeders',
         'uses' => 
        array (
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'runtimeexception' => 'RuntimeException',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Seeders\\SeedRunner',
         'functionName' => 'run',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Database\\Seeders\\SeedRunner.php' => '7fdb55bba9556ec706bdea706e0f093354690d8767aa500e8354fb31a62e137b',
    ),
  ),
));