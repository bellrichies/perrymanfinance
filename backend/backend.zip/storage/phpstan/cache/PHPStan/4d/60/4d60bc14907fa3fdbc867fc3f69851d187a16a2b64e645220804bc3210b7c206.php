<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\InsightRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '55a4d89d130b0ba1711a3a48471122b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '35c50444b1f4a4eaadfafa676b2f7bb3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'categories',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7a2eb66cf8ec8b486363956b1b5b3dea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'category',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e1436958e9e535585395158d83b5f837' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'insertCategory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8c56bc93a44c261289c76f4283433d38' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'updateCategory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4b92aab81e8028a32157fc58c9f7cc3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'deleteCategory',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '19210eae3588a83cef5ddc8faef6cb5a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'tags',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b9c98339222c39f82064a38a221d4b3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'tag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '56d554a348ab081a2adff9a06ae4d0a1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'insertTag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1b27f07d374a7660818f068cc884ac08' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'updateTag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '57db508310ba145aea77fa2338f3d151' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'deleteTag',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '6960bab94a68163d1597618164da40ea' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'articles',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '87c96f7534f1cee589ee8c1c79239d82' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'article',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3559d83d40cb12cf13ef8a0e1480da0b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'insertArticle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '766547e35b5897d0e1d75abc4024bceb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'updateArticle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9229dc6ca905f274edb336bc832750cf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'replaceArticleTags',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd936afbed35862dadf72176a879cb965' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'archiveArticle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2ee516e3e6f95e9afcf2c2c4a0d0bb5b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'related',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8403817be9def927ba9347f360d88671' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'faqs',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '665309183fba1f7f30d0771f2a22c06e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'faq',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ce02452e41702615880ed245a8d5ee34' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'insertFaq',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '61c0aea9c009f17ea8a5c41d30a89c96' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'updateFaq',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '985dd96f4fa792a473760579fbcf3207' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'deleteFaq',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3f5b8faa090a9fee08f1f5dcbeb5b1e1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'withTags',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4bd6ceeacbdf3e3204ed9a07663bf07b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'datetimeimmutable' => 'DateTimeImmutable',
          'datetimezone' => 'DateTimeZone',
        ),
         'className' => 'PerrymanFinance\\Repositories\\InsightRepository',
         'functionName' => 'now',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\InsightRepository.php' => '61f8f469fcf5030c42382508840071ea8515b47175e9337e15790a41c8687d18',
    ),
  ),
));