<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-FILTER_SANITIZE_STRING
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'FILTER_SANITIZE_STRING',
        'filename' => 'phpstorm-stubs:filter/filter.stub',
        'extensionName' => 'filter',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'FILTER_SANITIZE_STRING',
    'shortName' => 'FILTER_SANITIZE_STRING',
    'value' => 
    array (
      'code' => '513',
      'attributes' => 
      array (
        'startLine' => 8,
        'endLine' => 8,
        'startTokenPos' => 9,
        'startFilePos' => 149,
        'endTokenPos' => 9,
        'endFilePos' => 151,
      ),
    ),
    'docComment' => '/**
 * ID of "string" filter.
 * @link https://php.net/manual/en/filter.constants.php
 * @deprecated 8.1
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 8,
    'endLine' => 8,
    'startColumn' => 1,
    'endColumn' => 37,
    'namespace' => NULL,
  ),
));