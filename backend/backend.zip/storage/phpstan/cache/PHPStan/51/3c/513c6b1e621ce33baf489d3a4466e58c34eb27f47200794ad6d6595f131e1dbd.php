<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-FILE_SKIP_EMPTY_LINES
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'FILE_SKIP_EMPTY_LINES',
        'filename' => 'phpstorm-stubs:standard/standard_defines.stub',
        'extensionName' => 'standard',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'FILE_SKIP_EMPTY_LINES',
    'shortName' => 'FILE_SKIP_EMPTY_LINES',
    'value' => 
    array (
      'code' => '4',
      'attributes' => 
      array (
        'startLine' => 7,
        'endLine' => 7,
        'startTokenPos' => 9,
        'startFilePos' => 127,
        'endTokenPos' => 9,
        'endFilePos' => 127,
      ),
    ),
    'docComment' => '/**
 * Skip empty lines
 * @link https://php.net/manual/en/filesystem.constants.php
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 7,
    'startColumn' => 1,
    'endColumn' => 34,
    'namespace' => NULL,
  ),
));