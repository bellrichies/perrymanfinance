<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-PHP_INT_MAX
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'PHP_INT_MAX',
        'filename' => 'phpstorm-stubs:Core/Core_d.stub',
        'extensionName' => 'Core',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'PHP_INT_MAX',
    'shortName' => 'PHP_INT_MAX',
    'value' => 
    array (
      'code' => '9223372036854775807',
      'attributes' => 
      array (
        'startLine' => 3,
        'endLine' => 3,
        'startTokenPos' => 7,
        'startFilePos' => 29,
        'endTokenPos' => 7,
        'endFilePos' => 47,
      ),
    ),
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 3,
    'endLine' => 3,
    'startColumn' => 1,
    'endColumn' => 42,
    'namespace' => NULL,
  ),
));