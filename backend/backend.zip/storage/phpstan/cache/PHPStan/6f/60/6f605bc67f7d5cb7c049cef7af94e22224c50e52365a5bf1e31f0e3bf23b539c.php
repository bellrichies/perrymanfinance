<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\Exception\GeneratorNotSupportedException.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '7025a1d2673c7df2d713565c229a20fb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
        ),
         'className' => 'PHPUnit\\Framework\\GeneratorNotSupportedException',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '35e614e6d87a9b28ab62c91788f35d74' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework',
         'uses' => 
        array (
        ),
         'className' => 'PHPUnit\\Framework\\GeneratorNotSupportedException',
         'functionName' => 'fromParameterName',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => 'PHPUnit\\Framework',
           'uses' => 
          array (
          ),
           'className' => 'PHPUnit\\Framework\\GeneratorNotSupportedException',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\vendor\\phpunit\\phpunit\\src\\Framework\\Exception\\GeneratorNotSupportedException.php' => '2d2b9bc5da71b951d1347437feb189ffe05f2f75816312e349967bc6e3d8ee75',
    ),
  ),
));