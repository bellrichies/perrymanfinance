<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Database\Migrations\MigrationRunner.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '36538debec185067e36745a81b381bde' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRunner',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2b8a8f9c9c23b65b6a0f2826c60f5bc1' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRunner',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '29196ab7ac131f15fa6481e449ec7dbe' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRunner',
         'functionName' => 'migrate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3de9315246bf72df5066fea7616923ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRunner',
         'functionName' => 'rollback',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7c9dd48c184d44c99db0b390e5fafece' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRunner',
         'functionName' => 'status',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '144fa9288c641cb99c440070f5592622' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'pdo' => 'PDO',
          'connectioninterface' => 'PerrymanFinance\\Database\\ConnectionInterface',
          'throwable' => 'Throwable',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRunner',
         'functionName' => 'execute',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Database\\Migrations\\MigrationRunner.php' => 'd17062c0426d5e5afaaf69fbc0dbea79bec68b5850da7c4247000d159faa2c73',
    ),
  ),
));