<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-FILTER_VALIDATE_URL
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'FILTER_VALIDATE_URL',
        'filename' => 'phpstorm-stubs:filter/filter.stub',
        'extensionName' => 'filter',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'FILTER_VALIDATE_URL',
    'shortName' => 'FILTER_VALIDATE_URL',
    'value' => 
    array (
      'code' => '273',
      'attributes' => 
      array (
        'startLine' => 7,
        'endLine' => 7,
        'startTokenPos' => 9,
        'startFilePos' => 133,
        'endTokenPos' => 9,
        'endFilePos' => 135,
      ),
    ),
    'docComment' => '/**
 * ID of "validate_url" filter.
 * @link https://php.net/manual/en/filter.constants.php
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 7,
    'startColumn' => 1,
    'endColumn' => 34,
    'namespace' => NULL,
  ),
));