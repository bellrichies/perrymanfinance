<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\MockObject\Runtime\Interface\Stub.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'eb3564246fdaddddc7e44d932bce0da2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework\\MockObject',
         'uses' => 
        array (
          'invocationstubber' => 'PHPUnit\\Framework\\MockObject\\Builder\\InvocationStubber',
        ),
         'className' => 'PHPUnit\\Framework\\MockObject\\Stub',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\vendor\\phpunit\\phpunit\\src\\Framework\\MockObject\\Runtime\\Interface\\Stub.php' => '33dad69469d99b64cf86563bc39fa8323fadf7a7f44870f15dd0e1bb1134a5e1',
    ),
  ),
));