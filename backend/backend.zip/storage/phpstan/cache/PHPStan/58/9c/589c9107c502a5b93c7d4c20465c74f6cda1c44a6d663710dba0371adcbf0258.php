<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\vendor\phpunit\phpunit\src\Framework\MockObject\Exception\Exception.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'a098c74e63c45d5f4fcc6b9c1f175177' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PHPUnit\\Framework\\MockObject',
         'uses' => 
        array (
        ),
         'className' => 'PHPUnit\\Framework\\MockObject\\Exception',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\vendor\\phpunit\\phpunit\\src\\Framework\\MockObject\\Exception\\Exception.php' => '22dd6286a484a6e9d755b1a39de0613d076d1680da010ef212727dcfacedc4e4',
    ),
  ),
));