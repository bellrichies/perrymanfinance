<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\Response.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '6a913c3f63d93999efeb8afcdac12fc8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
          'jsonexception' => 'JsonException',
        ),
         'className' => 'PerrymanFinance\\Http\\Response',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e207d48035e66edb39e87b1ab0c8fc6c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
          'jsonexception' => 'JsonException',
        ),
         'className' => 'PerrymanFinance\\Http\\Response',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4997df202298f8eb1b8aaaa712830565' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
          'jsonexception' => 'JsonException',
        ),
         'className' => 'PerrymanFinance\\Http\\Response',
         'functionName' => 'status',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '683561ec331c62341c5ca06f5d19769f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
          'jsonexception' => 'JsonException',
        ),
         'className' => 'PerrymanFinance\\Http\\Response',
         'functionName' => 'body',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'da50d2810aac70c8f79ad5a259b823cb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
          'jsonexception' => 'JsonException',
        ),
         'className' => 'PerrymanFinance\\Http\\Response',
         'functionName' => 'headers',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f2e77916356d1dc8df8c5ae23d4b42dc' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
          'jsonexception' => 'JsonException',
        ),
         'className' => 'PerrymanFinance\\Http\\Response',
         'functionName' => 'withHeader',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f1d28b040a4d9861f19e5cf7837c4ddf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
          'jsonexception' => 'JsonException',
        ),
         'className' => 'PerrymanFinance\\Http\\Response',
         'functionName' => 'send',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\Response.php' => '3f543b267f74c1ae6715539afcbe3caff235da99a2da95cb69038b1ec41f0e31',
    ),
  ),
));