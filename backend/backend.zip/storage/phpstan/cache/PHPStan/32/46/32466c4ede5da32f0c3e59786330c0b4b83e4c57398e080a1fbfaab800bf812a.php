<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1-enums',
   'data' => 
  array (
    'D:\\Perryman\\backend\\tests\\Feature\\HealthEndpointTest.php' => 
    array (
      0 => '941aa84abb4f95ac105937b35975b4b5af2c17076d00bcd612b0b6a2094602ae',
      1 => 
      array (
        0 => 'tests\\feature\\healthendpointtest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\testhealthendpointusesthestandardsuccessenvelope',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\bootstrap.php' => 
    array (
      0 => '51047661d6c8c78fb3942f80eef8291a5b87ad9a5ef19c6cefdb91083d76868c',
      1 => 
      array (
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\CoreFrameworkTest.php' => 
    array (
      0 => '3212b535521e37841c4d2938223ce5d171a4c538423157218146e9c676783566',
      1 => 
      array (
        0 => 'tests\\feature\\coreframeworktest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\testproductionmaskserrorsevenwithdebugenabled',
        1 => 'tests\\feature\\testnotfoundandmethodnotallowedaremappedtosafeapierrors',
        2 => 'tests\\feature\\testunexpectedexceptionismasked',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Support\\ApplicationFactory.php' => 
    array (
      0 => '532152598c2caef7e5a8fb846882583cf345fd7e04347d7417dd55f745464b43',
      1 => 
      array (
        0 => 'tests\\support\\applicationfactory',
      ),
      2 => 
      array (
        0 => 'tests\\support\\create',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Support\\ExampleContract.php' => 
    array (
      0 => '3faaf8151f5c43c7ab62a6b74498ca1a05a0b7a3f40bc0c57c2f3f66038a629f',
      1 => 
      array (
        0 => 'tests\\support\\examplecontract',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Support\\ExampleService.php' => 
    array (
      0 => '3c399718aadc0ec20b929293a31cb0199e48fb5778fe00b44e2aa76bf508ecfb',
      1 => 
      array (
        0 => 'tests\\support\\exampleservice',
      ),
      2 => 
      array (
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Support\\InMemoryLogger.php' => 
    array (
      0 => '938f0ba3d7462004e6e0c049bac114a8fd3deb9e1d281f90b561fb76b9063b7f',
      1 => 
      array (
        0 => 'tests\\support\\inmemorylogger',
      ),
      2 => 
      array (
        0 => 'tests\\support\\log',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Core\\ContainerTest.php' => 
    array (
      0 => '0d8240da1ec6b9c77a63c3da83fe80475c5f15e3854e6d5352d07d2c13cdcd73',
      1 => 
      array (
        0 => 'tests\\unit\\core\\containertest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\core\\testinterfacebindingandsingletonlifecycle',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Database\\PdoConnectionManagerTest.php' => 
    array (
      0 => '55e42b83e4c08c0d7112ba4b705d77a0830d9a03c4b42aa7725b3d88ea1a0547',
      1 => 
      array (
        0 => 'tests\\unit\\database\\pdoconnectionmanagertest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\database\\testconfiguredconnectioniscreatedoncewithsafedefaults',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Http\\ApiResponseFactoryTest.php' => 
    array (
      0 => '2687f6ed82dbed9b3a483d9488f3ecf69eff2b7c78156a2b536a28a59afd5e6e',
      1 => 
      array (
        0 => 'tests\\unit\\http\\apiresponsefactorytest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\http\\testsuccessanderrorenvelopesarestable',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Http\\RequestTest.php' => 
    array (
      0 => 'c3605c8ca51b50aef971e6256637f4046f96779daf66c2652fff2ec3aa6f345b',
      1 => 
      array (
        0 => 'tests\\unit\\http\\requesttest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\http\\testrequestexposesinputsandrouteparameters',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Http\\RouterTest.php' => 
    array (
      0 => 'aa56709e1f4e99c18e6def837c4c195d841254c55e4cac01280a3617baf8142f',
      1 => 
      array (
        0 => 'tests\\unit\\http\\routertest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\http\\testgroupsandrouteparametersarematched',
        1 => 'tests\\unit\\http\\testknownpathwithwrongmethodthrowsmethodnotallowed',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Validation\\ValidatorTest.php' => 
    array (
      0 => 'eb88369c017fff6e8a0e1966bf3ca93f64118bfbff336cf17f1eafbbf636df88',
      1 => 
      array (
        0 => 'tests\\unit\\validation\\validatortest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\validation\\testvaliddataisreturnedandunknownfieldsareexcluded',
        1 => 'tests\\unit\\validation\\testinvaliddataproducesfielderrors',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Fixtures\\failing-migrations\\001_fails.php' => 
    array (
      0 => '6c15b4b250b80b2a16241a41b5ffe4a19d801f5cc923e98041fdd562614ea233',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Fixtures\\migrations\\001_create_widgets.php' => 
    array (
      0 => '873d3ab0e0303ca769ef7e7d9cec77a52b62a03723f6c2493818687904f149f5',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Fixtures\\migrations\\002_create_gadgets.php' => 
    array (
      0 => 'dbafd1318f56cf8caf607ac49f61adabb491fe059242b9817e290c762cb137fb',
      1 => 
      array (
      ),
      2 => 
      array (
        0 => 'name',
        1 => 'up',
        2 => 'down',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Integration\\Database\\MigrationRunnerTest.php' => 
    array (
      0 => 'b0d16b6cfa525de76d2de8fa495d8515f45c2852395b62732b089dfb45d3d8bc',
      1 => 
      array (
        0 => 'tests\\integration\\database\\migrationrunnertest',
      ),
      2 => 
      array (
        0 => 'tests\\integration\\database\\testmigratestatusandrollbackaretracked',
        1 => 'tests\\integration\\database\\testfailedtransactionalmigrationisnotpartiallyappliedorrecorded',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Support\\SqliteConnection.php' => 
    array (
      0 => 'cd06fa22159937d3189588825d70e55600f775aed7eb417df7b7e3c4332fe03d',
      1 => 
      array (
        0 => 'tests\\support\\sqliteconnection',
      ),
      2 => 
      array (
        0 => 'tests\\support\\__construct',
        1 => 'tests\\support\\memory',
        2 => 'tests\\support\\connection',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Database\\MigrationRegistryTest.php' => 
    array (
      0 => '43a4164d4796a8400858b8acbf642ed86ffed3d9c9dec52afb4be897cca79173',
      1 => 
      array (
        0 => 'tests\\unit\\database\\migrationregistrytest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\database\\testfilesareloadedindeterministicfilenameorder',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Database\\SeedRunnerTest.php' => 
    array (
      0 => '050ccd5124834df7d8041b7a075f3dd64a51808f1edb7e975b899d3e351172dc',
      1 => 
      array (
        0 => 'tests\\unit\\database\\seedrunnertest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\database\\testproductionseedingisrejected',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Database\\InitialSchemaDefinitionTest.php' => 
    array (
      0 => 'ce81604eeb430496b1ff9e4f0eb56ef8cf448dd30d9375267003be044c386ccb',
      1 => 
      array (
        0 => 'tests\\unit\\database\\initialschemadefinitiontest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\database\\testallrequiredtablesaredefinedwithmysqlstoragerequirements',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\AdminIdentityTest.php' => 
    array (
      0 => '1d71b21a15093ca95eeb972c8b0a0c263bd0a66006becb50e5493da00f8e2c9f',
      1 => 
      array (
        0 => 'tests\\feature\\adminidentitytest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\setup',
        1 => 'tests\\feature\\testvalidloginrefreshandlogoutrotation',
        2 => 'tests\\feature\\testinvalidloginandinactiveadminarerejected',
        3 => 'tests\\feature\\testlogoutrevokesrefreshtoken',
        4 => 'tests\\feature\\testexpiredrefreshtokenisrejected',
        5 => 'tests\\feature\\testratelimitingreturnstoomanyrequests',
        6 => 'tests\\feature\\testpasswordresetchangespasswordandrevokessessions',
        7 => 'tests\\feature\\testforgotpassworddoesnotrevealunknownaccount',
        8 => 'tests\\feature\\testpermissionmiddlewaredeniesmissingpermission',
        9 => 'tests\\feature\\insertuser',
        10 => 'tests\\feature\\createschema',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Identity\\TokenServiceTest.php' => 
    array (
      0 => '57292498b2bb33e932b37e45554d67ae329868e9f7490d6520312b33540c039b',
      1 => 
      array (
        0 => 'tests\\unit\\identity\\tokenservicetest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\identity\\testexpiredaccesstokenisrejected',
        1 => 'tests\\unit\\identity\\testtamperedaccesstokenisrejected',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Support\\CapturingResetNotifier.php' => 
    array (
      0 => 'ba6cb78501e8b7df6a492c599137c7800915fc83b273e522a7c64d2c2e7908f5',
      1 => 
      array (
        0 => 'tests\\support\\capturingresetnotifier',
      ),
      2 => 
      array (
        0 => 'tests\\support\\send',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\CmsFunctionalityTest.php' => 
    array (
      0 => '31f062284aab5c51798ad42c1f11aa3d0f0757ba0de9ed36e7a0b5e36d26d7bb',
      1 => 
      array (
        0 => 'tests\\feature\\cmsfunctionalitytest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\setup',
        1 => 'tests\\feature\\testdraftishiddenandpublishedpageisvisible',
        2 => 'tests\\feature\\testfuturepublishedpageisnotvisible',
        3 => 'tests\\feature\\testlegalversionupdatesandscriptsareremoved',
        4 => 'tests\\feature\\testseometadatapersistsforpageowner',
        5 => 'tests\\feature\\testpublishedpagerenamecreatesredirect',
        6 => 'tests\\feature\\testinvalidmediauploadisrejected',
        7 => 'tests\\feature\\testcmsmutationwithoutauthenticatedprincipalisdenied',
        8 => 'tests\\feature\\pageinput',
        9 => 'tests\\feature\\createschema',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\InvestmentCatalogueTest.php' => 
    array (
      0 => 'f08665e7f65a5e287371ea1f0bdd2696d0b914c16c7f300b2a3751199391b098',
      1 => 
      array (
        0 => 'tests\\feature\\investmentcataloguetest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\setup',
        1 => 'tests\\feature\\testdraftisinvisibleandpublisheddetailispublic',
        2 => 'tests\\feature\\testfilteringandpagination',
        3 => 'tests\\feature\\testslugandriskvalidation',
        4 => 'tests\\feature\\testadminmutationrequiresinvestmentpermission',
        5 => 'tests\\feature\\input',
        6 => 'tests\\feature\\createschema',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\EditorialPublishingTest.php' => 
    array (
      0 => 'cbc1fcb46368dbe5b0d2f3e3adc6ec98553f774e2ec345e9a40d45cb97679b98',
      1 => 
      array (
        0 => 'tests\\feature\\editorialpublishingtest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\setup',
        1 => 'tests\\feature\\testdraftisinvisibleandpublishedarticlesanitizescontent',
        2 => 'tests\\feature\\testpaginationfiltersandarticletagrelationships',
        3 => 'tests\\feature\\testrelatedarticlesusecategoryorsharedtags',
        4 => 'tests\\feature\\testfaqorderingandpublicationvisibility',
        5 => 'tests\\feature\\articleinput',
        6 => 'tests\\feature\\createschema',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\EnquirySubmissionTest.php' => 
    array (
      0 => '12c77486f69073fc7ade0f6f1b68d4178b7cb0ba0aeed6a93bcabf4246c61171',
      1 => 
      array (
        0 => 'tests\\feature\\enquirysubmissiontest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\setup',
        1 => 'tests\\feature\\notify',
        2 => 'tests\\feature\\testsubmissionsurvivesnotificationfailureandusespreparedstatements',
        3 => 'tests\\feature\\testconsentcannotbebypassed',
        4 => 'tests\\feature\\testmissingpublishedprivacyblockssubmission',
        5 => 'tests\\feature\\testinvalidemailandoversizedmessagearerejected',
        6 => 'tests\\feature\\testhoneypotdoesnotpersistandrequestsarethrottled',
        7 => 'tests\\feature\\countenquiries',
        8 => 'tests\\feature\\input',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\AdminEnquiryTest.php' => 
    array (
      0 => 'd80e6b79054017c2269f009918ad4f20d3a8f2b4f3d5481cab7aa91225095f11',
      1 => 
      array (
        0 => 'tests\\feature\\adminenquirytest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\setup',
        1 => 'tests\\feature\\teststatusworkflowrecordsauditwithoutpersonaldata',
        2 => 'tests\\feature\\testinvalidtransitionandextrafieldsarerejected',
        3 => 'tests\\feature\\testauditfailurerollsbackstatus',
        4 => 'tests\\feature\\testsearchfilterandpagination',
        5 => 'tests\\feature\\testactualadminroutesrejectanonymousaccess',
        6 => 'tests\\feature\\testviewercannotupdatestatus',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Feature\\TechnicalSeoTest.php' => 
    array (
      0 => 'b4d5a7ff0614e485f2970eb5450eeeddcd715027cbba236b3478b00da41b0791',
      1 => 
      array (
        0 => 'tests\\feature\\technicalseotest',
      ),
      2 => 
      array (
        0 => 'tests\\feature\\setup',
        1 => 'tests\\feature\\testsitemapincludesonlypublishedindexablepubliccontent',
        2 => 'tests\\feature\\testrobotsreferencesabsoluteproductionsitemap',
        3 => 'tests\\feature\\testproductionsitemaprequireshttpsorigin',
        4 => 'tests\\feature\\testredirectsareinternalpublicpathsonly',
        5 => 'tests\\feature\\seedcontent',
        6 => 'tests\\feature\\createschema',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\tests\\Unit\\Http\\SecurityHeadersMiddlewareTest.php' => 
    array (
      0 => '7d543d4440ac23a1c2aa3b1747b1f95ceeda1bf744efdbd4d8e0f561ca031e67',
      1 => 
      array (
        0 => 'tests\\unit\\http\\securityheadersmiddlewaretest',
      ),
      2 => 
      array (
        0 => 'tests\\unit\\http\\testproductionhttpsresponseincludessecurityandpubliccacheheaders',
        1 => 'tests\\unit\\http\\testadminresponsesarenotgivenpubliccacheheaders',
      ),
      3 => 
      array (
      ),
    ),
  ),
));