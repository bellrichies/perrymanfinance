<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\ClientAuditRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'caea88322ccb55728df5f481161fcd8c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eef9bb34a38fdf48e65fed9bb4fcb507' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
         'functionName' => 'record',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c1a64be3001b24451c11835b929b496b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Repositories\\ClientAuditRepository',
         'functionName' => 'forClient',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\ClientAuditRepository.php' => 'fde5034883147cdb0d9630358bec2ae16646644d85c67e3631035ebf53ebd3ac',
    ),
  ),
));