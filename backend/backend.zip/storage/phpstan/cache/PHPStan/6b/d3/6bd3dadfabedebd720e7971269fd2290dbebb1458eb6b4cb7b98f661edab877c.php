<?php declare(strict_types = 1);

// odsl-D:\Perryman\backend\tests\Unit\Database\MigrationRegistryTest.php-PHPStan\BetterReflection\Reflection\ReflectionClass-Tests\Unit\Database\MigrationRegistryTest
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-8.2.12-43a4164d4796a8400858b8acbf642ed86ffed3d9c9dec52afb4be897cca79173',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\LocatedSource',
      'data' => 
      array (
        'name' => 'Tests\\Unit\\Database\\MigrationRegistryTest',
        'filename' => 'D:/Perryman/backend/tests/Unit/Database/MigrationRegistryTest.php',
      ),
    ),
    'namespace' => 'Tests\\Unit\\Database',
    'name' => 'Tests\\Unit\\Database\\MigrationRegistryTest',
    'shortName' => 'MigrationRegistryTest',
    'isInterface' => false,
    'isTrait' => false,
    'isEnum' => false,
    'isBackedEnum' => false,
    'modifiers' => 32,
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 10,
    'endLine' => 20,
    'startColumn' => 1,
    'endColumn' => 1,
    'parentClassName' => 'PHPUnit\\Framework\\TestCase',
    'implementsClassNames' => 
    array (
    ),
    'traitClassNames' => 
    array (
    ),
    'immediateConstants' => 
    array (
    ),
    'immediateProperties' => 
    array (
    ),
    'immediateMethods' => 
    array (
      'testFilesAreLoadedInDeterministicFilenameOrder' => 
      array (
        'name' => 'testFilesAreLoadedInDeterministicFilenameOrder',
        'parameters' => 
        array (
        ),
        'returnsReference' => false,
        'returnType' => 
        array (
          'class' => 'PHPStan\\BetterReflection\\Reflection\\ReflectionNamedType',
          'data' => 
          array (
            'name' => 'void',
            'isIdentifier' => true,
          ),
        ),
        'attributes' => 
        array (
        ),
        'docComment' => NULL,
        'startLine' => 12,
        'endLine' => 19,
        'startColumn' => 5,
        'endColumn' => 5,
        'couldThrow' => false,
        'isClosure' => false,
        'isGenerator' => false,
        'isVariadic' => false,
        'modifiers' => 1,
        'namespace' => 'Tests\\Unit\\Database',
        'declaringClassName' => 'Tests\\Unit\\Database\\MigrationRegistryTest',
        'implementingClassName' => 'Tests\\Unit\\Database\\MigrationRegistryTest',
        'currentClassName' => 'Tests\\Unit\\Database\\MigrationRegistryTest',
        'aliasName' => NULL,
      ),
    ),
    'traitsData' => 
    array (
      'aliases' => 
      array (
      ),
      'modifiers' => 
      array (
      ),
      'precedences' => 
      array (
      ),
      'hashes' => 
      array (
      ),
    ),
  ),
));