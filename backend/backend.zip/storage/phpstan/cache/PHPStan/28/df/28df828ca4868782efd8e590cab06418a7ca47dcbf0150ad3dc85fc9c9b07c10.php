<?php declare(strict_types = 1);

// ftm-phar://D:\Perryman\backend\vendor\phpstan\phpstan\phpstan.phar\vendor\jetbrains\phpstorm-stubs\standard\standard_1.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '9b7d0f0bbbfe4a994e1bdd789ff3aed4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strtoupper',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c56bad8080dfdd7e8d1e70b5a8990c6c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strtolower',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0e55dff6258d9c8b6fe79d3bdfde8035' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strpos',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e9989aa7f4dc8b39f1025b5a319fc643' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'stripos',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '870ffb70c2553f95dccb2b8afa7e883c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strrpos',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '697a255b261ee13903076bbe8b95d798' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strripos',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1f30a9c3c37eecb05c05083214a1defb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strrev',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '94ba12a8adec896b882f2adcdfcd7704' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'hebrev',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b75ae5b02d5e7daa5df42893ff308bd6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'hebrevc',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'cf72653452a9642c1436b216c5365ccd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'nl2br',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '62454c0294a01c25e814586a1407d7b9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'basename',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '72bad7ea40f92e28ce184fa00fb99ed5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'dirname',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2351a8842cff69ae53249e5ffd9bfbee' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'pathinfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'bafca32e54cd3d80fdbe99c5435a9c65' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'stripslashes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'adb520b4d302ff709c100db88d68b18a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'stripcslashes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1a3063bd74c060e82a2c37e52ac602fa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strstr',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ec7b5f01018e38ef2ae6dfeb1c5ead68' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'stristr',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9f944aece83f2d53fc0596b5c731349a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strrchr',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0f1a3427912d28df3e970f78b52b12bf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'str_shuffle',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4eb517293512c5dc102fab91522599ef' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'str_word_count',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'babad5b56e72d6bb1c4a14421aa4faa4' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'str_split',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8d7e5935fbf7ed35fb41eddaca800f16' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strpbrk',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e8b384e657c2af7377a64052ca3de5d7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'substr_compare',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1367a1cccae4b4bac5a03ffdbefab8c7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strcoll',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e8e348daaa5ebd34d557f7a8adb2c9cf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'money_format',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd692b72d16dcc6fcabbc18dbd6cc1380' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'substr',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '38a6d061d48854908bf51fecec464405' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'substr_replace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'daaf52d66e9b4a915c4f721f4f851faa' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'quotemeta',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7818dd965c523d2d7a22c84f16e247ad' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'ucfirst',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'be6975b7a2bdeabaffb569d926c369e8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'lcfirst',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9d2935ad0262a3abdf373ef04493d5c2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'ucwords',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a03445911518dc1ff0dd1cb28a697527' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strtr',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a654ca86fe5eb4379dfee6d663858e3f' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'addslashes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12531527c57791aabed32686efe223f0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'addcslashes',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '295432034c1d1ace75833b56f1732f39' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'rtrim',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '5f688505e5afe8e1070d06a9c4dd9c9a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'str_replace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aecb01edad43cbe119a84e2e685f2016' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'str_ireplace',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9186bdc7e3516cf470f2353f2202956b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'str_repeat',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c173196e59fd48129826d3efbc5649a9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'count_chars',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '18b7c5cbc4cc835b04c9b23daed4a493' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'chunk_split',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '65112e10d4ebd276e517d2ea8e5d17c8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'trim',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9c2f044f3ca32418529f624fd7b2ae8c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'ltrim',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3b22e6923b49adc88bc0776739b9fdeb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strip_tags',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '809277a6d5721c5dd4418c824ab40361' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'similar_text',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '93e97c95e4bb6a5e41714dcd9e67e2b0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'explode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1a862ad18e508478fe64dd3de60914a2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'implode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '92cf092fb3a0ef0df4fb54047cecd2b6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'join',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4eaf85f1ca32d0328bd46c5235c5dfdb' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'setlocale',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '214764a8c00a0831f20d280706286e61' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'localeconv',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar://D:\\Perryman\\backend\\vendor\\phpstan\\phpstan\\phpstan.phar\\vendor\\jetbrains\\phpstorm-stubs\\standard\\standard_1.stub' => '4431109d74e0c1baf17458b514aef16ad7a1f98517a4dc07e502b749ee59e3e4',
    ),
  ),
));