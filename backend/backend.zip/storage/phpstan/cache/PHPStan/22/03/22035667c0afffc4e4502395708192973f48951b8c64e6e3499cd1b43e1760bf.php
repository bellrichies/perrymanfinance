<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Database\Migrations\MigrationRegistry.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'a32b431799bc8cf4e58375926243a6e6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRegistry',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'afa51bf0b4d7d94ac10a129b9cb9fae2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRegistry',
         'functionName' => '__construct',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e721a8031b53f598907a3e9b0e86ce6c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Database\\Migrations',
         'uses' => 
        array (
          'runtimeexception' => 'RuntimeException',
        ),
         'className' => 'PerrymanFinance\\Database\\Migrations\\MigrationRegistry',
         'functionName' => 'all',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Database\\Migrations\\MigrationRegistry.php' => '0f118ee1cfa43b687362e6cb83fe5121bd09b0e33d0e36939dc21485836dc89e',
    ),
  ),
));