<?php declare(strict_types = 1);

// osfsl-phar://D:/Perryman/backend/vendor/phpstan/phpstan/phpstan.phar/src/Node/NodeScanner.php-presentSymbols
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-2278a668b5a1b0ad6c9c35538fc4fb8e2cc26531fef97358c41b9ea63f4b2785-8.3.33',
   'data' => 
  array (
    'classes' => 
    array (
      'phpstan\\node\\nodescanner' => true,
    ),
    'functions' => 
    array (
    ),
    'constants' => 
    array (
    ),
  ),
));