<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Repositories\AdminUserRepository.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '81bbe8405087e4f31f73586c40e67e9d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'db854ac4934fdb385aea858166694851' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
         'functionName' => 'findByEmail',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '98dc6f5b28ab1be9d68980f3c858fa17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
         'functionName' => 'findById',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '896be886714b818bf08f1724fc50ecf9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
         'functionName' => 'recordLogin',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7bc753314b77758bb25969e81654c57a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
         'functionName' => 'updatePassword',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '16e6c4735d696eef79ec9a2092d6c9d3' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Repositories',
         'uses' => 
        array (
          'adminuser' => 'PerrymanFinance\\Domain\\Identity\\AdminUser',
        ),
         'className' => 'PerrymanFinance\\Repositories\\AdminUserRepository',
         'functionName' => 'hydrate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Repositories\\AdminUserRepository.php' => 'fcce6146f04970567def8054548417b6f3894e92e0873558d7af4460f1f2f361',
    ),
  ),
));