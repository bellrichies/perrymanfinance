<?php declare(strict_types = 1);

// ftm-D:\Perryman\backend\app\Http\ApiResponseFactory.php
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      'e64ee636ad0120375070e5aca8e136a0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\ApiResponseFactory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ca5f5e268075fef8e55f3373a30c64b2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\ApiResponseFactory',
         'functionName' => 'success',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'b10bf12606f35dddbf8c752fbd648dbf' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => 'PerrymanFinance\\Http',
         'uses' => 
        array (
        ),
         'className' => 'PerrymanFinance\\Http\\ApiResponseFactory',
         'functionName' => 'error',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'D:\\Perryman\\backend\\app\\Http\\ApiResponseFactory.php' => '71ca8e3e9d97f3a467814d1a519b7c72b0d4c4d52092941e16f5ac2509b72f03',
    ),
  ),
));