<?php declare(strict_types = 1);

// odsl-D:/Perryman/backend/database/seeders/
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v1-enums',
   'data' => 
  array (
    'D:\\Perryman\\backend\\database\\seeders\\ReferenceDataSeeder.php' => 
    array (
      0 => 'ff77977050b0402345883f536e17740f8cf10debceaaed7e1a7556c8efba9cef',
      1 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\referencedataseeder',
      ),
      2 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\name',
        1 => 'perrymanfinance\\database\\seeders\\run',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\seeders\\PublicContentSeeder.php' => 
    array (
      0 => '843c8116149c483e998655cb1ae1cd7479cc6d50d5542d74550bda916b1cb09c',
      1 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\publiccontentseeder',
      ),
      2 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\name',
        1 => 'perrymanfinance\\database\\seeders\\run',
        2 => 'perrymanfinance\\database\\seeders\\ensureseederadmin',
        3 => 'perrymanfinance\\database\\seeders\\upsertpage',
        4 => 'perrymanfinance\\database\\seeders\\replacesections',
        5 => 'perrymanfinance\\database\\seeders\\upsertlegaldocument',
        6 => 'perrymanfinance\\database\\seeders\\upsertseo',
        7 => 'perrymanfinance\\database\\seeders\\idforslug',
        8 => 'perrymanfinance\\database\\seeders\\upsertinvestmentcategory',
        9 => 'perrymanfinance\\database\\seeders\\upsertinvestmentopportunity',
        10 => 'perrymanfinance\\database\\seeders\\upsertarticlecategory',
        11 => 'perrymanfinance\\database\\seeders\\upserttag',
        12 => 'perrymanfinance\\database\\seeders\\upsertarticle',
        13 => 'perrymanfinance\\database\\seeders\\upsertfaq',
        14 => 'perrymanfinance\\database\\seeders\\settings',
        15 => 'perrymanfinance\\database\\seeders\\legaldocuments',
        16 => 'perrymanfinance\\database\\seeders\\pages',
        17 => 'perrymanfinance\\database\\seeders\\investmentcategories',
        18 => 'perrymanfinance\\database\\seeders\\investmentopportunities',
        19 => 'perrymanfinance\\database\\seeders\\articlecategories',
        20 => 'perrymanfinance\\database\\seeders\\tags',
        21 => 'perrymanfinance\\database\\seeders\\articles',
        22 => 'perrymanfinance\\database\\seeders\\faqs',
        23 => 'perrymanfinance\\database\\seeders\\grid',
        24 => 'perrymanfinance\\database\\seeders\\section',
        25 => 'perrymanfinance\\database\\seeders\\page',
        26 => 'perrymanfinance\\database\\seeders\\uuid',
      ),
      3 => 
      array (
      ),
    ),
    'D:\\Perryman\\backend\\database\\seeders\\DevAdminSeeder.php' => 
    array (
      0 => '1ce9a56d8b3b9d78d51ed257e0cf2720fbaf5c3a5824e78730c739858fc1e099',
      1 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\devadminseeder',
      ),
      2 => 
      array (
        0 => 'perrymanfinance\\database\\seeders\\name',
        1 => 'perrymanfinance\\database\\seeders\\run',
        2 => 'perrymanfinance\\database\\seeders\\uuid',
      ),
      3 => 
      array (
      ),
    ),
  ),
));