<?php declare(strict_types = 1);

// ftm-phar://D:\Perryman\backend\vendor\phpstan\phpstan\phpstan.phar\vendor\jetbrains\phpstorm-stubs\standard\standard_0.stub
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v6-2.3.5',
   'data' => 
  array (
    0 => 
    array (
      '3b2744b2c9b5479d2d0f7f7947b9ca19' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => '__PHP_Incomplete_Class',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '12da110ebdc3161e5346df7aaf970bde' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'php_user_filter',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ad46d47d9e9db7ddb8c0a1e9121a91c8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'php_user_filter',
         'functionName' => 'filter',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a4f3e0bc1d1849773860d9e09d385a11' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'php_user_filter',
         'functionName' => 'onCreate',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '88cf5706bdb46514234e64aed4fe24c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'php_user_filter',
         'functionName' => 'onClose',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8f998db720765143ff7fa41054a68fe8' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'StreamBucket',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '64f29d2742ec825ef3b11d528f9a1e45' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'Directory',
         'functionName' => NULL,
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e224a1bd5b0744c1e117d6c2feb212b5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'Directory',
         'functionName' => 'close',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
            'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'Directory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '27f183942b2e3ac75bd4e5c15d06db65' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'Directory',
         'functionName' => 'rewind',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
            'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'Directory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '788d850ad147cdd34306d23ad4a955dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => 'Directory',
         'functionName' => 'read',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => 
        \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
           'namespace' => NULL,
           'uses' => 
          array (
            'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
            'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
            'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
            'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
            'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
            'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
            'pure' => 'JetBrains\\PhpStorm\\Pure',
          ),
           'className' => 'Directory',
           'functionName' => NULL,
           'templatePhpDocNodes' => 
          array (
          ),
           'parent' => NULL,
           'typeAliasesMap' => 
          array (
          ),
           'bypassTypeAliases' => false,
           'constUses' => 
          array (
          ),
           'typeAliasClassName' => NULL,
           'traitData' => NULL,
        )),
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '386c30f892a5e83b1df4a53dc177ca17' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'constant',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'fe9f6de1eb6960b0d89adcd999a8bb10' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'bin2hex',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '75cb61d254ed5ee562b5d9c96c0b6732' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'sleep',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4922aafe5a405adf9cf3a322e7d4f61c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'usleep',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '1c09c25b803bccfc90d3c549c1507bed' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'time_nanosleep',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'de2434e75da1df6ed4e9b854e911300a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'time_sleep_until',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '953800f1f0d44528f73d230382df075c' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strptime',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'f191c5778844ec93d722310eb3afe514' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'flush',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0fe5e86e292b49af53c0750a83246fb7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'wordwrap',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '854c9844b1f6f4d09c577aeaf47bac2d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'htmlspecialchars',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '90f8ec4b1120d8ed8c6a6ea62aa2677a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'htmlentities',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'e84482efdb79e45c5226225f44d6351b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'html_entity_decode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '7380dffa88409883bf277848e26bd959' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'htmlspecialchars_decode',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '254f2f77029dd7259b02562eb84e94f5' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'get_html_translation_table',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '48a0b511a9478976f6a65d1e18687b91' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'sha1',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'a4bf90016f6ad07b138aae90a9697b3b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'sha1_file',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '9d8cdb01f05b8b32454465f1a463fc72' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'md5',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '83f3af52dab149b50b693e6f10e2a9dd' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'md5_file',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '86989eefc7a61d4d7e6be602671dee23' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'crc32',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '159cbfe640f043a270dea5c8c557bbb7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'iptcparse',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '2c0b9bb3f8d9ac947702a7c8a9c376c0' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'iptcembed',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'aa3858ed2a51a3bed74ef181de8a789a' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'getimagesize',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '86f947061fb9ba78a1840c4609bd706e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'image_type_to_mime_type',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '80819dbcf420124df3b6bee16e41ab02' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'image_type_to_extension',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '24324828a48eca9a43b33903263d1d42' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'phpinfo',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'c1ac7f2ff98179f42b5df16a5f0000be' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'phpversion',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'ee94eb52955694f2be811abb03a2a856' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'phpcredits',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '3a3d8a37cc7c34e69c30348e6e2b7ec7' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'php_logo_guid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4a5fc9f083ff299db999934b582c4a14' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'php_real_logo_guid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '373b8713f4f34dc6a2d3b7134b48387b' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'php_egg_logo_guid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '91b61989067e6cd848f86162fb24b5be' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'zend_logo_guid',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '0c3515d668eea96354fc9a06fe39031d' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'php_sapi_name',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '57435820cc0f5028621e4e82055f57d9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'php_uname',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'dffe74622e9d4f0a5a6bbdef8ff6b341' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'php_ini_scanned_files',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '8da7b4ca8ecae1f0e78970e509984a41' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'php_ini_loaded_file',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'eaa04404ca7f94eab2eabfe644603e0e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strnatcmp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      'd31595969ccdbb79cf0994e5c6beade6' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strnatcasecmp',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '10013c1da488e5157420058f0cf545f2' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'substr_count',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '892f4a56cbb4fe4f56fcced4fbc40288' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strspn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '356308c738d6ff363edf8064b7ae18a9' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strcspn',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
      '4aa3489f440d84147c5558974f355b9e' => 
      \PHPStan\Analyser\IntermediaryNameScope::__set_state(array(
         'namespace' => NULL,
         'uses' => 
        array (
          'arrayshape' => 'JetBrains\\PhpStorm\\ArrayShape',
          'deprecated' => 'JetBrains\\PhpStorm\\Deprecated',
          'expectedvalues' => 'JetBrains\\PhpStorm\\ExpectedValues',
          'languageleveltypeaware' => 'JetBrains\\PhpStorm\\Internal\\LanguageLevelTypeAware',
          'phpstormstubselementavailable' => 'JetBrains\\PhpStorm\\Internal\\PhpStormStubsElementAvailable',
          'tentativetype' => 'JetBrains\\PhpStorm\\Internal\\TentativeType',
          'pure' => 'JetBrains\\PhpStorm\\Pure',
        ),
         'className' => NULL,
         'functionName' => 'strtok',
         'templatePhpDocNodes' => 
        array (
        ),
         'parent' => NULL,
         'typeAliasesMap' => 
        array (
        ),
         'bypassTypeAliases' => false,
         'constUses' => 
        array (
        ),
         'typeAliasClassName' => NULL,
         'traitData' => NULL,
      )),
    ),
    1 => 
    array (
      'phar://D:\\Perryman\\backend\\vendor\\phpstan\\phpstan\\phpstan.phar\\vendor\\jetbrains\\phpstorm-stubs\\standard\\standard_0.stub' => '7e17a25d25749f3254d7549b2f239470969ff0478d9df418390f502bd061ecf0',
    ),
  ),
));