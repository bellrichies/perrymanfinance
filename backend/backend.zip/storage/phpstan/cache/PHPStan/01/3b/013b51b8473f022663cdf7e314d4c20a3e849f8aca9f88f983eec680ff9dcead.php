<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-FILTER_VALIDATE_DOMAIN
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'FILTER_VALIDATE_DOMAIN',
        'filename' => 'phpstorm-stubs:filter/filter.stub',
        'extensionName' => 'filter',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'FILTER_VALIDATE_DOMAIN',
    'shortName' => 'FILTER_VALIDATE_DOMAIN',
    'value' => 
    array (
      'code' => '277',
      'attributes' => 
      array (
        'startLine' => 3,
        'endLine' => 3,
        'startTokenPos' => 7,
        'startFilePos' => 40,
        'endTokenPos' => 7,
        'endFilePos' => 42,
      ),
    ),
    'docComment' => NULL,
    'attributes' => 
    array (
    ),
    'startLine' => 3,
    'endLine' => 3,
    'startColumn' => 1,
    'endColumn' => 37,
    'namespace' => NULL,
  ),
));