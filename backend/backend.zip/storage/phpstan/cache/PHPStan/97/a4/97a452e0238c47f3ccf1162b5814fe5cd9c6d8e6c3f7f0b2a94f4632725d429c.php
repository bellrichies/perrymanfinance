<?php declare(strict_types = 1);

// phpinternal-PHPStan\BetterReflection\Reflection\ReflectionConstant-SORT_REGULAR
return \PHPStan\Cache\CacheItem::__set_state(array(
   'variableKey' => 'v2-6.70.0.6-dev-master@709e512-8.2.12',
   'data' => 
  array (
    'locatedSource' => 
    array (
      'class' => 'PHPStan\\BetterReflection\\SourceLocator\\Located\\InternalLocatedSource',
      'data' => 
      array (
        'name' => 'SORT_REGULAR',
        'filename' => 'phpstorm-stubs:standard/standard_defines.stub',
        'extensionName' => 'standard',
        'aliasName' => NULL,
      ),
    ),
    'name' => 'SORT_REGULAR',
    'shortName' => 'SORT_REGULAR',
    'value' => 
    array (
      'code' => '0',
      'attributes' => 
      array (
        'startLine' => 7,
        'endLine' => 7,
        'startTokenPos' => 9,
        'startFilePos' => 144,
        'endTokenPos' => 9,
        'endFilePos' => 144,
      ),
    ),
    'docComment' => '/**
 * SORT_REGULAR is used to compare items normally.
 * @link https://php.net/manual/en/array.constants.php
 */',
    'attributes' => 
    array (
    ),
    'startLine' => 7,
    'endLine' => 7,
    'startColumn' => 1,
    'endColumn' => 25,
    'namespace' => NULL,
  ),
));